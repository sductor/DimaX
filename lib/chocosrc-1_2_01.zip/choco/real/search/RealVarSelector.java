package choco.real.search;

import choco.branch.VarSelector;
import choco.real.RealVar;

/**
 * An interface for selecting a real interval variable to narrow.
 */
public interface RealVarSelector extends VarSelector {
  public RealVar selectRealVar();
}
