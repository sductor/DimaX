package choco.set.var;

import choco.util.IntIterator;

/**
 * Created by IntelliJ IDEA.
 * User: Hadrien
 * Date: 6 juin 2004
 * Time: 15:11:54
 * To change this template use File | Settings | File Templates.
 */
public interface SetDomain {

  public BitSetEnumeratedDomain getKernelDomain();

  public BitSetEnumeratedDomain getEnveloppeDomain();

  public IntIterator getKernelIterator();

  public IntIterator getEnveloppeIterator();

  public IntIterator getOpenDomainIterator();
}
