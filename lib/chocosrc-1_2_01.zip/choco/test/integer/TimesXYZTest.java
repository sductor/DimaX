package choco.test.integer;

import choco.ContradictionException;
import choco.Problem;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

import java.util.logging.Logger;


public class TimesXYZTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private IntDomainVar x, y, z;

  protected void setUp() {
    logger.fine("choco.test.bool.TimesXYZTest Testing...");
    pb = new Problem();
  }

  protected void tearDown() {
    y = null;
    x = null;
    z = null;
    pb = null;
  }

  public void test1() {
    logger.finer("test1");
    x = pb.makeBoundIntVar("x", -7, 12);
    y = pb.makeBoundIntVar("y", 3, 5);
    z = pb.makeBoundIntVar("z", 22, 59);
    pb.post(pb.times(x,y,z));
    try {
      pb.propagate();
      assertEquals(x.getInf(), 5);
      y.setVal(3);
      pb.propagate();
      assertEquals(x.getInf(), 8);
      assertEquals(z.getSup(), 36);
      assertEquals(z.getInf(), 24);
    } catch (ContradictionException e) {
      assertFalse(true);
    }
  }
  
  }
