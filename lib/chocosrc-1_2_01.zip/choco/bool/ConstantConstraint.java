// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************

package choco.bool;

import choco.AbstractConstraint;
import choco.Constraint;
import choco.ContradictionException;
import choco.Var;

public class ConstantConstraint extends AbstractConstraint {
  private boolean satisfied;

  public ConstantConstraint(boolean value) {
    satisfied = value;
  }

  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  public int getNbVars() {
    return 0;
  }

  public Var getVar(int i) {
    return null;
  }

  public void setVar(int i, Var v) {
    throw new Error("BUG in CSP network management: too large index for setVar");
  }

  public boolean isCompletelyInstantiated() {
    return true;
  }

  public boolean isSatisfied() {
    return satisfied;
  }

  public void propagate() throws ContradictionException {
    if (!satisfied) {
      fail();
    }
  }

  public boolean isConsistent() {
    return satisfied;
  }

  public int assignIndices(AbstractCompositeConstraint root, int i, boolean dynamicAddition) {
    return i;
  }

  public void setConstraintIndex(int i, int idx) {
    throw new UnsupportedOperationException();
  }

  public int getConstraintIdx(int idx) {
    throw new UnsupportedOperationException();
  }

  public final boolean isEquivalentTo(Constraint compareTo) {
    if (compareTo instanceof ConstantConstraint) {
      ConstantConstraint c = (ConstantConstraint) compareTo;
      return (this.satisfied == c.satisfied);
    } else {
      return false;
    }
  }

}
