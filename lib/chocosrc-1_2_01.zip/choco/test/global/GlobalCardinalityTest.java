package choco.test.global;

import choco.Constraint;
import choco.ContradictionException;
import choco.Problem;
import choco.integer.IntDomainVar;
import choco.mem.Environment;
import junit.framework.TestCase;

/**
 * Tests for the GlobalCardinality constraint.
 */
public class GlobalCardinalityTest extends TestCase {
  public void testGCC() {
    System.out.println("Dummy GlobalCardinality test...");
    Problem pb = new Problem(new Environment());

    IntDomainVar peter = pb.makeEnumIntVar("Peter", 0, 1);
    IntDomainVar paul = pb.makeEnumIntVar("Paul", 0, 1);
    IntDomainVar mary = pb.makeEnumIntVar("Mary", 0, 1);
    IntDomainVar john = pb.makeEnumIntVar("John", 0, 1);
    IntDomainVar bob = pb.makeEnumIntVar("Bob", 0, 2);
    IntDomainVar mike = pb.makeEnumIntVar("Mike", 1, 4);
    IntDomainVar julia = pb.makeEnumIntVar("Julia", 2, 4);
    IntDomainVar[] vars = new IntDomainVar[]{peter, paul, mary, john, bob, mike, julia};

    Constraint gcc = pb.globalCardinality(vars, 0, 4, new int[]{1, 1, 1, 0, 0}, new int[]{2, 2, 1, 2, 2});
    pb.post(gcc);

    try {
      pb.propagate();
      assertEquals(2, bob.getInf());
      assertEquals(2, bob.getSup());
      julia.remVal(3);
      pb.propagate();
    } catch (ContradictionException e) {
      assertTrue(false);
    }
  }

  public void tooLongTestBugTPetit1() {
    int n = 10;
    Problem pb = new Problem();
    IntDomainVar[] vars = new IntDomainVar[n];
    for (int i = 0; i < n; i++) {
      vars[i] = pb.makeEnumIntVar("var " + i, 1, n);
    }
    int[] LB = {0, 1, 2, 0, 0, 0, 3, 0, 0, 0};
    int[] UB = {5, 2, 2, 9, 10, 9, 5, 1, 5, 5};
    System.out.println("premiere gcc :");
    Constraint gcc = pb.globalCardinality(vars,
        1,
        10,
        LB,
        UB);

    pb.post(gcc);

    int[] LB2 = {0, 0, 0, 0, 0, 4, 0, 0, 0, 0};
    int[] UB2 = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
    System.out.println("deuxieme gcc :");
    Constraint gcc2 = pb.globalCardinality(vars,
        1,
        10,
        LB2,
        UB2);
    pb.post(gcc2);
    int cpt = 1;
    pb.solve();
    for (int i = 0; i < n; i++) {
      System.out.print("" + vars[i].getVal());
    }
    System.out.println("");
    while (pb.nextSolution() == Boolean.TRUE) {
      cpt++;
      for (int i = 0; i < n; i++) {
        System.out.print("" + vars[i].getVal());
      }
      System.out.println("");
    }

    System.out.println("nb Sol " + cpt);
    assertEquals(12600, cpt);
  }

  public void testBugTPetit2() {
    Problem pb = new Problem();
    IntDomainVar[] vars = new IntDomainVar[2];
    vars[0] = pb.makeEnumIntVar("x " + 0, 1, 3);
    vars[1] = pb.makeEnumIntVar("x " + 1, 2, 7);
    IntDomainVar[] absVars = new IntDomainVar[6];
    for (int i = 0; i < absVars.length; i++) {
      absVars[i] = pb.makeEnumIntVar("V" + i, 0, 6);
    }

    pb.post(pb.or(pb.eq(pb.minus(vars[0], vars[1]), absVars[0]),
        pb.eq(pb.minus(vars[1], vars[0]), absVars[0])));

    int[] LB = {0, 0, 0, 0, 2, 0, 0};
    int[] UB = {6, 6, 6, 6, 6, 6, 6};
    Constraint gcc = pb.globalCardinality(absVars,
        0,
        6,
        LB,
        UB);
    pb.post(gcc);
    pb.solve();
  }

  public void testLatinSquareGCC() {
    System.out.println("Latin Square Test...");
    // Toutes les solutions de n=5 en 90 sec  (161280 solutions)
    final int n = 4;
    final int[] soluces = new int[]{1, 2, 12, 576, 161280};

    // Problem
    Problem myPb = new Problem();

    // Variables
    IntDomainVar[] vars = new IntDomainVar[n * n];
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++) {
        vars[i * n + j] = myPb.makeEnumIntVar("C" + i + "_" + j, 1, n);
      }

    // Constraints
    for (int i = 0; i < n; i++) {
      int[] low = new int[n];
      int[] up = new int[n];
      IntDomainVar[] row = new IntDomainVar[n];
      IntDomainVar[] col = new IntDomainVar[n];
      for (int x = 0; x < n; x++) {
        row[x] = vars[i * n + x];
        col[x] = vars[x * n + i];
        low[x] = 0;
        up[x] = 1;
      }
      myPb.post(myPb.globalCardinality(row, 1, n, low, up));
      myPb.post(myPb.globalCardinality(col, 1, n, low, up));
    }

    myPb.solve(true);

    assertEquals(soluces[n - 1], myPb.getSolver().getNbSolutions());
    System.out.println("LatinSquare Solutions : " + myPb.getSolver().getNbSolutions());
  }
}
