//     ___  ___         PaLM library for Choco system
//    /__ \/ __\        (c) 2001 - 2004 -- Narendra Jussien
//   ____\ |/_____
//  /_____\/_____ \     PalmExplanation based constraint programming tool
// |/   (_)(_)   \|
//       \ /            Version 0.1
//       \ /            January 2004
//       \ /
// ______\_/_______     Contibutors: Fran�ois Laburthe, Hadrien Cambazard, Guillaume Rochart...

package choco.palm.dbt.search;

import java.util.LinkedList;

public class PalmRepairLearn extends PalmLearn {
  protected int maxMoves = 1500;
  protected LinkedList explanations;
  protected int maxSize = 7;
}
