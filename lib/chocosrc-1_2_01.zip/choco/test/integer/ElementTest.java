package choco.test.integer;

import choco.ContradictionException;
import choco.Problem;
import choco.Solver;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: Narendra Jussien
 * Date: 18 mai 2005
 * Time: 16:29:42
 * To change this template use File | Settings | File Templates.
 */
public class ElementTest extends TestCase {
  public void test1() {
    Problem pb = new Problem();
    int[] values = new int[]{1, 2, 0, 4, 3};
    IntDomainVar index = pb.makeEnumIntVar("index", -3, 10);
    IntDomainVar var = pb.makeEnumIntVar("value", -20, 20);
    pb.post(pb.nth(index, values, var));

    pb.solve();
    do {
      System.out.println("index = " + index.getVal());
      System.out.println("value = " + var.getVal());
      assertEquals(var.getVal(), values[index.getVal()]);
    } while (pb.nextSolution().booleanValue());

    assertEquals(5, pb.getSolver().getNbSolutions());
  }

  public void test2() {
    Problem pb = new Problem();
    int[] values = new int[]{1, 2, 0, 4, 3};
    IntDomainVar index = pb.makeEnumIntVar("index", 2, 10);
    IntDomainVar var = pb.makeEnumIntVar("value", -20, 20);
    pb.post(pb.nth(index, values, var));

    pb.solve();
    do {
      System.out.println("index = " + index.getVal());
      System.out.println("value = " + var.getVal());
      assertEquals(var.getVal(), values[index.getVal()]);
    } while (pb.nextSolution().booleanValue());

    assertEquals(3, pb.getSolver().getNbSolutions());
  }

  public void test3() {
    Problem pb = new Problem();
    IntDomainVar X = pb.makeEnumIntVar("X", 0, 5);
    IntDomainVar Y = pb.makeEnumIntVar("Y", 3, 7);
    IntDomainVar Z = pb.makeEnumIntVar("Z", 5, 8);
    IntDomainVar I = pb.makeEnumIntVar("index", -5, 12);
    IntDomainVar V = pb.makeEnumIntVar("V", -3, 20);
    pb.post(pb.nth(I, new IntDomainVar[]{X, Y, Z}, V));
    try {
      pb.propagate();
      assertEquals(I.getInf(), 0);
      assertEquals(I.getSup(), 2);
      assertEquals(V.getInf(), 0);
      assertEquals(V.getSup(), 8);
      V.setSup(5);
      Z.setInf(6);
      pb.propagate();
      assertEquals(I.getSup(), 1);
      Y.remVal(4);
      Y.remVal(5);
      V.remVal(3);
      pb.propagate();
      assertTrue(I.isInstantiatedTo(0));
      V.setSup(2);
      V.remVal(1);
      pb.propagate();
      assertEquals(X.getSup(), 2);
      assertFalse(X.canBeInstantiatedTo(1));
    } catch (ContradictionException e) {
      assertFalse(true);
    }
  }

  public void test4() {
    Problem pb = new Problem();
    IntDomainVar V = pb.makeEnumIntVar("V", 0, 20);
    IntDomainVar X = pb.makeEnumIntVar("X", 10, 50);
    IntDomainVar Y = pb.makeEnumIntVar("Y", 0, 1000);
    IntDomainVar I = pb.makeEnumIntVar("I", 0, 1);
    pb.post(pb.nth(I, new IntDomainVar[]{X, Y}, V));
    try {
      pb.propagate();
      assertFalse(I.isInstantiated());
      Y.setInf(30);
      pb.propagate();
      assertTrue(I.isInstantiatedTo(0));
      assertEquals(V.getInf(), X.getInf());
      assertEquals(V.getSup(), X.getSup());
    } catch (ContradictionException e) {
      assertFalse(true);
    }
  }

  /**
   * testing the initial propagation and the behavior when the index variable is instantiated
   */
  public void test5() {
    Problem pb = new Problem();
    int n = 2;
    IntDomainVar[] vars = new IntDomainVar[n];
    for( int idx = 0; idx < n; idx++) {
        vars[idx] = pb.makeEnumIntVar("t"+idx, 0 + 3*idx, 2 + 3*idx);
    }
    IntDomainVar index = pb.makeEnumIntVar("index", -3, 15);
    IntDomainVar var = pb.makeEnumIntVar("value", -25, 20);

    pb.post(pb.nth(index, vars, var));

    try {
        pb.propagate();
    } catch (ContradictionException e) {
        assertFalse(true);
    }
    assertEquals(0, var.getInf());
    assertEquals(3 * n - 1, var.getSup());
    assertEquals(var.getDomainSize(), 3 * n);
    assertEquals(0, index.getInf());
    assertEquals(n - 1, index.getSup());
    assertEquals(index.getDomainSize(), n);

    assertEquals(0, vars[0].getInf());
    assertEquals(2, vars[0].getSup());
    assertEquals(vars[0].getDomainSize(), 3);
    assertEquals(3, vars[1].getInf());
    assertEquals(5, vars[1].getSup());
    assertEquals(vars[1].getDomainSize(), 3);

    try {
      index.setVal(1);
      pb.propagate();
      assertEquals(3, var.getInf());
      assertEquals(5, var.getSup());
      assertEquals(0, vars[0].getInf());
      assertEquals(2, vars[0].getSup());
      assertEquals(3, vars[1].getInf());
      assertEquals(5, vars[1].getSup());
      vars[0].setVal(0);
      pb.propagate();
    } catch (ContradictionException e) {
        assertFalse(true);
    }
  }

  /**
   *  same as test5, but counting the number of solutions
   */
  public void test6() {
    subtest6(2);
    subtest6(3);
    subtest6(4);
  }

  private void subtest6(int n) {
       Problem pb = new Problem();
     IntDomainVar[] vars = new IntDomainVar[n];
     for( int idx = 0; idx < n; idx++) {
         vars[idx] = pb.makeEnumIntVar("t"+idx, 0 + 3*idx, 2 + 3*idx);
     }
     IntDomainVar index = pb.makeEnumIntVar("index", -3, n + 15);
     IntDomainVar var = pb.makeEnumIntVar("value", -25, 4 * n + 20);

     pb.post(pb.nth(index, vars, var));

     try {
         pb.propagate();
     } catch (ContradictionException e) {
         assertFalse(true);
     }
     assertEquals(0, var.getInf());
     assertEquals(3 * n - 1, var.getSup());
     assertEquals(var.getDomainSize(), 3 * n);
     assertEquals(0, index.getInf());
     assertEquals(n - 1, index.getSup());
     assertEquals(index.getDomainSize(), n);
     for (int i=0; i<n; i++) {
       assertEquals(3*i, vars[i].getInf());
       assertEquals(2 + 3*i, vars[i].getSup());
       assertEquals(vars[i].getDomainSize(), 3);
     }
    Solver.setVerbosity(Solver.SEARCH);
    pb.getSolver().setLoggingMaxDepth(2);
    pb.solveAll();
    Solver.flushLogs();
    assertEquals(Math.round(n * Math.pow(3,n)), pb.getSolver().getNbSolutions());

  }


}
