package choco.test.bool;

import choco.Constraint;
import choco.ContradictionException;
import choco.Problem;
import choco.integer.IntDomainVar;
import choco.mem.PartiallyStoredIntVector;
import junit.framework.TestCase;

import java.util.logging.Logger;

public class CardinalityTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private IntDomainVar x, y, z, n, m;

  protected void setUp() {
    logger.fine("choco.test.bool.CardinalityTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVar("x", 1, 3);
    y = pb.makeBoundIntVar("y", 1, 3);
    z = pb.makeBoundIntVar("z", 1, 3);
    n = pb.makeBoundIntVar("n", 0, 4);
    m = pb.makeBoundIntVar("m", 0, 4);
  }

  protected void tearDown() {
    y = null;
    x = null;
    z = null;
    n = null;
    m = null;
    pb = null;
  }

  public void test1() {
    try {
      logger.finer("test1");
      Constraint c1 = pb.neq(x, y);
      Constraint c2 = pb.geq(y, z);
      Constraint c3 = pb.lt(x, z);
      pb.post(pb.neq(n, m));

      Constraint[] cs = new Constraint[]{c1, c2, c3};
      Constraint cardConst = pb.card(cs, n);
      pb.post(cardConst);
      assertEquals(x.getNbConstraints(), 2);
      assertEquals(x.getVarIndex(0), 0);
      assertEquals(x.getVarIndex(1), 0);
      assertEquals(cardConst.getConstraintIdx(6), PartiallyStoredIntVector.STORED_OFFSET + 1);
    } catch (Exception e) {
      assertFalse(true);
    }
  }

  public void test2() {
    logger.finer("test2");
    Constraint c1 = pb.lt(x, y);
    Constraint c2 = pb.lt(y, z);
    Constraint c3 = pb.lt(z, x);
    Constraint[] cs = new Constraint[]{c1, c2, c3};
    Constraint cardConst = pb.card(cs, n);
    pb.post(cardConst);
    try {
      pb.propagate();
    } catch (ContradictionException e) {
      assertFalse(true);
    }
    try {
      n.setInf(3);
      pb.propagate();
      assertFalse(true);
    } catch (ContradictionException e) {
      assertTrue(true);
    }
  }

   public void test3() {
    logger.finer("test3");
    Constraint c1 = pb.lt(x, y);
    Constraint c2 = pb.lt(y, z);
    Constraint c3 = pb.lt(z, x);
    Constraint[] cs = new Constraint[]{c1, c2, c3};
    Constraint cardConst = pb.card(cs, n);
    pb.post(cardConst);
    try {
      pb.propagate();
    } catch (ContradictionException e) {
      assertFalse(true);
    }
    try {
      n.setInf(2);
      z.setVal(3);
      pb.propagate();
      assertEquals(x.getVal(),1);
      assertEquals(y.getVal(),2);
      assertEquals(n.getVal(),2);
    } catch (ContradictionException e) {
      assertFalse(true);
    }
  }
}
