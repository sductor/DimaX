package choco.set.var;

import choco.AbstractVar;
import choco.ContradictionException;
import choco.mem.PartiallyStoredIntVector;
import choco.mem.PartiallyStoredVector;
import choco.prop.VarEvent;
import choco.set.SetConstraint;
import choco.set.SetVar;
import choco.util.BitSet;
import choco.util.IntIterator;

import java.util.logging.Level;

/**
 * Created by IntelliJ IDEA.
 * User: Hadrien
 * Date: 6 juin 2004
 * Time: 14:21:13
 * To change this template use File | Settings | File Templates.
 */
public class SetVarEvent extends VarEvent {

  /**
   * Constants for the <i>eventType</i> bitvector: index of bit for events on SetVars
   */
  public static final int REMENV = 0;
  public static final int ADDKER = 1;
  public static final int INSTSET = 2;

  public static final int ENVEVENT = 1;
  public static final int KEREVENT = 2;
  public static final int BOUNDSEVENT = 3;
  public static final int INSTSETEVENT = 4;

  public SetVarEvent(AbstractVar var) {
    super(var);
    eventType = EMPTYEVENT;
  }

  public SetVar getIntVar() {
    return (SetVar) modifiedVar;
  }

  /**
   * useful for debugging
   */
  public String toString() {
    return ("VarEvt(" + modifiedVar.toString() + ")[" + eventType + ":"
        + (BitSet.getBit(eventType, REMENV) ? "E" : "")
        + (BitSet.getBit(eventType, ADDKER) ? "K" : "")
        + (BitSet.getBit(eventType, INSTSET) ? "X" : "")
        + "]");
  }

  /**
   * Clears the var: delegates to the basic events.
   */
  public void clear() {
    this.eventType = EMPTYEVENT;
    ((SetDomain) ((SetVar) modifiedVar).getDomain()).getEnveloppeDomain().clearDeltaDomain();
    ((SetDomain) ((SetVar) modifiedVar).getDomain()).getKernelDomain().clearDeltaDomain();
  }


  protected void freeze() {
    ((SetDomain) ((SetVar) modifiedVar).getDomain()).getEnveloppeDomain().freezeDeltaDomain();
    ((SetDomain) ((SetVar) modifiedVar).getDomain()).getKernelDomain().freezeDeltaDomain();
    cause = NOEVENT;
    eventType = 0;
  }

  protected boolean release() {
    return ((SetVar) modifiedVar).getDomain().getEnveloppeDomain().releaseDeltaDomain() &&
        ((SetVar) modifiedVar).getDomain().getKernelDomain().releaseDeltaDomain();
  }

  public boolean getReleased() {
    return ((SetDomain) ((SetVar) modifiedVar).getDomain()).getEnveloppeDomain().getReleasedDeltaDomain() &&
        ((SetDomain) ((SetVar) modifiedVar).getDomain()).getKernelDomain().getReleasedDeltaDomain();
  }

  public IntIterator getEnvEventIterator() {
    return ((SetDomain) ((SetVar) modifiedVar).getDomain()).getEnveloppeDomain().getDeltaIterator();
  }

  public IntIterator getKerEventIterator() {
    return ((SetDomain) ((SetVar) modifiedVar).getDomain()).getKernelDomain().getDeltaIterator();
  }

  /**
   * Propagates the event through calls to the propagation engine.
   *
   * @return true if the event has been fully propagated (and can thus be discarded), false otherwise
   * @throws choco.ContradictionException
   */
  public boolean propagateEvent() throws ContradictionException {
    if (logger.isLoggable(Level.FINER))
      logger.finer("propagate " + this.toString());
    // first, mark event
    int evtType = eventType;
    int evtCause = cause;
    freeze();

    if (evtType >= INSTSETEVENT)
      propagateInstEvent(evtCause);
    else if (evtType <= BOUNDSEVENT) {
      if (evtType == ENVEVENT)
        propagateEnveloppeEvents(evtCause);
      else if (evtType == KEREVENT)
        propagateKernelEvents(evtCause);
      else if (evtType == BOUNDSEVENT) {
        propagateKernelEvents(evtCause);
        propagateEnveloppeEvents(evtCause);
      }
    }

    // last, release event
    return release();
  }

  /**
   * Propagates the instantiation event
   */
  public void propagateInstEvent(int evtCause) throws ContradictionException {
    AbstractVar v = getModifiedVar();
    PartiallyStoredVector constraints = v.getConstraintVector();
    PartiallyStoredIntVector indices = v.getIndexVector();

    for (IntIterator cit = constraints.getIndexIterator(); cit.hasNext();) {
      int idx = cit.next();
      if (idx != evtCause) {
        SetConstraint c = (SetConstraint) constraints.get(idx);
        if (c.isActive()) {
          int i = indices.get(idx);
          c.awakeOnInst(i);
        }
      }
    }
  }

  /**
   * Propagates a set of value removals
   */
  public void propagateKernelEvents(int evtCause) throws ContradictionException {
    AbstractVar v = getModifiedVar();
    PartiallyStoredVector constraints = v.getConstraintVector();
    PartiallyStoredIntVector indices = v.getIndexVector();

    for (IntIterator cit = constraints.getIndexIterator(); cit.hasNext();) {
      int idx = cit.next();
      if (idx != evtCause) {
        SetConstraint c = (SetConstraint) constraints.get(idx);
        if (c.isActive()) {
          int i = indices.get(idx);
          c.awakeOnkerAdditions(i, this.getKerEventIterator());
        }
      }
    }
  }

  /**
   * Propagates a set of value removals
   */
  public void propagateEnveloppeEvents(int evtCause) throws ContradictionException {
    AbstractVar v = getModifiedVar();
    PartiallyStoredVector constraints = v.getConstraintVector();
    PartiallyStoredIntVector indices = v.getIndexVector();

    for (IntIterator cit = constraints.getIndexIterator(); cit.hasNext();) {
      int idx = cit.next();
      if (idx != evtCause) {
        SetConstraint c = (SetConstraint) constraints.get(idx);
        if (c.isActive()) {
          int i = indices.get(idx);
          c.awakeOnEnvRemovals(i, this.getEnvEventIterator());
        }
      }
    }
  }

}
