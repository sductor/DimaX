// **************************************************
// *                   CHOCO                        *
// *  An open-source Constraint Programming system  *
// *  primarily designed for research & education   *
// *                                                *
// * Copyright (C) F. Laburthe, 1999-2005           *
// *                                                *
// * Contributors: Thierry Benoist,                 *
// *               Hadrien Cambazard,               *
// *               Etienne Gaudin,                  *
// *               Narendra Jussien,                *
// *               Francois Laburthe,               *
// *               Michel Lemaitre,                 *
// *               Guillaume Rochart ...            *
// **************************************************

package choco;


/**
 * An interface for all objects from constraint programs.
 */
public interface Entity {
  /**
   * Retrieves the problem of the entity.
   */

  public AbstractProblem getProblem();

  /**
   * pretty printing of the object. This String is not constant and may depend on the context.
   *
   * @return a readable string representation of the object
   */
  public String pretty();

}

