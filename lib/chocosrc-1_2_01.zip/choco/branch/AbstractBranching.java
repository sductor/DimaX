// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.branch;

import choco.search.AbstractGlobalSearchSolver;

import java.util.logging.Logger;

public abstract class AbstractBranching {
  /**
   * the main control object (responsible for the whole exploration, while the branching object
   * is responsible only at the choice point level
   */
  protected AbstractGlobalSearchSolver manager;
  /**
   * a link towards the next branching object (once this one is exhausted)
   */
  protected AbstractBranching nextBranching;
  /**
   * an object for logging trace statements
   */
  protected static Logger logger = Logger.getLogger("choco.search.branching");

  protected static String LOG_DOWN_MSG = "down branch ";
  protected static String LOG_UP_MSG = "up branch ";
  protected static String[] LOG_DECISION_MSG = {""};

  public void setSolver(AbstractGlobalSearchSolver s) {
    manager = s;
  }

  /**
   * Gets the next branching.
   */
  public AbstractBranching getNextBranching() {
    return nextBranching;
  }

  /**
   * Sets the next branching.
   */
  public void setNextBranching(AbstractBranching nextBranching) {
    this.nextBranching = nextBranching;
  }

  /**
   * used for logging messages related to the search tree
   * @param branchIndex
   * @return an string that will be printed between the branching object and the branch index
   * Suggested implementations return LOG_DECISION_MSG[0] or LOG_DECISION_MSG[branchIndex]
   */
  public abstract String getDecisionLogMsg(int branchIndex);
}
