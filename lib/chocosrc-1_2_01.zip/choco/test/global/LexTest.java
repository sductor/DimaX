package choco.test.global;

import choco.AbstractProblem;
import choco.Problem;
import choco.integer.IntDomainVar;
import choco.integer.search.RandomIntValSelector;
import choco.integer.search.RandomIntVarSelector;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: Hadrien
 * Date: 5 avr. 2006
 * Time: 08:42:43
 * To change this template use File | Settings | File Templates.
 */
public class LexTest extends TestCase {

    public void testLessLexq() {
        for (int seed = 0; seed < 5; seed++) {
            AbstractProblem pb = new Problem();
            int n1 = 8;
            int k = 2;
            IntDomainVar[] vs1 = new IntDomainVar[n1/2];
            IntDomainVar[] vs2 = new IntDomainVar[n1/2];
            for (int i = 0; i < n1/2; i++) {
                vs1[i] = pb.makeEnumIntVar("" + i, 0, k);
                vs2[i] = pb.makeEnumIntVar("" + i, 0, k);
            }
            pb.post(pb.lexeq(vs1, vs2));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb, seed));
            pb.getSolver().setValSelector(new RandomIntValSelector(seed));
            pb.solveAll();
            int kpn = (int) Math.pow(k + 1, n1 / 2);
            assertEquals(pb.getSolver().getNbSolutions(),(kpn*(kpn + 1)/2));
            //if (pb.getSolver().getNbSolutions() != kpn*(kpn + 1)/2 )
            //throw new Error("nbSol " + pb.getSolver().getNbSolutions() + " should be " + (kpn*(kpn + 1)/2));
            System.out.println("NbSol : " + pb.getSolver().getNbSolutions() + " =? " + (kpn*(kpn + 1)/2));
       }
   }


   public static void testLex() {
        for (int seed = 0; seed < 5; seed++) {
            AbstractProblem pb = new Problem();
            int n1 = 8;
            int k = 2;
            IntDomainVar[] vs1 = new IntDomainVar[n1/2];
            IntDomainVar[] vs2 = new IntDomainVar[n1/2];
            for (int i = 0; i < n1/2; i++) {
                vs1[i] = pb.makeEnumIntVar("" + i, 0, k);
                vs2[i] = pb.makeEnumIntVar("" + i, 0, k);
            }
            pb.post(pb.lex(vs1,vs2));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb, seed));
            pb.getSolver().setValSelector(new RandomIntValSelector(seed));
            //pb.getSolver().setValIterator(new IncreasingTrace());
            pb.solveAll();
            assertEquals(3240,pb.getSolver().getNbSolutions());
            System.out.println("NbSol : " + pb.getSolver().getNbSolutions() + " =? 3240");
       }
   }
}
