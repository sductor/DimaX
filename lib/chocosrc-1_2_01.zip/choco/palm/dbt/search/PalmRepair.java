//     ___  ___         PaLM library for Choco system
//    /__ \/ __\        (c) 2001 - 2004 -- Narendra Jussien
//   ____\ |/_____
//  /_____\/_____ \     PalmExplanation based constraint programming tool
// |/   (_)(_)   \|
//       \ /            Version 0.1
//       \ /            January 2004
//       \ /
// ______\_/_______     Contibutors: Fran�ois Laburthe, Hadrien Cambazard, Guillaume Rochart...

package choco.palm.dbt.search;

import choco.Constraint;

import java.util.Collections;

/**
 * A repairing algorithm.
 */

public class PalmRepair extends PalmAbstractSolverTool {

  /**
   * Selects a decision to undo for repairing a contradiction. In this default implementation, it
   * selects the minimal constraints in the provided explain w.r.t. the BetterConstraintComparator
   * order.
   *
   * @param expl The explain of the contradiction.
   */

  public Constraint selectDecisionToUndo(choco.palm.dbt.explain.PalmExplanation expl) {
    return (Constraint) Collections.min(expl.toSet(), new choco.palm.dbt.explain.BetterConstraintComparator());
  }
}
