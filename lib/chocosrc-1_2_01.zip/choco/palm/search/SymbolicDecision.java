package choco.palm.search;

import choco.palm.PalmConstraint;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public interface SymbolicDecision extends PalmConstraint {

  /**
   * Returns the number identifying the current branch.
   */

  public int getBranch();

}
