package choco.palm.cbj;

import choco.AbstractProblem;
import choco.Solver;
import choco.integer.IntDomainVar;
import choco.integer.search.IncreasingDomain;
import choco.integer.search.MinDomain;
import choco.integer.var.IntDomainVarImpl;
import choco.palm.cbj.search.*;
import choco.real.RealVar;
import choco.real.search.AbstractRealOptimize;
import choco.real.search.RealBranchAndBound;
import choco.real.search.RealOptimizeWithRestarts;
import choco.search.NodeLimit;
import choco.search.TimeLimit;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public class JumpSolver extends Solver {

  public JumpSolver(AbstractProblem pb) {
    super(pb);
  }

  public void generateSearchSolver(AbstractProblem pb) {
    problem = pb;
    if (null == objective) {
      solver = new JumpGlobalSearchSolver(this.getProblem());
    } else if (restart) {
      if (objective instanceof IntDomainVar)
        solver = new JumpRestartOptimizer((IntDomainVarImpl) objective, doMaximize);
      else if (objective instanceof RealVar)
        solver = new RealOptimizeWithRestarts((RealVar) objective, doMaximize);
    } else {
      if (objective instanceof IntDomainVar)
        solver = new JumpBranchAndBoundOptimizer((IntDomainVarImpl) objective, doMaximize);
      else if (objective instanceof RealVar)
        solver = new RealBranchAndBound((RealVar) objective, doMaximize);
    }
    solver.stopAtFirstSol = firstSolution;

    solver.limits.add(new TimeLimit(solver, timeLimit));
    solver.limits.add(new NodeLimit(solver, nodeLimit));

    generateGoal(pb);
  }

  protected void generateGoal(AbstractProblem pb) {
    if (varSelector == null) varSelector = new MinDomain(pb);
    if (valIterator == null && valSelector == null) valIterator = new IncreasingDomain();
    if (valIterator != null)
      attachGoal(new JumpAssignVar(varSelector, valIterator));
    else
      attachGoal(new JumpAssignVar(varSelector, valSelector));
  }

  public Number getOptimumValue() {
    if (solver instanceof JumpAbstractOptimizer) {
      return new Integer(((JumpAbstractOptimizer) solver).getBestObjectiveValue());
    } else if (solver instanceof AbstractRealOptimize) {
      return new Double(((AbstractRealOptimize) solver).getBestObjectiveValue());
    }
    return null;
  }
}
