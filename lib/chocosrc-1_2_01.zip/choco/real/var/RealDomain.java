package choco.real.var;

import choco.Entity;
import choco.real.RealInterval;

/**
 * An interface for real variable domains.
 */
public interface RealDomain extends Entity, RealInterval {
  public void clearDeltaDomain();

  boolean releaseDeltaDomain();

  void freezeDeltaDomain();

  boolean getReleasedDeltaDomain();

  void silentlyAssign(RealInterval i);
}
