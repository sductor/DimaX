// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* File choco.test.search.SolveTest.java, last modified by Francois 2 d�c. 2003 23:49:19 */
package choco.test.search;

import choco.Constraint;
import choco.Problem;
import choco.Propagator;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.logging.Logger;

public class SolveTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar x;
  private choco.integer.IntDomainVar y;

  protected void setUp() {
    logger.fine("StoredInt Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVar("X", 0, 5);
    y = pb.makeBoundIntVar("Y", 0, 1);
  }

  protected void tearDown() {
    x = null;
    y = null;
    pb = null;
  }

  /**
   * test the solution count for an infeasible problem
   */
  public void test1() {
    logger.finer("test1");
    pb.post(pb.eq(x, 2));
    pb.post(pb.eq(x, 3));
    pb.solve(false);
    assertEquals(pb.getSolver().getNbSolutions(), 0);
    assertEquals(pb.isFeasible(), Boolean.FALSE);
  }

  /**
   * test the solution count for instantiated problem
   */
  public void test2() {
    logger.finer("test2");
    pb.post(pb.eq(x, 2));
    pb.post(pb.eq(y, 1));
    pb.solve(true);
    assertEquals(pb.isFeasible(), Boolean.TRUE);
    assertEquals(pb.getSolver().getNbSolutions(), 1);
  }

  /**
   * test the solution count for a simple one-variable problem
   */
  public void test3() {
    logger.finer("test3");
    pb.post(pb.eq(y, 1));
    pb.solve(true);
    assertEquals(pb.isFeasible(), Boolean.TRUE);
    assertEquals(pb.getSolver().getNbSolutions(), 6);
  }

  /**
   * test the solution count for a simple two-variable problem
   */
  public void test4() {
    logger.finer("test4");
    pb.solve(true);
    assertEquals(pb.isFeasible(), Boolean.TRUE);
    assertEquals(pb.getSolver().getNbSolutions(), 12);
  }

  /**
   * test the incremental solve.
   */
  public void test5() {
    logger.finer("test5");
    pb.solve();
    while (pb.nextSolution() == Boolean.TRUE) {
    }
    pb.printRuntimeSatistics();
    assertEquals(pb.isFeasible(), Boolean.TRUE);
    assertEquals(pb.getSolver().getNbSolutions(), 12);
    //Logger.getLogger("choco").getHandlers()[0].flush();
  }


  public static void testBugTPetit150205() {
    int n = 3;
    Problem pb = new Problem();
    IntDomainVar[] vars = new IntDomainVar[n];
    for (int i = 0; i < n; i++) {
      vars[i] = pb.makeEnumIntVar("debut " + i + " :" + i, 1, n);
    }
    ArrayList list = new ArrayList();
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (i != j) {
          Constraint c = pb.neq(vars[i], vars[j]);
          list.add(c);
          pb.post(c);
        }
      }
    }

    int FAILPB = 0; // try any value but 0 => no pb
    for (int j = 0; j < 5; j++) {
      for (int i = 0; i < list.size(); i++) {
        Constraint constraint = (Constraint) list.get(i);
        ((Propagator) constraint).constAwake(true);
      }

      pb.worldPush();

      Constraint ct = pb.eq(vars[0], 1);
      Constraint ct2 = pb.eq(vars[1], 1);
      if (j == FAILPB) { // no solution
        pb.post(ct);
        pb.post(ct2);
      }


      pb.solveAll();
      if (pb.getSolver().getNbSolutions() > 0) {
        //System.out.println("Nb Solution = " + pb.getSolver().getNbSolutions());
        for (int i = 0; i < n; i++) {
          System.out.print(vars[i].getVal() + " ");
        }
        System.out.println();
      }
      if (FAILPB == j) assertEquals(pb.getSolver().getNbSolutions(), 0);
      if (FAILPB != j) assertEquals(pb.getSolver().getNbSolutions(), 6);
      pb.worldPopUntil(0);

      /*   if (j == FAILPB) {
           ct.delete();
           ct2.delete();
         } */
      //Logger.getLogger("choco").getHandlers()[0].flush();
    }

  }
}

