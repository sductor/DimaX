package choco.real.var;

import choco.AbstractProblem;
import choco.AbstractVar;
import choco.ContradictionException;
import choco.real.RealInterval;
import choco.real.RealMath;
import choco.real.RealVar;
import choco.real.exp.RealIntervalConstant;

import java.util.List;
import java.util.Set;

/**
 * An implementation of real variables using RealDomain domains.
 */
public class RealVarImpl extends AbstractVar implements RealVar {
  protected RealDomain domain;

  public RealVarImpl(AbstractProblem pb, String name, double a, double b) {
    super(pb, name);
    this.domain = new RealDomainImpl(this, a, b);
    this.event = new RealVarEvent(this);
  }

  public String toString() {
    return this.name + "[" + this.getInf() + "," + this.getSup() + "]";
  }

  public RealInterval getValue() {
    return new RealIntervalConstant(getInf(), getSup());
  }

  public RealDomain getDomain() {
    return domain;
  }

  public void silentlyAssign(RealInterval i) {
    domain.silentlyAssign(i);
  }

  public double getInf() {
    return domain.getInf();
  }

  public double getSup() {
    return domain.getSup();
  }

  public void intersect(RealInterval interval) throws ContradictionException {
    this.domain.intersect(interval);
  }

  public void intersect(RealInterval interval, int index) throws ContradictionException {
    this.domain.intersect(interval, index);
  }

  public void fail() throws ContradictionException {
    fail();
  }

  public boolean isInstantiated() {
    return RealMath.isCanonical(this, this.problem.getPrecision());
  }

  public void tighten() {
  }

  public void project() {
  }

  public List subExps(List l) {
    l.add(this);
    return l;
  }

  public Set collectVars(Set s) {
    s.add(this);
    return s;
  }

  public boolean isolate(RealVar var, List wx, List wox) {
    if (this == var) {
      return true;
    } else {
      return false;
    }
  }
}
