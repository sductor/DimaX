package choco.global;

import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.integer.constraints.AbstractLargeIntConstraint;
import choco.util.IntIterator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;


/**
 * Created by IntelliJ IDEA.
 * Author: Hadrien
 * Date: 29 juil. 2005
 */
public class Cumulative extends AbstractLargeIntConstraint {

    public static boolean debug = false;
    public static boolean taskInter = true;


    protected int nbTask;
    protected int capaMax;

    /**
     * first data structure of the sweep algorithm
     * event point series : list of Event
     */
    protected ArrayList<Event> events;
    protected Comparator evtComp;

    /**
     * data structures of the sweep algorithm
     * sweep line status
     */
    protected int sum_height;
    protected IntList taskToPrune;


    //protected int[] heights;

    private static IntDomainVar[] createAllVarsArray(IntDomainVar[] starts,
                                                     IntDomainVar[] ends,
                                                     IntDomainVar[] duration,
                                                     IntDomainVar[] heights) {
      int n = starts.length;
      IntDomainVar[] ret = new IntDomainVar[4*n];
      for (int i = 0; i < n; i++) {
          ret[4 * i] = starts[i];
          ret[4 * i + 1] = ends[i];
          ret[4 * i + 2] = duration[i];
          ret[4 * i + 3] = heights[i];
      }
      return ret;
    }

    public Cumulative(IntDomainVar[] starts, IntDomainVar[] ends, IntDomainVar[] duration, IntDomainVar[] heights, int Capa) {
        super(createAllVarsArray(starts, ends, duration,heights));
        //heights = h;
        nbTask = starts.length;
        Xtasks = new ArrayList<Integer>();
        Ytasks = new ArrayList<Integer>();

        for (int i = 0; i < nbTask; i++) {
            Xtasks.add(i);
            Ytasks.add(i);
        }
        taskToPrune = new IntList(nbTask);
        taskToPrune.reInit();
        events = new ArrayList<Event>();
        evtComp = new EventComparator();
        stComp = new StartingDateComparator();
        endComp = new EndingDateComparator();
        contributions = new int[nbTask];
        this.capaMax = Capa;
    }

    public IntDomainVar getStart(int i) {
        return vars[i*4];
    }

    public IntDomainVar getEnd(int i) {
        return vars[i*4 + 1];
    }

    public IntDomainVar getDuration(int i) {
        return vars[i*4 + 2];
    }

    public IntDomainVar getHeight(int i) {
        return vars[i*4 + 3];
    }

    public void awakeOnBounds(int varIndex) throws ContradictionException {
        this.constAwake(false);
    }

    public void awakeOnRemovals(int idx, IntIterator deltaDomain) throws ContradictionException {
        this.constAwake(false);
    }

    public void awakeOnInst(int idx) throws ContradictionException {
        this.constAwake(false);
    }

    public void propagate() throws ContradictionException {
        filter();
    }

    public boolean isSatisfied() {
        throw new Error("isSatisfied not yet implemented on choco.global.Cumulative");
    }

    public Boolean isEntailed() {
        throw new Error("isEntailed not yet implemented on choco.global.Cumulative");
    }

    public boolean isScheduled(int i) {
        return getStart(i).isInstantiated() && getEnd(i).isInstantiated() && getDuration(i).isInstantiated() && getHeight(i).isInstantiated();
    }

    /**
     * return earliest start of task i
     * @param i
     */
    public int getES(int i) {
        return getStart(i).getInf();
      }

    /**
     * return latest start of task i
     * @param i
     */
    public int getLS(int i) {
       return getStart(i).getSup();
    }

    /**
     * return earliest end of task i
     * @param i
     */
    public int getEE(int i) {
      return getEnd(i).getInf();
    }

    /**
     * return latest start of task i
     * @param i
     */
    public int getLE(int i) {
       return getEnd(i).getSup();
    }


    public boolean generateEvents() {
        events.clear();
        boolean someprof = false;
        for (int i = 0; i < nbTask; i++) {
            if (getStart(i).getSup() < getEnd(i).getInf()) { // t has a compulsory part
                final int h = getHeight(i).getInf();
                events.add(new Event(Event.CHECKPROF, i, getStart(i).getSup(), h)); // for variable heights : min(h)
                events.add(new Event(Event.CHECKPROF, i, getEnd(i).getInf(), -h));  // for variable heights : min(h)
                someprof=true;
                //events.add(new Event(Event.CHECK, i, t.start().getSup(), 1));
                //events.add(new Event(Event.CHECK, i, t.end().getInf(), -1));
            }
            if (!isScheduled(i)) {
                events.add(new Event(Event.PRUNING, i, getStart(i).getInf(), 0));
            }
        }
        return someprof;
    }

    /*protected int getConsumption(TaskVar t, int ridx) {
        int hsure = t.getConsumption(resourceUsed);
        int h = ((Integer) (t.getListHeight().get(ridx))).intValue();
        if (h != hsure) throw new Error("indexing problem");
        return h;
    }*/

    protected int[] contributions;
    protected boolean fixPoint;

    public void initMainIteration() {
        fixPoint = false;
        taskToPrune.reInit();
    }

    public void filter() throws ContradictionException {
        if (debug) System.out.println("========= Filtering on resource =======");
        updateCompulsoryPart();
        fixPoint = true;
        while (fixPoint) {  // apply the sweep process until saturation
            initMainIteration();
            if (debug) System.out.println("------ Start sweep for resource ========");
            sweep();
        }
        if (taskInter) {
            if (debug) System.out.println("------ Task interval for resource ========");
            taskIntervals();
            if (debug) System.out.println("------ Filtering OK for =========");
        }
    }

    public void sweep() throws ContradictionException {
        if (generateEvents()) { // events are start/end of mandatory parts (CHECKPROF event) and start of tasks (PRUNING events)
            Collections.sort(events, evtComp);  // sort event by date
            for (int i = 0; i < contributions.length; i++)
                contributions[i] = 0;
            sum_height = 0;
            int d = events.get(0).getDate(); // get first date
            Iterator it = events.iterator(); // about to iterate on events
            while (it.hasNext()) {
                Event evt = (Event) it.next();  // get next event
                if (debug) System.out.println("" + evt + " s:" + sum_height);
                //----- profile event
                if (evt.type != Event.PRUNING) {
                    if (d != evt.date) { // if event of a different date it means that all profile events <= d have been taken into account
                        if (sum_height > capaMax) // if capa is exceeded : contradiction (but how could sum_height be > 0 is nb_task=0 ?)
                            this.fail();
                        prune(d, evt.date - 1); // caution: prune is called on non-pruning events !
                        d = evt.date; // register new date
                    }
                    if (evt.type == Event.CHECKPROF) { // if part of the profile  (this test will always be true since type!=pruning
                        sum_height += evt.prof_increment; // consuming a certain quantity
                        contributions[evt.task] += evt.prof_increment; // update contribution too
                    } else
                        throw new Error("" + evt.type + " should not be used");
                }
                //----- pruning event
                else {
                    taskToPrune.add(evt.task); // if not a pruning event then add the new task to the list of "active" tasks (taskToPrune is decreased in the prune method ?)
                }
            }
            if (sum_height > capaMax) // how is it possible since all events have been covered ??
                this.fail();
            prune(d, d);
            // Insert the last pruning phase
        }
    }

    public void prune(int low, int up) throws ContradictionException {
        while (taskToPrune.hasNext()) { // prune all task that intersect with the current time
            int idx = taskToPrune.next();
            IntDomainVar s =  getStart(idx);
            IntDomainVar e =  getEnd(idx);
            IntDomainVar d =  getDuration(idx);
            IntDomainVar h =  getHeight(idx);
            int height = h.getInf();
            // we remove contribution of task v and imagine that if overlaps some date between low and up (plateau of the current profile)
            if (sum_height - contributions[idx] + height > capaMax) { // exclure celles qui overlap for sure
                if (debug) System.out.println("START PRUNING ON TASK " + idx + " BETWEEN [" + low + "," + up + "]");
                if (debug) System.out.println("s:" + sum_height + " c:" + contributions[idx] + " h:" + height + " CAPA:" + capaMax);
                // call removeInterval on start since some starting time are not possible anymore
                fixPoint |= s.removeInterval(low - d.getInf() + 1, up, cIndices[idx * 4]);
                //TODO: this second removeInterval is only relevant if a duration variable exists
                fixPoint |= e.removeInterval(low + 1, up + d.getInf(), cIndices[idx * 4 + 1]);
                int maxd = Math.max(Math.max(low - s.getInf(), 0), e.getSup() - up - 1);
                fixPoint |= d.updateSup(maxd, cIndices[idx * 4 + 2]); // t is either to the left or to the right of this interval -> it has an impact on the duration !
                if (debug) System.out.println("END PRUNING ON " + idx);
                //Mise � jour de TaskToPrune: on retire les taches telles que t.end().sup() < date
                if (e.getSup() <= up + 1) taskToPrune.remove();
            }
            // prune the height of tasks that overlap for sure
            if (e.getInf()>low && s.getSup() <= up && d.getInf() > 0) { 
                fixPoint |= h.updateSup(capaMax - (sum_height - contributions[idx]), cIndices[idx * 4 + 3]);
            }
            //inclure ici le pruning sur la hauteur pour les taches qui sont dans [low,up]
        }
        taskToPrune.restart();
    }

    public void updateCompulsoryPart() throws ContradictionException {
        for (int i = 0; i < nbTask; i++) {
            fixPoint = true;
            while (fixPoint) {
                fixPoint = false;
                IntDomainVar s =  getStart(i);
                IntDomainVar e =  getEnd(i);
                IntDomainVar d =  getDuration(i);
                fixPoint |= s.updateInf(e.getInf() - d.getSup(), cIndices[4 * i]);
                fixPoint |= s.updateSup(e.getSup() - d.getInf(), cIndices[4 * i]);
                fixPoint |= e.updateInf(s.getInf() + d.getInf(), cIndices[4 * i + 1]);
                fixPoint |= e.updateSup(s.getSup() + d.getSup(), cIndices[4 * i + 1]);
                fixPoint |= d.updateInf(e.getInf() - s.getSup(), cIndices[4 * i + 2]);
                fixPoint |= d.updateSup(e.getSup() - s.getInf(), cIndices[4 * i + 2]);
            }
        }
        if (debug) {
            System.out.println("Initial state for resource ");
            for (int i = 0; i < nbTask; i++) {
                System.out.println("start="+ getStart(i) +"; duration="+ getDuration(i));
            }
        }
    }

    protected ArrayList<Integer> Xtasks; // tasks sorted by increasing starting date
    protected Comparator stComp;

    protected ArrayList<Integer> Ytasks; // tasks sorted by increasing ending date
    protected Comparator endComp;

    // Todo : generalize task interval to edge finding
    public void taskIntervals() throws ContradictionException {
        Collections.sort(Xtasks, stComp);  // ce tri de devrait pas etre utile (THB:sauf si dur�e variables ?)
        Collections.sort(Ytasks, endComp);
        for (int i = 0; i < nbTask; i++) {
            //Y[i].sup is the right bound of the interval
            int D = getEnd(Ytasks.get(i)).getSup(); // D is the end of this interval
            long energy = 0; // energy
            for (int j = nbTask - 1; j >= 0; j--) {
                int t = Xtasks.get(j);
                // we consider interval  (X[j].inf .... Y[i].sup)
                //NB: if not fully included in this interval it may have a mandatory part in this interval anyway ?
                //if (t.end().getSup() <= D) { // if this task is fully included in this interval
                int h = getHeight(t).getInf();
                int minDur = getDuration(t).getInf();
                long e = minDur * h;
                if (getLE(t) > D) e = Math.min(e, (D - getLS(t)) * h); // if task can end after D, part (or all) of it can be outside
                if (e > 0) { // e<=0 means that task can be fully outside
                    energy += e;
                    long diff = D - getES(t);           //avoid integer overload
                    long capaMaxDiff = capaMax * diff;
                    if (capaMaxDiff < energy) this.fail();
                }
            }
        }
    }


    protected class EventComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            int date1 = ((Event) o1).getDate();
            int date2 = ((Event) o2).getDate();

            if (date1 < date2)
                return -1;
            else if (date1 == date2) {
                return 0;
            } else
                return 1;
        }
    }

    protected class StartingDateComparator implements Comparator {

        public StartingDateComparator() {
        }

        public int compare(Object o1, Object o2) {
            int date1 = getStart((Integer) o1).getInf();
            int date2 = getStart((Integer) o2).getInf();

            if (date1 < date2)
                return -1;
            else if (date1 == date2) {
                return 0;
            } else
                return 1;
        }
    }

    protected class EndingDateComparator implements Comparator {

        public EndingDateComparator() {
        }

        public int compare(Object o1, Object o2) {
            int date1 = getEnd((Integer) o1).getSup();
            int date2 = getEnd((Integer) o2).getSup();

            if (date1 < date2)
                return -1;
            else if (date1 == date2) {
                return 0;
            } else
                return 1;
        }
    }

    protected class Event {
        public final static int CHECK = 0;  // never used
        public final static int PROFILE = 1; // never used
        public final static int PRUNING = 2;
        public final static int CHECKPROF = 3;

        public int type; // among CHECK, PROFILE, CHECKPROFILE and PRUNING
        public int task;
        public int date;
        public int prof_increment;


        public Event(int type, int task, int date, int pinc) {
            this.type = type;
            this.task = task;
            this.date = date;
            this.prof_increment = pinc;
        }

        public String toString() {
            String typ = "";
            switch (type) {
                case 0 :
                    typ = "CHECK  ";
                    break;
                case 1 :
                    typ = "PROFILE";
                    break;
                case 2 :
                    typ = "PRUNING";
                    break;
                case 3 :
                    typ = "CHECK-PROFILE";
                    break;
            }
            return "[" + typ + " on task " + task + " at date " + date + " with incH " + prof_increment + "]";
        }

        public int getType() {
            return type;
        }

        public int getTask() {
            return task;
        }

        public int getDate() {
            return date;
        }

        public int getProfIncrement() {
            return prof_increment;
        }

    }

    protected class IntList implements choco.util.IntIterator {
        protected int[] content;
        protected int size;
        protected int currentIdx = 0;

        public IntList(int size) {
            this.size = size;
            this.content = new int[size];
        }

        public boolean hasNext() {
            return currentIdx < size;
        }

        public int next() {
            return content[currentIdx++];
        }

        /**
         * Read the next element wihtout incrementing
         */
        public int read() {
            return content[currentIdx];
        }

        public void remove() {
            if (currentIdx != size) {
                currentIdx--; // back to last returned
                content[currentIdx] = content[size - 1]; // reinsert the last one where we remove one
            }
            size--;
        }

        public int getSize() {
            return size;
        }

        public void restart() {
            currentIdx = 0;
        }

        public void reInit() {
            size = 0;
            restart();
        }

        public void delete(int val) {
            for (restart(); hasNext();) {
                if (next() == val) remove();
            }
        }

        public void add(int v) {
            if (size == content.length)
                throw new IllegalArgumentException("" + size);
            else
                content[size++] = v;
        }

        public void addAll(IntList l2) {
            addAllBut(l2, 0, true);
        }

        public void addAllBut(IntList l2, int i) {
            addAllBut(l2, i, false);
        }

        protected void addAllBut(IntList l2, int i, boolean ignoreBut) {
            final int n1 = this.getSize();
            final int n2 = l2.getSize();
            if (n1 + n2 > content.length)
                throw new IllegalArgumentException();
            else
                for (l2.restart(); l2.hasNext();) {
                    final int v = l2.next();
                    if (ignoreBut || v != i) add(v);
                }
        }
    }

}
