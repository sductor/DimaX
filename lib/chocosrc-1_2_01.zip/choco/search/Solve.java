// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.search;

import choco.AbstractProblem;


public class Solve extends AbstractGlobalSearchSolver {
  public Solve(AbstractProblem pb) {
    super(pb);
  }

}
