// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco;

import choco.mem.Environment;
import choco.mem.PartiallyStoredIntVector;
import choco.mem.PartiallyStoredVector;
import choco.prop.VarEvent;
import choco.util.IntIterator;

import java.util.Iterator;

/**
 * An abstract class for all implementations of domain variables.
 */
public abstract class AbstractVar extends AbstractEntity implements Var {

  /**
   * A name may be associated to each variable.
   */
  protected String name;

  /**
   * The variable var associated to this variable.
   */
  protected VarEvent event;


  /**
   * The list of constraints (listeners) observing the variable.
   */
  protected PartiallyStoredVector constraints;


  /**
   * List of indices encoding the constraint network.
   * <i>v.indices[i]=j</i> means that v is the j-th variable
   * of its i-th constraint.
   */
  protected PartiallyStoredIntVector indices;

  /**
   * Initializes a new variable.
   * @param pb The problem this variable belongs to
   * @param name The name of the variable
   */
  public AbstractVar(final AbstractProblem pb, final String name) {
    super(pb);
    this.name = name;
    Environment env = pb.getEnvironment();
    constraints = env.makePartiallyStoredVector();
    indices = env.makePartiallyStoredIntVector();
  }

  /**
   * Useful for debugging.
   * @return the name of the variable
   */
  public String toString() {
    return name;
  }

  /**
   * Returns the variable event.
   * @return the event responsible for propagating variable modifications
   */
  public VarEvent getEvent() {
    return event;
  }


  /**
   * Retrieve the constraint i involving the variable.
   * Be careful to use the correct constraint index (constraints are not
   * numbered from 0 to number of constraints minus one, since an offset
   * is used for some of the constraints).
   * @param i the number of the required constraint
   * @return the constraint number i according to the variable
   */
  public Constraint getConstraint(final int i) {
    return ((Constraint) constraints.get(i));
  }


  /**
   * Returns the number of constraints involving the variable.
   * @return the number of constraints containing this variable
   */
  public int getNbConstraints() {
    return constraints.size();
  }

  /**
   * Access the data structure storing constraints involving a given variable.
   * @return the backtrackable structure containing the constraints
   */
  public PartiallyStoredVector getConstraintVector() {
    return constraints;
  }

  /**
   * Access the data structure storing indices associated to constraints 
   * involving a given variable.
   * @return the indices associated to this variable in each constraint
   */
  public PartiallyStoredIntVector getIndexVector() {
    return indices;
  }

  /**
   * Returns the index of the variable in its constraint i.
   * @param constraintIndex the index of the constraint 
   * (among all constraints linked to the variable)
   * @return the index of the variable
   */
  public int getVarIndex(final int constraintIndex) {
    return indices.get(constraintIndex);
  }

  /**
   * Removes (permanently) a constraint from the list of constraints 
   * connected to the variable.
   * @param c the constraint that should be removed from the list this variable
   * maintains.
   */
  public void eraseConstraint(final Constraint c) {
    constraints.remove(c);
  }

  // ============================================
  // Managing Listeners.
  // ============================================

  /**
   * Adds a new constraints on the stack of constraints
   * the addition can be dynamic (undone upon backtracking) or not.
   * @param c the constraint to add
   * @param varIdx the variable index accrding to the added constraint
   * @param dynamicAddition states if the addition is definitic (cut) or
   * subject to backtracking (standard constraint)
   * @return the index affected to the constraint according to this variable
   */
  public int addConstraint(final Constraint c, final int varIdx,
                           final boolean dynamicAddition) {
    int constraintIdx = -1;
    if (dynamicAddition) {
      constraintIdx = constraints.add(c);
      indices.add(varIdx);
    } else {
      constraintIdx = constraints.staticAdd(c);
      indices.staticAdd(varIdx);
    }
    return constraintIdx;
  }

  /**
   * This methods should be used if one want to access the different constraints
   * currently posted on this variable.
   *
   * Indeed, since indices are not always
   * consecutive, it is the only simple way to achieve this.
   *
   * Warning ! this iterator should not be used to remove elements.
   * The <code>remove</code> method throws an
   * <code>UnsupportedOperationException</code>.
   *
   * @return an iterator over all constraints involving this variable
   */
  public Iterator getConstraintsIterator() {
    return new Iterator() {
      IntIterator indices = constraints.getIndexIterator();

      public boolean hasNext() {
        return indices.hasNext();
      }

      public Object next() {
        return constraints.get(indices.next());
      }

      public void remove() {
        throw new UnsupportedOperationException();
      }
    };
  }
}
