package choco.real.exp;

import choco.AbstractEntity;
import choco.AbstractProblem;
import choco.ContradictionException;
import choco.mem.Environment;
import choco.mem.StoredFloat;
import choco.prop.VarEvent;
import choco.real.RealExp;
import choco.real.RealInterval;

/**
 * A compound expression depending on other terms.
 */
public abstract class AbstractRealCompoundTerm extends AbstractEntity implements RealExp {
  protected StoredFloat inf;
  protected StoredFloat sup;

  public AbstractRealCompoundTerm(AbstractProblem pb) {
    super(pb);
    Environment env = pb.getEnvironment();
    inf = env.makeFloat(Double.NEGATIVE_INFINITY);
    sup = env.makeFloat(Double.POSITIVE_INFINITY);
  }

  public String toString() {
    return "[" + inf.get() + "," + sup.get() + "]";
  }

  public double getInf() {
    return inf.get();
  }

  public double getSup() {
    return sup.get();
  }

  public void intersect(RealInterval interval) throws ContradictionException {
    intersect(interval, VarEvent.NOCAUSE);
  }

  public void intersect(RealInterval interval, int index) throws ContradictionException {
    if (interval.getInf() > inf.get()) inf.set(interval.getInf());
    if (interval.getSup() < sup.get()) sup.set(interval.getSup());
    if (inf.get() > sup.get()) {
      problem.getPropagationEngine().raiseContradiction();
    }
  }
}
