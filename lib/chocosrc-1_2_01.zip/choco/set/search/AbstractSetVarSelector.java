package choco.set.search;

import choco.AbstractVar;
import choco.search.AbstractSearchHeuristic;
import choco.set.SetVar;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public abstract class AbstractSetVarSelector extends AbstractSearchHeuristic implements SetVarSelector {

  /**
   * a specific array of SetVars from which the object seeks the one with smallest domain
   */
  protected SetVar[] vars;

  public AbstractVar selectVar() {
    return (AbstractVar) selectSetVar();
  }

}
