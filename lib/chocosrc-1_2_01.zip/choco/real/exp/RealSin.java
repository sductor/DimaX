package choco.real.exp;

import choco.AbstractProblem;
import choco.ContradictionException;
import choco.real.RealExp;
import choco.real.RealInterval;
import choco.real.RealMath;

/**
 * Expression evaluatiing the cos of its only one sub-expression.
 */
public class RealSin extends AbstractRealUnTerm {
  public RealSin(AbstractProblem pb, RealExp exp1) {
    super(pb, exp1);
  }

  public void tighten() {
    RealInterval res = RealMath.sin(exp1);
    inf.set(res.getInf());
    sup.set(res.getSup());
  }

  public void project() throws ContradictionException {
    RealInterval res = RealMath.asin_wrt(this, exp1);
    if (res.getInf() > res.getSup()) {
      problem.getPropagationEngine().raiseContradiction();
    }
    exp1.intersect(res);
  }
}
