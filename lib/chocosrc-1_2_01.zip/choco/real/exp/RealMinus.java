package choco.real.exp;

import choco.AbstractProblem;
import choco.ContradictionException;
import choco.real.RealExp;
import choco.real.RealInterval;
import choco.real.RealMath;

/**
 * An expression modelling a substraction.
 */
public class RealMinus extends AbstractRealBinTerm {
  public RealMinus(AbstractProblem pb, RealExp exp1, RealExp exp2) {
    super(pb, exp1, exp2);
  }

  public void tighten() {
    RealInterval res = RealMath.sub(exp1, exp2);
    inf.set(res.getInf());
    sup.set(res.getSup());
  }

  public void project() throws ContradictionException {
    exp1.intersect(RealMath.add(this, exp2));
    exp2.intersect(RealMath.sub(exp1, this));
  }
}
