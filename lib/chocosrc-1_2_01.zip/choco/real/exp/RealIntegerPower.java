package choco.real.exp;

import choco.AbstractProblem;
import choco.ContradictionException;
import choco.real.RealExp;
import choco.real.RealInterval;
import choco.real.RealMath;

public class RealIntegerPower extends AbstractRealUnTerm {
  protected int power;

  public RealIntegerPower(AbstractProblem pb, RealExp exp1, int power) {
    super(pb, exp1);
    this.power = power;
  }

  public void tighten() {
    RealInterval res = RealMath.iPower(exp1, power);
    inf.set(res.getInf());
    sup.set(res.getSup());
  }

  public void project() throws ContradictionException {
    RealInterval res = RealMath.iRoot(this, power, exp1);
    if (res.getInf() > res.getSup()) {
      problem.getPropagationEngine().raiseContradiction();
    }
    exp1.intersect(res);
  }
}
