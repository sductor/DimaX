// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.constraints.extension;

import choco.AbstractConstraint;
import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.util.IntIterator;

public class AC3BinConstraint extends CspBinConstraint {

  public AC3BinConstraint(IntDomainVar x0, IntDomainVar x1, BinRelation rela) {//int[][] consistencyMatrice) {
    super(x0, x1, rela);
  }

  public Object clone() {
    return new AC3BinConstraint(this.v0, this.v1, this.relation);
  }

  // updates the support for all values in the domain of v1, and remove unsupported values for v1
  public void reviseV1() throws ContradictionException {
    int nbs = 0;
    IntIterator itv1 = v1.getDomain().getIterator();
    while (itv1.hasNext()) {
      IntIterator itv0 = v0.getDomain().getIterator();
      int val1 = itv1.next();
      while (itv0.hasNext()) {
        int val0 = itv0.next();
        if (relation.isConsistent(val0, val1)) {
          nbs += 1;
          break;
        }
      }
      if (nbs == 0) v1.removeVal(val1, cIdx1);
      nbs = 0;
    }
  }

  // updates the support for all values in the domain of v0, and remove unsupported values for v0
  public void reviseV0() throws ContradictionException {
    int nbs = 0;
    IntIterator itv0 = v0.getDomain().getIterator();
    while (itv0.hasNext()) {
      IntIterator itv1 = v1.getDomain().getIterator();
      int val0 = itv0.next();
      while (itv1.hasNext()) {
        int val1 = itv1.next();
        if (relation.isConsistent(val0, val1)) {
          nbs += 1;
          break;
        }
      }
      if (nbs == 0) v0.removeVal(val0, cIdx0);
      nbs = 0;
    }
  }

  // standard filtering algorithm initializing all support counts
  public void propagate() throws ContradictionException {
    reviseV0();
    reviseV1();
  }

  public void awakeOnRem(int idx, int x) throws ContradictionException {
    if (idx == 0) {
      reviseV1();
    } else
      reviseV0();
  }
  //propagate();

  /**
   * Propagation when a minimal bound of a variable was modified.
   *
   * @param idx The index of the variable.
   * @throws choco.ContradictionException
   */
  // Note: these methods could be improved by considering for each value, the minimal and maximal support considered into the count
  public void awakeOnInf(int idx) throws ContradictionException {
    if (idx == 0) {
      reviseV1();
    } else
      reviseV0();
  }

  public void awakeOnSup(int idx) throws ContradictionException {
    if (idx == 0) {
      reviseV1();
    } else
      reviseV0();
  }


  /**
   * Propagation when a variable is instantiated.
   *
   * @param idx The index of the variable.
   * @throws choco.ContradictionException
   */

  public void awakeOnInst(int idx) throws ContradictionException {
    if (idx == 0) {
      reviseV1();
    } else
      reviseV0();
  }


  public AbstractConstraint opposite() {
    BinRelation rela2 = (BinRelation) ((ConsistencyRelation) relation).getOpposite();
    AbstractConstraint ct = new AC3BinConstraint(v0, v1, rela2);
    return ct;
  }

  /**
   * Checks if the listeners must be checked or must fail.
   */

}
