// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.search;

import choco.AbstractProblem;
import choco.branch.AbstractIntBranching;
import choco.branch.IntBranching;

/**
 * An abstract class for all heuristics (variable, value, branching heuristics) related to search
 */
public class AbstractSearchHeuristic {
  /**
   * the branching object owning the variable heuristic
   */
  protected AbstractIntBranching branching;

  /**
   * the problem to which the heuristic is related
   */
  protected AbstractProblem problem;

  /**
   * each IVarSelector is associated to a branching strategy
   *
   * @return the associated branching strategy
   */
  public IntBranching getBranching() {
    return branching;
  }
}
