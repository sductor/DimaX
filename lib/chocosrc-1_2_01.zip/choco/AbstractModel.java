// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco;

import choco.bool.*;
import choco.integer.IntDomainVar;
import choco.integer.IntExp;
import choco.integer.IntVar;
import choco.integer.constraints.IntLinComb;
import choco.integer.constraints.extension.BinRelation;
import choco.integer.constraints.extension.CouplesTable;
import choco.integer.constraints.extension.LargeRelation;
import choco.integer.constraints.extension.TuplesTable;
import choco.integer.var.IntTerm;
import choco.mem.PartiallyStoredVector;
import choco.real.RealExp;
import choco.real.RealMath;
import choco.real.RealVar;
import choco.real.exp.RealIntervalConstant;
import choco.set.SetVar;

import java.util.*;

public abstract class AbstractModel implements IntModeler, BoolModeler { // extends AbstractEntity
  /**
   * A constant denoting the true constraint (always satisfied)
   */
  public final Constraint TRUE = new ConstantConstraint(true);
  /**
   * A constant denoting the false constraint (never satisfied)
   */
  public final Constraint FALSE = new ConstantConstraint(false);
  /**
   * A constant denoting a null integer term. This is useful to make the API
   * more robust, for instance with linear expression with null coefficients.
   */
  public final IntTerm ZERO = new IntTerm(0);
  /**
   * All the constraints of the problem.
   */
  protected PartiallyStoredVector constraints;

  /**
   * All the search intVars in the problem.
   */
  protected ArrayList intVars;
  /**
   * All the set intVars in the problem.
   */
  protected ArrayList setVars;
  /**
   * All the float vars in the problem.
   */
  protected ArrayList floatVars;
  /**
   * The variable modelling the objective function
   */
  protected IntVar objective;
  /**
   * Maximization / Minimization problem
   */
  protected boolean doMaximize;
  /**
   * The number of constraints for the current problem.
   */
  protected int nbConstraint;

  public AbstractModel() {
    intVars = new ArrayList();
    nbConstraint = 0;
    setVars = new ArrayList();
    floatVars = new ArrayList();
  }

  /**
   * Creates a new search variable with an enumerated domain
   *
   * @param name the name of the variable
   * @param min  minimal allowed value (included in the domain)
   * @param max  maximal allowed value (included in the domain)
   * @return the variable
   */
  public IntDomainVar makeEnumIntVar(String name, int min, int max) {
    IntDomainVar v = createIntVar(name, IntDomainVar.LIST, min, max);
    intVars.add(v);
    return v;
  }

  /**
   * Creates a new search variable with an enumerated domain
   *
   * @param name   the name of the variable
   * @param values allowed in the domain (may be unsorted, but not with duplicates !)
   * @return the variable
   */
  public IntDomainVar makeEnumIntVar(String name, int[] values) {
    int[] values2 = new int[values.length];
    System.arraycopy(values, 0, values2, 0, values.length);
    Arrays.sort(values2);
    IntDomainVar v = createIntVar(name, values2);
    intVars.add(v);
    return v;
  }

  /**
   * Creates a new search variable with an interval domain
   *
   * @param name the name of the variable
   * @param min  minimal allowed value (included in the domain)
   * @param max  maximal allowed value (included in the domain)
   * @return the variable
   */
  public IntDomainVar makeBoundIntVar(String name, int min, int max) {
    IntDomainVar v = createIntVar(name, IntDomainVar.BOUNDS, min, max);
    intVars.add(v);
    return v;
  }

  public IntDomainVar makeBoundIntVar(String name, int min, int max, boolean toAdd) {
    IntDomainVar v = createIntVar(name, IntDomainVar.BOUNDS, min, max);
    if (toAdd) intVars.add(v);
    return v;
  }

  public final void setMinimizationObjective(IntVar obj) {
    objective = obj;
    doMaximize = false;
  }

  public final void setMaximizationObjective(IntVar obj) {
    objective = obj;
    doMaximize = true;
  }

  /**
   * Creates a one dimensional array of integer variables
   *
   * @param name the name of the array (a prefix shared by all individual IntVars)
   * @param dim  the number of entries
   * @param min  the minimal domain value for all variables in the array
   * @param max  the maximal domain value for all variables in the array
   */
  public IntDomainVar[] makeBoundIntVarArray(String name, int dim, int min, int max) {
    IntDomainVar[] res = new IntDomainVar[dim];
    for (int i = 0; i < dim; i++) {
      res[i] = makeBoundIntVar(name + "[" + String.valueOf(i) + "]", min, max);
    }
    return res;
  }

  /**
   * Creates a one dimensional array of integer variables
   *
   * @param name the name of the array (a prefix shared by all individual IntVars)
   * @param dim1 the number of entries for the first index
   * @param dim2 the number of entries for the second index
   * @param min  the minimal domain value for all variables in the array
   * @param max  the maximal domain value for all variables in the array
   */
  public IntDomainVar[][] makeBoundIntVarArray(String name, int dim1, int dim2, int min, int max) {
    IntDomainVar[][] res = new IntDomainVar[dim1][dim2];
    for (int i = 0; i < dim1; i++) {
      for (int j = 0; j < dim2; j++) {
        res[i][j] = makeBoundIntVar(name + "[" + String.valueOf(i) + ", " + String.valueOf(j) + "]", min, max);
      }
    }
    return res;
  }

  /**
   * Creates a one dimensional array of integer variables
   *
   * @param name the name of the array (a prefix shared by all individual IntVars)
   * @param dim  the number of entries
   * @param min  the minimal domain value for all variables in the array
   * @param max  the maximal domain value for all variables in the array
   */
  public IntDomainVar[] makeEnumIntVarArray(String name, int dim, int min, int max) {
    IntDomainVar[] res = new IntDomainVar[dim];
    for (int i = 0; i < dim; i++) {
      res[i] = makeEnumIntVar(name + "[" + String.valueOf(i) + "]", min, max);
    }
    return res;
  }

  /**
   * Creates a one dimensional array of integer variables
   *
   * @param name the name of the array (a prefix shared by all individual IntVars)
   * @param dim1 the number of entries for the first index
   * @param dim2 the number of entries for the second index
   * @param min  the minimal domain value for all variables in the array
   * @param max  the maximal domain value for all variables in the array
   */
  public IntDomainVar[][] makeEnumIntVarArray(String name, int dim1, int dim2, int min, int max) {
    IntDomainVar[][] res = new IntDomainVar[dim1][dim2];
    for (int i = 0; i < dim1; i++) {
      for (int j = 0; j < dim2; j++) {
        res[i][j] = makeEnumIntVar(name + "[" + String.valueOf(i) + ", " + String.valueOf(j) + "]", min, max);
      }
    }
    return res;
  }

  /**
   * Creates a real variable.
   *
   * @param name
   * @param min
   * @param max
   * @return the new object (RealVar)
   */
  public RealVar makeRealVar(String name, double min, double max) {
    RealVar v = createRealVal(name, min, max);
    floatVars.add(v);
    return v;
  }

  /**
   * Creates an anonymous real variable.
   */
  public RealVar makeRealVar(double inf, double sup) {
    return makeRealVar("", inf, sup);
  }

  /**
   * Creates an unbounded real variable.
   */
  public RealVar makeRealVar(String name) {
    return makeRealVar(name, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
  }

  /**
   * Creates a set variable.
   *
   * @param name
   * @param a    : the first value of the initial enveloppe
   * @param b    : the last value of the initial enveloppe
   * @return the new object (RealVar)
   */
  public SetVar makeSetVar(String name, int a, int b) {
    SetVar v = createSetVar(name, a, b);
    setVars.add(v);
    return v;
  }

  // TODO: can be optimized (no need to attach propagation events)
  public IntVar makeConstantIntVar(String name, int val) {
    return makeBoundIntVar(name, val, val);
  }

  public IntVar makeConstantIntVar(int val) {
    return makeConstantIntVar("", val);
  }

  /**
   * Creates a simple linear term from one coefficient and one variable
   *
   * @param a the coefficient
   * @param x the variable
   * @return the term
   */
  public IntExp mult(int a, IntExp x) {
    if (a != 0 && x != ZERO) {
      IntTerm t = new IntTerm(1);
      t.setCoefficient(0, a);
      t.setVariable(0, (IntVar) x);
      return t;
    } else {
      return ZERO;
    }
  }

  /**
   * Utility method for constructing a term from two lists of variables, list of coeffcicients and constants
   *
   * @param coeffs1 coefficients from the first term
   * @param vars1   variables from the first term
   * @param cste1   constant from the fisrt term
   * @param coeffs2 coefficients from the second term
   * @param vars2   variables from the second term
   * @param cste2   constant from the second term
   * @return the term (a fresh one)
   */
  protected IntExp plus(int[] coeffs1, IntVar[] vars1, int cste1, int[] coeffs2, IntVar[] vars2, int cste2) {
    int n1 = vars1.length;
    int n2 = vars2.length;
    IntTerm t = new IntTerm(n1 + n2);
    for (int i = 0; i < n1; i++) {
      t.setVariable(i, vars1[i]);
      t.setCoefficient(i, coeffs1[i]);
    }
    for (int i = 0; i < n2; i++) {
      t.setVariable(n1 + i, vars2[i]);
      t.setCoefficient(n1 + i, coeffs2[i]);
    }
    t.setConstant(cste1 + cste2);
    return t;
  }

  /**
   * Adding two terms one to another
   *
   * @param t1 first term
   * @param t2 second term
   * @return the term (a fresh one)
   */
  public IntExp plus(IntExp t1, IntExp t2) {
    if (t1 == ZERO) return t2;
    if (t2 == ZERO) return t1;
    if (t1 instanceof IntTerm) {
      if (t2 instanceof IntTerm) {
        return plus(((IntTerm) t1).getCoefficients(),
            ((IntTerm) t1).getVariables(),
            ((IntTerm) t1).getConstant(),
            ((IntTerm) t2).getCoefficients(),
            ((IntTerm) t2).getVariables(),
            ((IntTerm) t2).getConstant());
      } else if (t2 instanceof IntVar) {
        return plus(((IntTerm) t1).getCoefficients(),
            ((IntTerm) t1).getVariables(),
            ((IntTerm) t1).getConstant(),
            new int[]{1},
            new IntVar[]{(IntVar) t2},
            0);
      } else {
        throw new Error("IntExp not a term, not a var");
      }
    } else if (t1 instanceof IntVar) {
      if (t2 instanceof IntTerm) {
        return plus(new int[]{1},
            new IntVar[]{(IntVar) t1},
            0,
            ((IntTerm) t2).getCoefficients(),
            ((IntTerm) t2).getVariables(),
            ((IntTerm) t2).getConstant());
      } else if (t2 instanceof IntVar) {
        IntTerm t = new IntTerm(2);
        t.setCoefficient(0, 1);
        t.setCoefficient(1, 1);
        t.setVariable(0, (IntVar) t1);
        t.setVariable(1, (IntVar) t2);
        t.setConstant(0);
        return t;
      } else
        throw new Error("IntExp not a term, not a var");
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public IntExp plus(IntExp t, int c) {
    if (t == ZERO) {
      IntTerm t2 = new IntTerm(0);
      t2.setConstant(c);
      return t2;
    } else if (t instanceof IntTerm) {
      IntTerm t2 = new IntTerm((IntTerm) t);
      t2.setConstant(((IntTerm) t).getConstant() + c);
      return t2;
    } else if (t instanceof IntVar) {
      IntTerm t2 = new IntTerm(1);
      t2.setCoefficient(0, 1);
      t2.setVariable(0, (IntVar) t);
      t2.setConstant(c);
      return t2;
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public final IntExp plus(int c, IntExp t1) {
    return plus(t1, c);
  }

  /**
   * Subtracting two terms one from another
   *
   * @param t1 first term
   * @param t2 second term
   * @return the term (a fresh one)
   */
  public IntExp minus(IntExp t1, IntExp t2) {
    if (t1 == ZERO) return mult(-1, t2);
    if (t2 == ZERO) return t1;
    if (t1 instanceof IntTerm) {
      if (t2 instanceof IntTerm) {
        int[] coeffs2 = ((IntTerm) t2).getCoefficients();
        int n2 = coeffs2.length;
        int[] oppcoeffs2 = new int[n2];
        for (int i = 0; i < n2; i++) {
          oppcoeffs2[i] = -(coeffs2[i]);
        }
        return plus(((IntTerm) t1).getCoefficients(),
            ((IntTerm) t1).getVariables(),
            ((IntTerm) t1).getConstant(),
            oppcoeffs2,
            ((IntTerm) t2).getVariables(),
            -((IntTerm) t2).getConstant());
      } else if (t2 instanceof IntVar) {
        return plus(((IntTerm) t1).getCoefficients(),
            ((IntTerm) t1).getVariables(),
            ((IntTerm) t1).getConstant(),
            new int[]{-1},
            new IntVar[]{(IntVar) t2},
            0);
      } else {
        throw new Error("IntExp not a term, not a var");
      }
    } else if (t1 instanceof IntVar) {
      if (t2 instanceof IntTerm) {
        int[] coeffs2 = ((IntTerm) t2).getCoefficients();
        int n2 = coeffs2.length;
        int[] oppcoeffs2 = new int[n2];
        for (int i = 0; i < n2; i++) {
          oppcoeffs2[i] = -(coeffs2[i]);
        }
        return plus(new int[]{1},
            new IntVar[]{(IntVar) t1},
            0,
            oppcoeffs2,
            ((IntTerm) t2).getVariables(),
            -((IntTerm) t2).getConstant());
      } else if (t2 instanceof IntVar) {
        IntTerm t = new IntTerm(2);
        t.setCoefficient(0, 1);
        t.setCoefficient(1, -1);
        t.setVariable(0, (IntVar) t1);
        t.setVariable(1, (IntVar) t2);
        t.setConstant(0);
        return t;
      } else
        throw new Error("IntExp not a term, not a var");
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public IntExp minus(IntExp t, int c) {
    if (t == ZERO) {
      IntTerm t2 = new IntTerm(0);
      t2.setConstant(-c);
      return t2;
    } else if (t instanceof IntTerm) {
      IntTerm t2 = new IntTerm((IntTerm) t);
      t2.setConstant(((IntTerm) t).getConstant() - c);
      return t2;
    } else if (t instanceof IntVar) {
      IntTerm t2 = new IntTerm(1);
      t2.setCoefficient(0, 1);
      t2.setVariable(0, (IntVar) t);
      t2.setConstant(-c);
      return t2;
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public IntExp minus(int c, IntExp t) {
    if (t instanceof IntTerm) {
      IntTerm t1 = (IntTerm) t;
      int n = t1.getSize();
      IntTerm t2 = new IntTerm(n);
      for (int i = 0; i < n; i++) {
        t2.setCoefficient(i, -t1.getCoefficient(i));
        t2.setVariable(i, t1.getVariable(i));
      }
      t2.setConstant(c - t1.getConstant());
      return t2;
    } else if (t instanceof IntVar) {
      IntTerm t2 = new IntTerm(1);
      t2.setCoefficient(0, -1);
      t2.setVariable(0, (IntVar) t);
      t2.setConstant(c);
      return t2;
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  /**
   * Building a term from a scalar product of coefficients and variables
   *
   * @param lc the array of coefficients
   * @param lv the array of variables
   * @return the term
   */
  public IntExp scalar(int[] lc, IntVar[] lv) {
    int n = lc.length;
    assert(lv.length == n);
    IntTerm t = new IntTerm(n);
    for (int i = 0; i < n; i++) {
      t.setCoefficient(i, lc[i]);
      if (lv[i] instanceof IntVar) {
        t.setVariable(i, (IntVar) lv[i]);
      } else {
        throw new Error("unknown kind of IntDomainVar");
      }
    }
    return t;
  }

  /**
   * Building a term from a scalar product of coefficients and variables
   *
   * @param lv the array of variables
   * @param lc the array of coefficients
   * @return the term
   */
  public final IntExp scalar(IntVar[] lv, int[] lc) {
    return scalar(lc, lv);
  }

  /**
   * Building a term from a sum of integer expressions
   *
   * @param lv the array of integer expressions
   * @return the term
   */
  public IntExp sum(IntExp[] lv) {
    int n = lv.length;
    IntTerm t = new IntTerm(n);
    for (int i = 0; i < n; i++) {
      t.setCoefficient(i, 1);
      if (lv[i] instanceof IntVar) {
        t.setVariable(i, (IntVar) lv[i]);
      } else {
        throw new Error("unexpected kind of IntExp");
      }
    }
    return t;
  }

  /**
   * Creates a constraint by stating that a term is not equal than a constant
   *
   * @param x the expression
   * @param c the constant
   * @return the linear disequality constraint
   */
  public Constraint neq(IntExp x, int c) {
    if (x instanceof IntTerm) {
      IntTerm t = (IntTerm) x;
      if ((t.getSize() == 2) && (t.getCoefficient(0) + t.getCoefficient(1) == 0)) {
        return createNotEqualXYC(t.getVariable(0), t.getVariable(1), (c - t.getConstant()) / t.getCoefficient(0));
      } else {
        return makeIntLinComb(((IntTerm) x).getVariables(), ((IntTerm) x).getCoefficients(), -(c), IntLinComb.NEQ);
      }
    } else if (x instanceof IntVar) {
      return createNotEqualXC((IntVar) x, c);
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public final Constraint neq(int c, IntExp x) {
    return neq(x, c);
  }

  public Constraint neq(IntExp x, IntExp y) {
    if (x instanceof IntTerm) {
      return neq(minus(x, y), 0);
    } else if (x instanceof IntVar) {
      if (y instanceof IntTerm) {
        return neq(minus(x, y), 0);
      } else if (y instanceof IntVar) {
        return createNotEqualXYC((IntVar) x, (IntVar) y, 0);
      } else if (y == null) {
        return neq(x, 0);
      } else {
        throw new Error("IntExp not a term, not a var");
      }
    } else if (x == null) {
      return neq(0, y);
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public Constraint geq(IntExp x, IntExp y) {
    if (x instanceof IntVar && y instanceof IntVar) {
      return createGreaterOrEqualXYC((IntVar) x, (IntVar) y, 0);
    } else if ((x instanceof IntTerm || x instanceof IntVar) && (y instanceof IntTerm || y instanceof IntVar)) {
      return geq(this.minus(x, y), 0);
    } else if (y == null) {
      return geq(x, 0);
    } else if (x == null) {
      return leq(x, 0);
    } else {
      throw new Error("IntExp not a good exp");
    }
  }

  // rewriting utility: remove all null coefficients
  // TODO: could be improved to remove duplicates (variables that would appear twice in the linear combination)
  public static int countNonNullCoeffs(int[] lcoeffs) {
    int nbNonNull = 0;
    for (int i = 0; i < lcoeffs.length; i++) {
      if (lcoeffs[i] != 0)
        nbNonNull++;
    }
    return nbNonNull;
  }

  protected Constraint makeIntLinComb(IntVar[] lvars, int[] lcoeffs, int c, int linOperator) {
    int nbNonNullCoeffs = countNonNullCoeffs(lcoeffs);
    int nbPositiveCoeffs = 0;
    int[] sortedCoeffs = new int[nbNonNullCoeffs];
    IntVar[] sortedVars = new IntVar[nbNonNullCoeffs];

    int j = 0;
    // fill it up with the coefficients and variables in the right order
    for (int i = 0; i < lvars.length; i++) {
      if (lcoeffs[i] > 0) {
        sortedVars[j] = lvars[i];
        sortedCoeffs[j] = lcoeffs[i];
        j++;
      }
    }
    nbPositiveCoeffs = j;

    for (int i = 0; i < lvars.length; i++) {
      if (lcoeffs[i] < 0) {
        sortedVars[j] = lvars[i];
        sortedCoeffs[j] = lcoeffs[i];
        j++;
      }
    }
    return createIntLinComb(sortedVars, sortedCoeffs, nbPositiveCoeffs, c, linOperator);
  }

  /**
   * Creates a constraint by stating that a term is greater or equal than a constant
   *
   * @param x the expression
   * @param c the constant
   * @return the linear inequality constraint
   */
  public Constraint geq(IntExp x, int c) {
    if (x instanceof IntTerm) {
      IntTerm t = (IntTerm) x;
      if ((t.getSize() == 2) && (t.getCoefficient(0) + t.getCoefficient(1) == 0)) {
        if (t.getCoefficient(0) > 0) {
          return createGreaterOrEqualXYC(t.getVariable(0), t.getVariable(1), (c - t.getConstant()) / t.getCoefficient(0));
        } else {
          return createGreaterOrEqualXYC(t.getVariable(1), t.getVariable(0), (c - t.getConstant()) / t.getCoefficient(1));
        }
      } else {
        return makeIntLinComb(((IntTerm) x).getVariables(), ((IntTerm) x).getCoefficients(), ((IntTerm) x).getConstant() - c, IntLinComb.GEQ);
      }
    } else if (x instanceof IntVar) {
      return createGreaterOrEqualXC((IntVar) x, c);
    } else if (x == null) {
      if (c <= 0) {
        return TRUE;
      } else {
        return FALSE;
      }
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public Constraint geq(int c, IntExp x) {
    if (x instanceof IntTerm) {
      int[] coeffs = ((IntTerm) x).getCoefficients();
      int n = coeffs.length;
      int[] oppcoeffs = new int[n];
      for (int i = 0; i < n; i++) {
        oppcoeffs[i] = -(coeffs[i]);
      }
      return makeIntLinComb(((IntTerm) x).getVariables(), oppcoeffs, c - ((IntTerm) x).getConstant(), IntLinComb.GEQ);
    } else if (x instanceof IntVar) {
      return createLessOrEqualXC((IntVar) x, c);
    } else if (x == null) {
      if (c <= 0) {
        return TRUE;
      } else {
        return FALSE;
      }
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public final Constraint gt(IntExp x, IntExp y) {
    return geq(minus(x, y), 1);
  }

  public final Constraint gt(IntExp x, int c) {
    return geq(x, c + 1);
  }

  public final Constraint gt(int c, IntExp x) {
    return geq(c - 1, x);
  }

  public Constraint eq(IntExp x, IntExp y) {
    if (x instanceof IntVar && y instanceof IntVar) {
      return createEqualXYC((IntVar) x, (IntVar) y, 0);
    } else if ((x instanceof IntTerm || x instanceof IntVar) && (y instanceof IntTerm || y instanceof IntVar)) {
      return eq(this.minus(x, y), 0);
    } else if (x == null) {
      return eq(0, y);
    } else if (y == null) {
      return eq(x, 0);
    } else {
      throw new Error("IntExp not a good exp");
    }
  }

  public Constraint eq(IntExp x, int c) {
    if (x instanceof IntTerm) {
      IntTerm t = (IntTerm) x;
      int nbvars = t.getSize();
      int c2 = c - t.getConstant();
      if (t.getSize() == 1) {
        if (c2 % t.getCoefficient(0) == 0)
          return createEqualXC(t.getVariable(0), c2 / t.getCoefficient(0));
        else
          return FALSE;
      } else if ((nbvars == 2) && (t.getCoefficient(0) + t.getCoefficient(1) == 0)) {
        return createEqualXYC(t.getVariable(0), t.getVariable(1), c2 / t.getCoefficient(0));
      } else {
        return makeIntLinComb(t.getVariables(), t.getCoefficients(), -(c2), IntLinComb.EQ);
      }
    } else if (x instanceof IntVar) {
      return createEqualXC((IntVar) x, c);
    } else {
      throw new Error("IntExp not a term, not a var");
    }
  }

  public final Constraint eq(int c, IntExp x) {
    return eq(x, c);
  }

  public final Constraint leq(IntExp x, int c) {
    return geq(c, x);
  }

  public final Constraint leq(int c, IntExp x) {
    return geq(x, c);
  }

  public final Constraint leq(IntExp x, IntExp y) {
    return geq(y, x);
  }

  public final Constraint lt(IntExp x, int c) {
    return gt(c, x);
  }

  public final Constraint lt(int c, IntExp x) {
    return gt(x, c);
  }

  public final Constraint lt(IntExp x, IntExp y) {
    return gt(y, x);
  }

  public Constraint times(IntVar x, IntVar y, IntVar z) {
    return createTimesXYZ(x,y,z);
  }

  // ------------------------ constraints over reals
  /**
   * Makes an equation from an expression and a constantt interval. It is used by all methods building
   * constraints. This is  useful for subclassing this modeller  for another kind of problem (like PaLM).
   *
   * @param exp The expression
   * @param cst The interval this expression should be in
   */
  public Constraint makeEquation(RealExp exp, RealIntervalConstant cst) {
    // Collect the variables
    Set collectedVars = new HashSet();
    exp.collectVars(collectedVars);
    RealVar[] tmpVars = new RealVar[0];
    tmpVars = (RealVar[]) collectedVars.toArray(tmpVars);
    return createEquation(tmpVars, exp, cst);
  }

  /**
   * Eqality constraint.
   */
  public Constraint eq(RealExp exp1, RealExp exp2) {
    if (exp1 instanceof RealIntervalConstant) {
      return makeEquation(exp2, (RealIntervalConstant) exp1);
    } else if (exp2 instanceof RealIntervalConstant) {
      return makeEquation(exp1, (RealIntervalConstant) exp2);
    } else {
      return makeEquation(minus(exp1, exp2), cst(0.0));
    }
  }

  public Constraint eq(RealExp exp, double cst) {
    return makeEquation(exp, cst(cst));
  }

  public Constraint eq(double cst, RealExp exp) {
    return makeEquation(exp, cst(cst));
  }

  /**
   * Inferority constraint.
   */
  public Constraint leq(RealExp exp1, RealExp exp2) {
    if (exp1 instanceof RealIntervalConstant) {
      return makeEquation(exp2, cst(exp1.getInf(), Double.POSITIVE_INFINITY));
    } else if (exp2 instanceof RealIntervalConstant) {
      return makeEquation(exp1, cst(Double.NEGATIVE_INFINITY, exp2.getSup()));
    } else {
      return makeEquation(minus(exp1, exp2), cst(Double.NEGATIVE_INFINITY, 0.0));
    }
  }

  public Constraint leq(RealExp exp, double cst) {
    return makeEquation(exp, cst(Double.NEGATIVE_INFINITY, cst));
  }

  public Constraint leq(double cst, RealExp exp) {
    return makeEquation(exp, cst(cst, Double.POSITIVE_INFINITY));
  }

  /**
   * Superiority constraint.
   */
  public Constraint geq(RealExp exp1, RealExp exp2) {
    return leq(exp2, exp1);
  }

  public Constraint geq(RealExp exp, double cst) {
    return leq(cst, exp);
  }

  public Constraint geq(double cst, RealExp exp) {
    return leq(exp, cst);
  }

  /**
   * Addition of two expressions.
   */
  public RealExp plus(RealExp exp1, RealExp exp2) {
    return createRealPlus(exp1, exp2);
  }

  /**
   * Substraction of two expressions.
   */
  public RealExp minus(RealExp exp1, RealExp exp2) {
    return createRealMinus(exp1, exp2);
  }

  /**
   * Multiplication of two expressions.
   */
  public RealExp mult(RealExp exp1, RealExp exp2) {
    return createRealMult(exp1, exp2);
  }

  /**
   * Power of an expression.
   */
  public RealExp power(RealExp exp, int power) {
    return createRealIntegerPower(exp, power);
  }

  /**
   * Cosinus of an expression.
   */
  public RealExp cos(RealExp exp) {
    return createRealCos(exp);
  }

  /**
   * Sinus of an expression.
   */
  public RealExp sin(RealExp exp) {
    return createRealSin(exp);
  }

  /**
   * Arounds a double d to <code>[d - epsilon, d + epilon]</code>.
   */
  public RealIntervalConstant around(double d) {
    return cst(RealMath.prevFloat(d), RealMath.nextFloat(d));
  }

  /**
   * Makes a constant interval from a double d ([d,d]).
   */
  public RealIntervalConstant cst(double d) {
    return createRealIntervalConstant(d, d);
  }

  /**
   * Makes a constant interval between two doubles [a,b].
   */
  public RealIntervalConstant cst(double a, double b) {
    return createRealIntervalConstant(a, b);
  }

  // ------------------------ Boolean connectors
  public Constraint makeDisjunction(Constraint[] alternatives) {
    if (alternatives.length == 0) {
      throw new UnsupportedOperationException();
    } else if (alternatives.length == 1) {
      return alternatives[0];
    } else if (alternatives.length == 2) {
      return createBinDisjunction((AbstractConstraint) alternatives[0], (AbstractConstraint) alternatives[1]);
    } else {
      return createLargeDisjunction(alternatives);
    }
  }

  public final Constraint or(Constraint[] constList) {
    return makeDisjunction(constList);
  }

  public final Constraint or(Constraint c0, Constraint c1, Constraint c2) {
    return makeDisjunction(new Constraint[]{c0, c1, c2});
  }

  public final Constraint or(Constraint c0, Constraint c1, Constraint c2, Constraint c3) {
    return makeDisjunction(new Constraint[]{c0, c1, c2, c3});
  }

  public final Constraint or(Constraint c0, Constraint c1) {
    Constraint[] alternatives;
    if (c0 instanceof BinDisjunction) {
      if (c1 instanceof BinDisjunction) {
        alternatives = new Constraint[4];
        alternatives[0] = ((BinDisjunction) c0).getSubConstraint(0);
        alternatives[1] = ((BinDisjunction) c0).getSubConstraint(1);
        alternatives[2] = ((BinDisjunction) c1).getSubConstraint(0);
        alternatives[3] = ((BinDisjunction) c1).getSubConstraint(1);
      } else if (c1 instanceof LargeDisjunction) {
        int nb1 = ((LargeDisjunction) c1).getNbSubConstraints();
        alternatives = new Constraint[2 + nb1];
        alternatives[0] = ((BinDisjunction) c0).getSubConstraint(0);
        alternatives[1] = ((BinDisjunction) c0).getSubConstraint(1);
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          alternatives[2 + constIdx] = ((LargeDisjunction) c1).getSubConstraint(constIdx);
        }
      } else { // c1 is not a disjunction
        alternatives = new Constraint[3];
        alternatives[0] = ((BinDisjunction) c0).getSubConstraint(0);
        alternatives[1] = ((BinDisjunction) c0).getSubConstraint(1);
        alternatives[2] = c1;
      }
    } else if (c0 instanceof LargeDisjunction) {
      if (c1 instanceof BinDisjunction) {
        int nb0 = ((LargeDisjunction) c0).getNbSubConstraints();
        alternatives = new Constraint[2 + nb0];
        alternatives[0] = ((BinDisjunction) c1).getSubConstraint(0);
        alternatives[1] = ((BinDisjunction) c1).getSubConstraint(1);
        for (int constIdx = 0; constIdx < ((LargeDisjunction) c0).getNbSubConstraints(); constIdx++) {
          alternatives[2 + constIdx] = ((LargeDisjunction) c0).getSubConstraint(constIdx);
        }
      } else if (c1 instanceof LargeDisjunction) {
        int nb0 = ((LargeDisjunction) c0).getNbSubConstraints();
        int nb1 = ((LargeDisjunction) c1).getNbSubConstraints();
        alternatives = new Constraint[nb0 + nb1];
        for (int constIdx = 0; constIdx < nb0; constIdx++) {
          alternatives[constIdx] = ((LargeDisjunction) c0).getSubConstraint(constIdx);
        }
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          alternatives[nb0 + constIdx] = ((LargeDisjunction) c1).getSubConstraint(constIdx);
        }
      } else {
        int nb0 = ((LargeDisjunction) c0).getNbSubConstraints();
        alternatives = new Constraint[nb0 + 1];
        alternatives[0] = ((BinDisjunction) c1).getSubConstraint(0);
        alternatives[1] = ((BinDisjunction) c1).getSubConstraint(1);
        for (int constIdx = 0; constIdx < nb0; constIdx++) {
          alternatives[constIdx] = ((LargeDisjunction) c0).getSubConstraint(constIdx);
        }
        alternatives[nb0] = c1;
      }
    } else { // c0 does not implement a disjunction
      if (c1 instanceof BinDisjunction) {
        alternatives = new Constraint[3];
        alternatives[0] = c0;
        alternatives[1] = ((BinDisjunction) c1).getSubConstraint(0);
        alternatives[2] = ((BinDisjunction) c1).getSubConstraint(1);
      } else if (c1 instanceof LargeDisjunction) {
        int nb1 = ((LargeDisjunction) c1).getNbSubConstraints();
        alternatives = new Constraint[1 + nb1];
        alternatives[0] = c0;
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          alternatives[1 + constIdx] = ((LargeDisjunction) c1).getSubConstraint(constIdx);
        }
      } else { // c1 does not implement a disjunction
        alternatives = new Constraint[2];
        alternatives[0] = c0;
        alternatives[1] = c1;
      }
    }
    return makeDisjunction(alternatives);
  }

  public Constraint makeConjunction(Constraint[] branches) {
    if (branches.length == 0) {
      throw new UnsupportedOperationException();
    } else if (branches.length == 1) {
      return branches[0];
    } else if (branches.length == 2) {
      return createBinConjunction((AbstractConstraint) branches[0], (AbstractConstraint) branches[1]);
    } else {
      return createLargeConjunction(branches);
    }
  }

  public final Constraint and(Constraint[] constList) {
    return makeConjunction(constList);
  }

  public final Constraint and(Constraint c0, Constraint c1, Constraint c2) {
    return makeConjunction(new Constraint[]{c0, c1, c2});
  }

  public final Constraint and(Constraint c0, Constraint c1, Constraint c2, Constraint c3) {
    return makeConjunction(new Constraint[]{c0, c1, c2, c3});
  }

  public final Constraint and(Constraint c0, Constraint c1) {
    Constraint[] branches;
    if (c0 instanceof BinConjunction) {
      if (c1 instanceof BinConjunction) {
        branches = new Constraint[4];
        branches[0] = ((BinConjunction) c0).getSubConstraint(0);
        branches[1] = ((BinConjunction) c0).getSubConstraint(1);
        branches[2] = ((BinConjunction) c1).getSubConstraint(0);
        branches[3] = ((BinConjunction) c1).getSubConstraint(1);
      } else if (c1 instanceof LargeConjunction) {
        int nb1 = ((LargeConjunction) c1).getNbSubConstraints();
        branches = new Constraint[2 + nb1];
        branches[0] = ((BinConjunction) c0).getSubConstraint(0);
        branches[1] = ((BinConjunction) c0).getSubConstraint(1);
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          branches[2 + constIdx] = ((LargeConjunction) c1).getSubConstraint(constIdx);
        }
      } else { // c1 is not a Conjunction
        branches = new Constraint[3];
        branches[0] = ((BinConjunction) c0).getSubConstraint(0);
        branches[1] = ((BinConjunction) c0).getSubConstraint(1);
        branches[2] = c1;
      }
    } else if (c0 instanceof LargeConjunction) {
      if (c1 instanceof BinConjunction) {
        int nb0 = ((LargeConjunction) c0).getNbSubConstraints();
        branches = new Constraint[2 + nb0];
        branches[0] = ((BinConjunction) c1).getSubConstraint(0);
        branches[1] = ((BinConjunction) c1).getSubConstraint(1);
        for (int constIdx = 0; constIdx < ((LargeConjunction) c0).getNbSubConstraints(); constIdx++) {
          branches[2 + constIdx] = ((LargeConjunction) c0).getSubConstraint(constIdx);
        }
      } else if (c1 instanceof LargeConjunction) {
        int nb0 = ((LargeConjunction) c0).getNbSubConstraints();
        int nb1 = ((LargeConjunction) c1).getNbSubConstraints();
        branches = new Constraint[nb0 + nb1];
        for (int constIdx = 0; constIdx < nb0; constIdx++) {
          branches[constIdx] = ((LargeConjunction) c0).getSubConstraint(constIdx);
        }
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          branches[nb0 + constIdx] = ((LargeConjunction) c1).getSubConstraint(constIdx);
        }
      } else {
        int nb0 = ((LargeConjunction) c0).getNbSubConstraints();
        branches = new Constraint[nb0 + 1];
        branches[0] = ((BinConjunction) c1).getSubConstraint(0);
        branches[1] = ((BinConjunction) c1).getSubConstraint(1);
        for (int constIdx = 0; constIdx < nb0; constIdx++) {
          branches[constIdx] = ((LargeConjunction) c0).getSubConstraint(constIdx);
        }
        branches[nb0] = c1;
      }
    } else { // c0 does not implement a Conjunction
      if (c1 instanceof BinConjunction) {
        branches = new Constraint[3];
        branches[0] = c0;
        branches[1] = ((BinConjunction) c1).getSubConstraint(0);
        branches[2] = ((BinConjunction) c1).getSubConstraint(1);
      } else if (c1 instanceof LargeConjunction) {
        int nb1 = ((LargeConjunction) c1).getNbSubConstraints();
        branches = new Constraint[1 + nb1];
        branches[0] = c0;
        for (int constIdx = 0; constIdx < nb1; constIdx++) {
          branches[1 + constIdx] = ((LargeConjunction) c1).getSubConstraint(constIdx);
        }
      } else { // c1 does not implement a Conjunction
        branches = new Constraint[2];
        branches[0] = c0;
        branches[1] = c1;
      }
    }
    return makeConjunction(branches);
  }

  public final Constraint implies(Constraint c1, Constraint c2) {
    return or(not(c1), c2);
  }

  public Constraint ifThen(Constraint c1, Constraint c2) {
    return createGuard((AbstractConstraint) c1, (AbstractConstraint) c2);
  }

  public Constraint ifOnlyIf(Constraint c1, Constraint c2) {
    return createEquiv((AbstractConstraint) c1, (AbstractConstraint) c2);
  }


  public final Constraint not(Constraint c) {
    return c.opposite();
  }

  public Constraint atleast(Constraint[] constList, int nbTrueConstraints) {
    IntVar cardVar = makeConstantIntVar(nbTrueConstraints);
    return createCardinality(constList, cardVar, true, false);
  }

  public Constraint atmost(Constraint[] constList, int nbTrueConstraints) {
    IntVar cardVar = makeConstantIntVar(nbTrueConstraints);
    return createCardinality(constList, cardVar, false, true);
  }

  public Constraint card(Constraint[] constList, IntVar nbTrueConstraints) {
    return createCardinality(constList, nbTrueConstraints, true, true);
  }

  public Constraint makePairAC(IntVar v1, IntVar v2, List mat, boolean feas, int ac) {
    IntDomainVar x = (IntDomainVar) v1;
    IntDomainVar y = (IntDomainVar) v2;
    int n1 = x.getSup() - x.getInf() + 1;
    int n2 = y.getSup() - y.getInf() + 1;
    CouplesTable relation = new CouplesTable(feas, ((IntDomainVar) v1).getInf(), ((IntDomainVar) v2).getInf(), n1, n2);
    Iterator it = mat.iterator();
    while (it.hasNext()) {
      int[] couple = (int[]) it.next();
      if (couple.length != 2) throw new Error("Wrong dimension : " + couple.length + " for a couple");
      relation.setCouple(couple[0], couple[1]);
    }
    if (ac == 3)
      return this.createAC3BinConstraint(v1, v2, relation);
    else if (ac == 4)
      return this.createAC4BinConstraint(v1, v2, relation);
    else if (ac == 2001)
      return this.createAC2001BinConstraint(v1, v2, relation);
    else {
      throw new Error("Ac " + ac + " algorithm not yet implemented");
    }
  }

  public Constraint makePairAC(IntVar v1, IntVar v2, boolean[][] mat, boolean feas, int ac) {
    int n1 = ((IntDomainVar) v1).getDomainSize();
    int n2 = ((IntDomainVar) v2).getDomainSize();
    if (n1 == mat.length && n2 == mat[0].length) {
      CouplesTable relation = new CouplesTable(feas, ((IntDomainVar) v1).getInf(), ((IntDomainVar) v2).getInf(), n1, n2);
      for (int i = 0; i < n1; i++) {
        for (int j = 0; j < n2; j++) {
          if (mat[i][j])
            relation.setCoupleWithoutOffset(i, j);
        }
      }
      if (ac == 3)
        return this.createAC3BinConstraint(v1, v2, relation);
      else if (ac == 4)
        return this.createAC4BinConstraint(v1, v2, relation);
      else if (ac == 2001)
        return this.createAC2001BinConstraint(v1, v2, relation);
      else {
        throw new Error("Ac " + ac + " algorithm not yet implemented");
      }
    } else
      throw new Error("Wrong dimension for the matrix of consistency : "
          + mat.length + " X " + mat[0].length + " instead of " + n1 + "X" + n2);
  }

  public Constraint relationPairAC(IntVar v1, IntVar v2, BinRelation binR, int ac) {
    if (ac == 3)
      return createAC3BinConstraint(v1, v2, binR);
    else if (ac == 4)
      return createAC4BinConstraint(v1, v2, binR);
    else if (ac == 2001)
      return createAC2001BinConstraint(v1, v2, binR);
    else {
      throw new Error("Ac " + ac + " algorithm not yet implemented");
    }
  }

  public Constraint makeTupleFC(IntVar[] vs, List tuples, boolean feas) {
    int n = vs.length;
    int[] offsets = new int[n];
    int[] sizes = new int[n];
    for (int i = 0; i < n; i++) {
      IntDomainVar vi = (IntDomainVar) vs[i];
      sizes[i] = vi.getSup() - vi.getInf() + 1; //vi.getDomainSize();
      offsets[i] = vi.getInf();
    }
    TuplesTable relation = new TuplesTable(feas, offsets, sizes);
    Iterator it = tuples.iterator();
    while (it.hasNext()) {
      int[] tuple = (int[]) it.next();
      if (tuple.length != n) throw new Error("Wrong dimension : " + tuple.length + " for a tuple (should be " + n + ")");
      relation.setCouple(tuple);
    }
    return createCspLargeConstraint(vs, relation);
  }

  public Constraint relationTuple(IntVar[] vs, LargeRelation rela) {
    return createCspLargeConstraint(vs, rela);
  }

  public Constraint infeasTuple(IntVar[] vars, ArrayList tuples) {
    return makeTupleFC(vars, tuples, false);
  }

  public Constraint feasTuple(IntVar[] vars, ArrayList tuples) {
    return makeTupleFC(vars, tuples, true);
  }

  public Constraint relationPairAC(IntVar v1, IntVar v2, BinRelation binR) {
    return relationPairAC(v1, v2, binR, 2001);
  }

  public Constraint infeasPairAC(IntVar v1, IntVar v2, ArrayList mat) {
    return makePairAC(v1, v2, mat, false, 2001);
  }

  public Constraint infeasPairAC(IntVar v1, IntVar v2, ArrayList mat, int ac) {
    return makePairAC(v1, v2, mat, false, ac);
  }

  public Constraint feasPairAC(IntVar v1, IntVar v2, ArrayList mat) {
    return makePairAC(v1, v2, mat, true, 2001);
  }

  public Constraint feasPairAC(IntVar v1, IntVar v2, ArrayList mat, int ac) {
    return makePairAC(v1, v2, mat, true, ac);
  }

  public Constraint infeasPairAC(IntVar v1, IntVar v2, boolean[][] mat) {
    return makePairAC(v1, v2, mat, false, 2001);
  }

  public Constraint infeasPairAC(IntVar v1, IntVar v2, boolean[][] mat, int ac) {
    return makePairAC(v1, v2, mat, false, ac);
  }

  public Constraint feasPairAC(IntVar v1, IntVar v2, boolean[][] mat) {
    return makePairAC(v1, v2, mat, true, 2001);
  }

  public Constraint feasPairAC(IntVar v1, IntVar v2, boolean[][] mat, int ac) {
    return makePairAC(v1, v2, mat, true, ac);
  }

  protected Constraint makeOccurrence(IntVar[] lvars, IntVar occVar, int occval, boolean onInf, boolean onSup) {
    IntVar[] tmpvars = new IntVar[lvars.length + 1];
    System.arraycopy(lvars, 0, tmpvars, 0, lvars.length);
    tmpvars[lvars.length] = occVar;
    return this.createOccurrence(tmpvars, occval, onInf, onSup);
  }

  /**
   * Ensures that the occurrence variable contains the number of occurrences of the given value in the list of
   * variables
   *
   * @param vars       List of variables where the value can appear
   * @param occurrence The variable that should contain the occurence number
   */

  public Constraint occurrence(IntVar[] vars, int value, IntVar occurrence) {
    return makeOccurrence(vars, occurrence, value, true, true);
  }

  /**
   * Ensures that the lower bound of occurrence is at least equal to the number of occurences
   * size{forall v in vars | v = value} <= occurence
   */
  public Constraint occurenceMin(IntVar[] vars, int value, IntVar occurrence) {
    return makeOccurrence(vars, occurrence, value, true, false);
  }

  /**
   * Ensures that the upper bound of occurrence is at most equal to the number of occurences
   * size{forall v in vars | v = value} >= occurence
   */
  public Constraint occurenceMax(IntVar[] vars, int value, IntVar occurrence) {
    return makeOccurrence(vars, occurrence, value, false, true);
  }

  /**
   * subscript constraint: accessing an array with a variable index
   */
  public Constraint nth(IntVar index, int[] values, IntVar val) {
    return createSubscript(index, values, val, 0);
  }

  /**
   * subscript constraint: accessing an array of variables with a variable index
   */
  public Constraint nth(IntVar index, IntVar[] varArray, IntVar val) {
    return createSubscript(index, varArray, val, 0);
  }

  /**
   * State a simple channeling bewteen a boolean variable and an interger variable
   * Ensures for that b = 1 iff x = j
   *
   * @param b : a boolean variable
   * @param x : an integer variable
   * @param j : the value such that b = 1 ssi x = j, and b = 0 otherwise
   */
  public Constraint boolChanneling(IntVar b, IntVar x, int j) {
    IntVar boolv, intv;
    if ((((IntDomainVar) b).getInf() >= 0) && (((IntDomainVar) b).getSup() <= 1)) {
      boolv = b;
      intv = x;
    } else {
      boolv = x;
      intv = b;
    }
    if ((((IntDomainVar) boolv).getInf() >= 0) && (((IntDomainVar) boolv).getSup() <= 1) && ((IntDomainVar) intv).canBeInstantiatedTo(j))
      return createBoolChanneling(boolv, intv, j);
    else
      throw new Error(b + " should be a boolean variable and " + j + " should belongs to the domain of " + x);
  }

  /**
   * State a channeling bewteen two arrays of integer variables x and y with the same domain which enforces
   * x[i] = j <=> y[j] = i
   */
  public Constraint inverseChanneling(IntVar[] x, IntVar[] y) {
    if (x.length == y.length) {
      for (int i = 0; i < x.length; i++) {
        if ((((IntDomainVar) x[i]).getInf() != ((IntDomainVar) y[i]).getInf()) ||
            (((IntDomainVar) x[i]).getSup() != ((IntDomainVar) y[i]).getSup()))
          throw new Error(x[i] + " and " + y[i] + " should have the same domain in inverseChanneling");
      }
      return createInverseChanneling(x, y);
    } else
      throw new Error("intvar arrays of inverseChanneling should have the same size " + x.length + " - " + y.length);


  }

  /**
   * All different constraints with a global filtering :
   * v1 != v2, v1 != v3, v2 != v3 ... For each (i,j), v_i != v_j
   * If vars is a table of BoundIntVar a dedicated algorithm is used. In case
   * of EnumIntVar it is the regin alldifferent.
   */
  public Constraint allDifferent(IntVar[] vars) {
    return allDifferent(vars,true);
  }

  /**
   * All different constraints : v1 != v2, v1 != v3, v2 != v3 ... For each (i,j), v_i != v_j.
   * parameter global specifies if a global filtering algorithm is used for propagation or not.
   */
  public Constraint allDifferent(IntVar[] vars, boolean global) {
    if (global) {
        if (((IntDomainVar) vars[0]).hasEnumeratedDomain())
            return createAllDifferent(vars);
        else
            return createBoundAllDiff(vars,true);
    } else {
      return createBoundAllDiff(vars,false);
    }
  }

  /**
   * Global cardinality : Given an array of variables vars, min the minimal value over all variables,
   * and max the maximal value over all variables, the constraint ensures that the number of occurences
   * of the value i among the variables is between low[i - min] and up[i - min]. Note that the length
   * of low and up should be max - min + 1.
   */

  public Constraint globalCardinality(IntVar[] vars, int min, int max, int[] low, int[] up) {
    return createGlobalCardinality(vars, min, max, low, up);
  }

  /**
   * Global cardinality : Given an array of variables vars such that their domains are subsets of
   * [1, n], the constraint ensures that the number of occurences
   * of the value i among the variables is between low[i - 1] and up[i - 1]. Note that the length
   * of low and up should be exactly n.
   */

  public Constraint globalCardinality(IntVar[] vars, int[] low, int[] up) {
    return createGlobalCardinality(vars, 1, low.length, low, up);
  }

  /**
   * Cumulative : Given a set of tasks defined by their starting dates, ending dates, durations and
   * consumptions/heights, the cumulative ensures that at any time t, the sum of the heights of the tasks
   * which are executed at time t does not exceed a given limit C (the capacity of the ressource).
   * The notion of task does not exist yet in choco. The cumulative takes therefore as input three arrays
   * of integer variables (of same size n) denoting the starting, ending, and duration of each task.
   * The heights of the tasks are considered constant and given via an array of size n of positive integers.
   * The last parameter Capa denotes the Capacity of the cumulative (of the ressource).
   * The implementation is based on the paper of Bediceanu and al :
   * "A new multi-resource cumulatives constraint with negative heights" in CP02
   */

  public Constraint cumulative(IntVar[] starts, IntVar[] ends, IntVar[] durations, int[] heights, int Capa) {
      int n = starts.length;
      if (ends.length != n || durations.length != n || heights.length != n) {
          throw new Error("starts, ends, durations and heigts should be of the same size " + n);
      }
      return createCumulative(starts,ends,durations,heights,Capa);
  }

  public Constraint cumulative(IntVar[] starts, IntVar[] ends, IntVar[] durations, IntVar[] heights, int Capa) {
      int n = starts.length;
      if (ends.length != n || durations.length != n || heights.length != n) {
          throw new Error("starts, ends, durations and heigts should be of the same size " + n);
      }
      return createCumulative(starts, ends, durations, heights, Capa);
  }
  /**
    * Enforce a lexicographic ordering on two vectors of integer
    * variables x <_lex y with x = <x_0, ..., x_n>, and y = <y_0, ..., y_n>.
    * ref : Global Constraints for Lexicographic Orderings (Frisch and al)
  */
  public Constraint lexeq(IntVar[] v1, IntVar[] v2) {
     if (v1.length != v2.length)
        throw new Error("the vectors of variables should be of same size for lex " + v1.length + " and " + v2.length);
     return createLex(v1,v2,false);
  }

  /**
    * Enforce a strict lexicographic ordering on two vectors of integer
    * variables x <_lex y with x = <x_0, ..., x_n>, and y = <y_0, ..., y_n>.
    * ref : Global Constraints for Lexicographic Orderings (Frisch and al)
  */
  public Constraint lex(IntVar[] v1, IntVar[] v2) {
     if (v1.length != v2.length)
        throw new Error("the vectors of variables should be of same size for lex " + v1.length + " and " + v2.length);
     return createLex(v1,v2,true);
  }
  // ------------- Constraints over sets -------------------------------
  /**
   * Enforce a set to be the intersection of two others.
   * @param inter the intersection of sv1 and sv2
   */
  public Constraint setInter(SetVar sv1, SetVar sv2, SetVar inter) {
    return createSetIntersection(sv1, sv2, inter);
  }

  public Constraint eqCard(SetVar sv, IntVar v) {
    return createSetCard(sv, v, true, true);
  }

  public Constraint eqCard(SetVar sv, int val) {
    IntVar v = makeConstantIntVar("cste" + sv, val);
    return createSetCard(sv, v, true, true);
  }

  public Constraint geqCard(SetVar sv, IntVar v) {
    return createSetCard(sv, v, false, true);
  }

  public Constraint geqCard(SetVar sv, int val) {
    IntVar v = makeConstantIntVar("cste" + sv, val);
    return createSetCard(sv, v, false, true);
  }

  public Constraint leqCard(SetVar sv, IntVar v) {
    return createSetCard(sv, v, true, false);
  }

  public Constraint leqCard(SetVar sv, int val) {
    IntVar v = makeConstantIntVar("cste" + sv, val);
    return createSetCard(sv, v, true, false);
  }

  public Constraint setDisjoint(SetVar sv1, SetVar sv2) {
    return createDisjoint(sv1, sv2);
  }

  public Constraint member(int val, SetVar sv1) {
    return createMemberX(sv1, val);
  }

  public Constraint member(SetVar sv1, int val) {
    return createMemberX(sv1, val);
  }

  public Constraint member(SetVar sv1, IntVar var) {
    return createMemberXY(sv1, var);
  }

  public Constraint member(IntVar var, SetVar sv1) {
    return createMemberXY(sv1, var);
  }

  public Constraint notMember(int val, SetVar sv1) {
    return createNotMemberX(sv1, val);
  }

  public Constraint notMember(SetVar sv1, int val) {
    return notMember(val, sv1);
  }

  public Constraint notMember(SetVar sv1, IntVar var) {
    return notMember(var, sv1);
  }

  public Constraint notMember(IntVar var, SetVar sv1) {
    return createNotMemberXY(sv1, var);
  }


  // -------------------------------------------------------------------

  // All abstract methods for constructing constraint
  // that need be defined by a Problem implementing a model
  protected abstract Constraint createEqualXC(IntVar v0, int c);

  protected abstract Constraint createNotEqualXC(IntVar v0, int c);

  protected abstract Constraint createGreaterOrEqualXC(IntVar v0, int c);

  protected abstract Constraint createLessOrEqualXC(IntVar v0, int c);

  protected abstract Constraint createEqualXYC(IntVar intVar, IntVar intVar1, int i);

  protected abstract Constraint createNotEqualXYC(IntVar variable, IntVar variable1, int i);

  protected abstract Constraint createGreaterOrEqualXYC(IntVar intVar, IntVar intVar1, int i);

  protected abstract Constraint createIntLinComb(IntVar[] sortedVars, int[] sortedCoeffs, int nbPositiveCoeffs, int c, int linOperator);

  protected abstract Constraint createTimesXYZ(IntVar x, IntVar y, IntVar z);
  
  protected abstract Constraint createBinDisjunction(Constraint c0, Constraint c1);

  protected abstract Constraint createLargeDisjunction(Constraint[] alternatives);

  protected abstract Constraint createBinConjunction(Constraint c0, Constraint c1);

  protected abstract Constraint createLargeConjunction(Constraint[] alternatives);

  protected abstract Constraint createCardinality(Constraint[] constList, IntVar cardVar, boolean b, boolean b1);

  protected abstract Constraint createGuard(Constraint c0, Constraint c1);

  protected abstract Constraint createEquiv(Constraint c0, Constraint c1);

  protected abstract Constraint createAC3BinConstraint(IntVar v1, IntVar v2, BinRelation relation);

  protected abstract Constraint createAC4BinConstraint(IntVar v1, IntVar v2, BinRelation relation);

  protected abstract Constraint createAC2001BinConstraint(IntVar v1, IntVar v2, BinRelation relation);

  protected abstract Constraint createCspLargeConstraint(IntVar[] vs, LargeRelation relation);

  protected abstract Constraint createOccurrence(IntVar[] lvars, int occval, boolean onInf, boolean onSup);

  protected abstract Constraint createAllDifferent(IntVar[] vars);

  protected abstract Constraint createBoundAllDiff(IntVar[] vars, boolean global);

  protected abstract Constraint createGlobalCardinality(IntVar[] vars, int min, int max, int[] low, int[] up);

  protected abstract Constraint createCumulative(IntVar[] sts, IntVar[] ends, IntVar[] durations, int[] h, int capa);

  protected abstract Constraint createCumulative(IntVar[] sts, IntVar[] ends, IntVar[] durations, IntVar[] heights, int capa);  

  protected abstract Constraint createLex(IntVar[] v1, IntVar[] v2, boolean strict);

  protected abstract Constraint createSubscript(IntVar index, int[] values, IntVar val, int offset);

  protected abstract Constraint createSubscript(IntVar index, IntVar[] varArray, IntVar val, int offset);

  protected abstract Constraint createInverseChanneling(IntVar[] x, IntVar[] y);

  protected abstract Constraint createBoolChanneling(IntVar b, IntVar x, int j);

  protected abstract IntDomainVar createIntVar(String name, int domainType, int min, int max);

  protected abstract IntDomainVar createIntVar(String name, int[] sortedValues);

  protected abstract RealVar createRealVal(String name, double min, double max);

  protected abstract SetVar createSetVar(String name, int a, int b);

  protected abstract RealIntervalConstant createRealIntervalConstant(double a, double b);

  protected abstract RealExp createRealSin(RealExp exp);

  protected abstract RealExp createRealCos(RealExp exp);

  protected abstract RealExp createRealIntegerPower(RealExp exp, int power);

  protected abstract RealExp createRealPlus(RealExp exp1, RealExp exp2);

  protected abstract RealExp createRealMinus(RealExp exp1, RealExp exp2);

  protected abstract RealExp createRealMult(RealExp exp1, RealExp exp2);

  protected abstract Constraint createEquation(RealVar[] tmpVars, RealExp exp, RealIntervalConstant cst);

  protected abstract Constraint createMemberXY(SetVar sv1, IntVar var);

  protected abstract Constraint createNotMemberXY(SetVar sv1, IntVar var);

  protected abstract Constraint createMemberX(SetVar sv1, int val);

  protected abstract Constraint createNotMemberX(SetVar sv1, int val);

  protected abstract Constraint createDisjoint(SetVar sv1, SetVar sv2);

  protected abstract Constraint createSetIntersection(SetVar sv1, SetVar sv2, SetVar inter);

  protected abstract Constraint createSetCard(SetVar sv, IntVar v, boolean b1, boolean b2);

  /**
   * <i>Network management:</i>
   * Retrieve a variable by its index (all integer variables of
   * the problem are numbered in sequence from 0 on)
   *
   * @param i index of the variable in the problem
   */

  public final IntVar getIntVar(int i) {
    return (IntVar) intVars.get(i);
  }

  public int getIntVarIndex(IntVar c) {
    return intVars.indexOf(c);
  }

  /**
   * retrieving the total number of variables
   *
   * @return the total number of variables in the problem
   */
  public final int getNbIntVars() {
    return intVars.size();
  }

  /**
   * Returns a real variable.
   *
   * @param i index of the variable
   * @return the i-th real variable
   */
  public final RealVar getRealVar(int i) {
    return (RealVar) floatVars.get(i);
  }

  /**
   * Returns the number of variables modelling real numbers.
   */
  public final int getNbRealVars() {
    return floatVars.size();
  }

  /**
   * Returns a set variable.
   *
   * @param i index of the variable
   * @return the i-th real variable
   */
  public final SetVar getSetVar(int i) {
    return (SetVar) setVars.get(i);
  }

  /**
   * Returns the number of variables modelling real numbers.
   */
  public final int getNbSetVars() {
    return setVars.size();
  }
}
