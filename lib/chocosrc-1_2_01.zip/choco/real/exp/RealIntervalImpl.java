package choco.real.exp;

import choco.ContradictionException;
import choco.prop.VarEvent;
import choco.real.RealInterval;

/**
 * @deprecated
 */
public class RealIntervalImpl implements RealInterval {
  protected double inf;
  protected double sup;

  public RealIntervalImpl(double inf, double sup) {
    this.inf = inf;
    this.sup = sup;
  }

  public RealIntervalImpl() {
    this(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
  }

  public RealIntervalImpl(RealInterval i) {
    this(i.getInf(), i.getSup());
  }

  public String toString() {
    return "[" + inf + "," + sup + "]";
  }

  public double getInf() {
    return inf;
  }

  public double getSup() {
    return sup;
  }

  public void intersect(RealInterval interval) throws ContradictionException {
    intersect(interval, VarEvent.NOCAUSE);
  }

  public void intersect(RealInterval interval, int index) throws ContradictionException {
    if (interval.getInf() > inf) inf = interval.getInf();
    if (interval.getSup() < sup) sup = interval.getSup();
  }
}
