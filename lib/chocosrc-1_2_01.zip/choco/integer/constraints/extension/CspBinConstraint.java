// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.constraints.extension;

import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.integer.constraints.AbstractBinIntConstraint;
import choco.util.IntIterator;

public abstract class CspBinConstraint extends AbstractBinIntConstraint {


  protected BinRelation relation;


  protected CspBinConstraint(IntDomainVar x, IntDomainVar y, BinRelation relation) {
    super(x, y);
    this.relation = relation;
  }

  /**
   * Checks if the constraint is satisfied when the variables are instantiated.
   *
   * @return true if the constraint is satisfied
   */

  public boolean isSatisfied() {
    return relation.isConsistent(v0.getVal(), v1.getVal()); //table.get((v1.getVal() - offset) * n + (v0.getVal() - offset));
  }

  public BinRelation getRelation() {
    return relation;
  }

  public void awakeOnVar(int idx) throws ContradictionException {
    logger.severe("AwakeOnVar should not be called in CspBinConstraint");
    System.exit(0);
  }

  public Boolean isEntailed() {
    boolean always = true;
    IntIterator itv1 = v0.getDomain().getIterator();
    while (itv1.hasNext()) {
      int nbs = 0;
      int val = itv1.next();
      IntIterator itv2 = v1.getDomain().getIterator();
      while (itv2.hasNext()) {
        if (relation.isConsistent(val, itv2.next())) nbs += 1;
      }
      if (nbs == 0) {
        always = false;
      } else if (nbs != v1.getDomainSize()) {
        return null;
      }
    }
    if (always)
      return Boolean.TRUE;
    else
      return Boolean.FALSE;
  }
}
