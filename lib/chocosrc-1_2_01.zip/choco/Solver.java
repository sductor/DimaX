// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco;

import choco.branch.AbstractIntBranching;
import choco.branch.VarSelector;
import choco.integer.IntDomainVar;
import choco.integer.search.*;
import choco.integer.var.IntDomainVarImpl;
import choco.real.RealVar;
import choco.real.search.AbstractRealOptimize;
import choco.real.search.RealBranchAndBound;
import choco.real.search.RealOptimizeWithRestarts;
import choco.search.*;
import choco.util.LightFormatter;

import java.security.AccessControlException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.StreamHandler;

/**
 * This class serves both as a factory and as a handler for AbstractGlobalSearchSolvers:
 */
public class Solver extends AbstractEntity {

  /**
   * The variable modelling the objective function
   */
  protected Var objective;

  /**
   * Maximization / Minimization problem
   */
  protected boolean doMaximize;

  public void setLoggingMaxDepth(int loggingMaxDepth) {
    this.loggingMaxDepth = loggingMaxDepth;
  }

  /**
   * maximal search depth for logging statements
   */
  public int loggingMaxDepth = 5;

  /**
   * Do we want to restart a new search after each solution
   */
  protected boolean restart = false;

  /**
   * do we want to explore one or all solutions (default=one solution)
   */
  protected boolean firstSolution = true;

  /**
   * The object controlling the global search exploration
   */
  protected AbstractGlobalSearchSolver solver;

  /**
   * Variable selector
   */
  protected VarSelector varSelector = null;

  /**
   * Value iterator
   */
  protected ValIterator valIterator = null;

  /**
   * Value selector
   */
  protected ValSelector valSelector = null;

  protected int timeLimit = Integer.MAX_VALUE;

  protected int nodeLimit = Integer.MAX_VALUE;

  /**
   * Temporary attached goal for the future generated solver.
   */
  protected AbstractIntBranching tempGoal;

  public AbstractGlobalSearchSolver getSearchSolver() {
    return solver;
  }

  public Solver(AbstractProblem pb) {
    super(pb);
    setVerbosity(SILENT);
  }

  public void generateSearchSolver(AbstractProblem pb) {
    problem = pb;
    if (null == objective) {
      solver = new Solve(this.getProblem());
    } else if (restart) {
      if (objective instanceof IntDomainVar)
        solver = new OptimizeWithRestarts((IntDomainVarImpl) objective, doMaximize);
      else if (objective instanceof RealVar)
        solver = new RealOptimizeWithRestarts((RealVar) objective, doMaximize);
    } else {
      if (objective instanceof IntDomainVar)
        solver = new BranchAndBound((IntDomainVarImpl) objective, doMaximize);
      else if (objective instanceof RealVar)
        solver = new RealBranchAndBound((RealVar) objective, doMaximize);
    }
    solver.stopAtFirstSol = firstSolution;

    solver.setLoggingMaxDepth(this.loggingMaxDepth);

    solver.limits.add(new TimeLimit(solver, timeLimit));
    solver.limits.add(new NodeLimit(solver, nodeLimit));

    if (tempGoal == null) {
      generateGoal(pb);
    } else {
      attachGoal(tempGoal);
      tempGoal = null;
    }
  }

  protected void generateGoal(AbstractProblem pb) {
    if (varSelector == null) varSelector = new MinDomain(pb);
    if (valIterator == null && valSelector == null) valIterator = new IncreasingDomain();
    if (valIterator != null)
      attachGoal(new AssignVar(varSelector, valIterator));
    else
      attachGoal(new AssignVar(varSelector, valSelector));
  }

  public void attachGoal(AbstractIntBranching branching) {
    if (solver == null) {
      tempGoal = branching;
    } else {
      AbstractIntBranching br = branching;
      while (br != null) {
        br.setSolver(solver);
        br = (AbstractIntBranching) br.getNextBranching();
      }
      solver.mainGoal = branching;
    }
  }

  public void addGoal(AbstractIntBranching branching) {
    AbstractIntBranching br;
    if (solver == null) {
      br = tempGoal;
    } else {
      branching.setSolver(solver);
       br = solver.mainGoal;
    }
    while (br.getNextBranching() != null) {
      br = (AbstractIntBranching) br.getNextBranching();
    }
    br.setNextBranching(branching);
  }

  /**
   * commands the solver to start
   */
  public void launch() {
    // solver.run();
    solver.incrementalRun();
  }

  /**
   * returns the number of solutions encountered during the search
   *
   * @return the number of solutions to the problem that were encountered during the search
   */
  public int getNbSolutions() {
    return solver.nbSolutions;
  }

  /**
   * Sets the time limit i.e. the maximal time before stopping the search algorithm
   */
  public void setTimeLimit(int timeLimit) {
    this.timeLimit = timeLimit;
  }

  /**
   * Sets the node limit i.e. the maximal number of nodes explored by the search algorithm
   */
  public void setNodeLimit(int nodeLimit) {
    this.nodeLimit = nodeLimit;
  }

  /**
   * @return true if only the first solution must be found
   */
  public boolean getFirstSolution() {
    return firstSolution;
  }

  /**
   * Sets wether only the first solution must be found
   */
  public void setFirstSolution(boolean firstSolution) {
    this.firstSolution = firstSolution;
  }

  /**
   * Sets the variable selector the search solver should use.
   */
  public void setVarSelector(VarSelector varSelector) {
    this.varSelector = varSelector;
  }

  /**
   * Sets the value iterator the search should use
   */
  public void setValIterator(ValIterator valIterator) {
    this.valIterator = valIterator;
  }

  /**
   * Sets the value selector the search should use
   */
  public void setValSelector(ValSelector valSelector) {
    this.valSelector = valSelector;
  }

  /**
   * set the optimization strategy:
   * - restart or not after each solution found
   *
   * @param restart
   */
  public void setRestart(boolean restart) {
    this.restart = restart;
  }

  /**
   * a boolean indicating if the solver minize or maximize the objective function
   *
   * @param doMaximize
   */
  public void setDoMaximize(boolean doMaximize) {
    this.doMaximize = doMaximize;
  }

  /**
   * Set the variable to optimize
   *
   * @param objective
   */
  public void setObjective(Var objective) {
    this.objective = objective;
  }

  public Number getOptimumValue() {
    if (solver instanceof AbstractOptimize) {
      return new Integer(((AbstractOptimize) solver).getBestObjectiveValue());
    } else if (solver instanceof AbstractRealOptimize) {
      return new Double(((AbstractRealOptimize) solver).getBestObjectiveValue());
    }
    return null;
  }

  /**
   * Checks if a limit has been encountered
   */
  public boolean isEncounteredLimit() {
    return solver.isEncounteredLimit();
  }

  /**
   * If a limit has been encounteres, return the involved limit
   */
  public GlobalSearchLimit getEncounteredLimit() {
    return solver.getEncounteredLimit();
  }

  // **********************************************************************
  //                       LOGGERS MANAGEMENT
  // **********************************************************************
  public static final int SILENT = 0;
  public static final int SOLUTION = 1;
  public static final int SEARCH = 2;
  public static final int PROPAGATION = 3;

  static {
    try {
      setDefaultHandler();
      setVerbosity(SILENT);
    } catch (AccessControlException e) {
      // Do nothing if this is an applet !
      // TODO: see how to make it work with an applet !
    }
  }

  private static void setDefaultHandler() {
    // define default levels, take into account only info, warning and severe messages
    StreamHandler sh = new StreamHandler(System.out, new LightFormatter());
    setHandler(Logger.getLogger("choco"), sh);

    sh = new StreamHandler(System.out, new LightFormatter());
    setHandler(Logger.getLogger("choco.search"), sh);

    sh = new StreamHandler(System.out, new LightFormatter());
    setHandler(Logger.getLogger("choco.prop"), sh);

    // Some loggers for debug purposes... not available for final user !
    Logger.getLogger("choco.prop.const").setLevel(Level.SEVERE);
    Logger.getLogger("choco.mem").setLevel(Level.SEVERE);
    Logger.getLogger("choco.test").setLevel(Level.SEVERE);
  }

  private static void setHandler(Logger l, Handler h) {
    // remove existing handler on choco logger and define choco handler
    // the handler defined here could be reused by other packages
    l.setUseParentHandlers(false);
    Handler[] handlers = l.getHandlers();
    for (int i = 0; i < handlers.length; i++) {
      l.removeHandler(handlers[i]);
    }
    // by default, handle (so print) only severe message, it could be modified in other package
    l.addHandler(h);
  }

  public static void setVerbosity(int verbosity) {
    switch (verbosity) {
      case SOLUTION:
        setVerbosity(Logger.getLogger("choco"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search.branching"), Level.SEVERE);
        setVerbosity(Logger.getLogger("choco.prop"), Level.SEVERE);
        break;
      case SEARCH:
        setVerbosity(Logger.getLogger("choco"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search.branching"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.prop"), Level.SEVERE);
        break;
      case PROPAGATION:
        setVerbosity(Logger.getLogger("choco"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.search.branching"), Level.ALL);
        setVerbosity(Logger.getLogger("choco.prop"), Level.INFO);
        break;
      case SILENT:
      default:
        setVerbosity(Logger.getLogger("choco"), Level.SEVERE);
        setVerbosity(Logger.getLogger("choco.search"), Level.SEVERE);
        setVerbosity(Logger.getLogger("choco.search.branching"), Level.SEVERE);
        setVerbosity(Logger.getLogger("choco.prop"), Level.SEVERE);
    }
  }

  public static void flushLogs() {
    flushLog(Logger.getLogger("choco"));
    flushLog(Logger.getLogger("choco.search"));
    flushLog(Logger.getLogger("choco.search.branching"));
    flushLog(Logger.getLogger("choco.prop"));
  }

  /**
   * Sets the level of log for the Logger and the Handler. This means that
   * inherited loggers will have at least same level if they do not have
   * custom handler.
   *
   * @param logger the logger to modify its level
   * @param level  the new level
   */
  protected static void setVerbosity(Logger logger, Level level) {
    logger.setLevel(level);
    Handler[] handlers = logger.getHandlers();
    for (int i = 0; i < handlers.length; i++) {
      handlers[i].setLevel(level);
    }
  }

  protected static void flushLog(Logger log) {
    Handler[] handlers = log.getHandlers();
    for (int i = 0; i < handlers.length; i++) {
      handlers[i].flush();
    }
  }

  // **********************************************************************
  //                       END OF LOGGERS MANAGEMENT
  // **********************************************************************

}
