package choco.integer.search;

import choco.Constraint;
import choco.ContradictionException;
import choco.branch.ConstraintSelector;
import choco.branch.VarSelector;
import choco.integer.IntConstraint;
import choco.integer.IntDomainVar;

/**
 * A class that composes two heuristics for selecting a variable:
 *   a first heuristic is appled for selecting a constraint.
 *   from that constraint a second heuristic is applied for selecting the variable
 */
public class CompositeIntVarSelector extends AbstractIntVarSelector implements VarSelector {
  protected ConstraintSelector cs;
  protected HeuristicIntVarSelector cvs;

  public CompositeIntVarSelector(ConstraintSelector cs, HeuristicIntVarSelector cvs) {
    this.cs = cs;
    this.cvs = cvs;
  }

  public IntDomainVar selectIntVar() throws ContradictionException {
    Constraint c = cs.getConstraint();
    if (c == null) return null;
    else return cvs.getMinVar((IntConstraint) c);
  }
}
