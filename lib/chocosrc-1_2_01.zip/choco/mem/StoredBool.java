// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.mem;

import java.util.logging.Logger;

/**
 * A class implementing backtrackable booleans.
 */
public final class StoredBool implements IStateBool {
  /**
   * Reference to an object for logging trace statements related memory & backtrack (using the java.util.logging package)
   */

  private static Logger logger = Logger.getLogger("choco.mem");

  /**
   * The current {@link choco.mem.Environment}.
   */

  private Environment environment;


  /**
   * Current value of the search.
   */

  private boolean currentValue;


  /**
   * The last world the search was moidified in.
   */

  int worldStamp;


  /**
   * The current {@link choco.mem.StoredIntTrail}.
   */

  private final StoredBoolTrail trail;


  /**
   * Constructs a stored search with an initial value.
   * Note: this constructor should not be used directly: one should instead
   * use the Environment factory
   */

  public StoredBool(Environment env, boolean b) {
    environment = env;
    currentValue = b;
    worldStamp = env.currentWorld;
    trail = (StoredBoolTrail) this.environment.getTrail(Environment.BOOL_TRAIL);
  }


  /**
   * Returns the current value.
   */

  public boolean get() {
    return currentValue;
  }

  /**
   * Modifies the value and stores if needed the former value on the
   * trailing stack.
   */

  public void set(boolean b) {
    if (b != currentValue) {
      if (this.worldStamp < environment.currentWorld) {
        trail.savePreviousState(this, currentValue, worldStamp);
        worldStamp = environment.currentWorld;
      }
      currentValue = b;
    }
  }

  /**
   * Modifies the value without storing the former value on the trailing stack.
   *
   * @param b      the new value
   * @param wstamp the stamp of the world in which the update is performed
   */

  void _set(boolean b, int wstamp) {
    currentValue = b;
    worldStamp = wstamp;
  }

  /**
   * Retrieving the environment
   */
  public Environment getEnvironment() {
    return environment;
  }

  public String toString() {
    return String.valueOf(currentValue);
  }

}

