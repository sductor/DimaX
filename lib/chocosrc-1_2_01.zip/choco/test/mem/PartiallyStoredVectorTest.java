package choco.test.mem;

import choco.mem.Environment;
import choco.mem.PartiallyStoredVector;
import junit.framework.TestCase;

import java.util.logging.Logger;

public class PartiallyStoredVectorTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Environment env;
  private PartiallyStoredVector vector;

  protected void setUp() {
    logger.fine("StoredIntVector Testing...");

    env = new Environment();
    vector = env.makePartiallyStoredVector();
  }

  protected void tearDown() {
    vector = null;
    env = null;
  }

  /**
   * testing the empty constructor with a few backtracks, additions, and updates
   */
  public void test1() {
    logger.finer("test1");
    assertEquals(0, env.getWorldIndex());
    assertTrue(vector.isEmpty());
    env.worldPush();
    assertEquals(1, env.getWorldIndex());
    vector.add(new Integer(0));
    vector.add(new Integer(1));
    env.worldPush();
    assertEquals(2, env.getWorldIndex());
    vector.add(new Integer(2));
    vector.add(new Integer(3));
    vector.staticAdd(new Integer(4));
    assert(vector.size() == 5);
    env.worldPop();
    assert(vector.size() == 3);
    assertEquals(1, env.getWorldIndex());
    env.worldPop();
    assert(vector.size() == 1);
    assertEquals(0, env.getWorldIndex());
  }
}
