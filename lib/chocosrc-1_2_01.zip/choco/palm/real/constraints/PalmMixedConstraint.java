package choco.palm.real.constraints;

import choco.palm.integer.PalmIntVarListener;
import choco.palm.real.PalmRealVarListener;
import choco.real.constraint.MixedConstraint;

/**
 * Mixed constraint: such constraints handle both integer
 * and real variables (and their events).
 */
public interface PalmMixedConstraint extends MixedConstraint,
    PalmRealVarListener, PalmIntVarListener {
}
