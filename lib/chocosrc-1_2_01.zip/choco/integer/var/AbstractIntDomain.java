// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.var;

import choco.AbstractEntity;
import choco.ContradictionException;
import choco.prop.VarEvent;
import choco.util.IntIterator;

import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class AbstractIntDomain extends AbstractEntity implements IntDomain {
  /**
   * Reference to an object for logging trace statements related to domains of search variables (using the java.util.logging package)
   */
  protected static Logger logger = Logger.getLogger("choco.prop");

  /**
   * The involved variable.
   */
  protected choco.integer.var.IntDomainVarImpl variable;

  /**
   * for the delta domain: current value of the inf (domain lower bound) when the bound started beeing propagated
   * (just to check that it does not change during the propagation phase)
   */
  protected int currentInfPropagated;

  /**
   * for the delta domain: current value of the sup (domain upper bound) when the bound started beeing propagated
   * (just to check that it does not change during the propagation phase)
   */
  protected int currentSupPropagated;

  /**
   * Returns an getIterator.
   */

  public IntIterator getIterator() {
    return new IntDomainIterator(this);
  }


  protected class IntDomainIterator implements IntIterator {
    protected AbstractIntDomain domain;
    protected int currentValue = Integer.MIN_VALUE;

    private IntDomainIterator(AbstractIntDomain dom) {
      domain = dom;
      currentValue = Integer.MIN_VALUE; // dom.getInf();
    }

    public boolean hasNext() {
      return (Integer.MIN_VALUE == currentValue) ? true : (currentValue < domain.getSup());
    }

    public int next() {
      currentValue = (Integer.MIN_VALUE == currentValue) ? domain.getInf() : domain.getNextValue(currentValue);
      return currentValue;
    }

    public void remove() {
      if (currentValue == Integer.MIN_VALUE) {
        throw new IllegalStateException();
      } else {
        throw new UnsupportedOperationException();
      }
    }
  }

  /**
   * Internal var: update on the variable upper bound caused by its i-th
   * constraint.
   * Returns a boolean indicating whether the call indeed added new information.
   *
   * @param x   The new upper bound
   * @param idx The index of the constraint (among all constraints linked to
   *            the variable) responsible for the update
   */
  public boolean updateSup(int x, int idx) throws ContradictionException {
    if (_updateSup(x)) {
      int cause = VarEvent.NOCAUSE;
      if (getSup() == x) cause = idx;
      if (getInf() == getSup())
        instantiate(getSup(), cause);
      else
        problem.getPropagationEngine().postUpdateSup(variable, cause);
      return true;
    } else
      return false;
  }

  /**
   * Internal var: update on the variable lower bound caused by its i-th
   * constraint.
   * Returns a boolean indicating whether the call indeed added new information
   *
   * @param x   The new lower bound.
   * @param idx The index of the constraint (among all constraints linked to
   *            the variable) responsible for the update.
   */

  public boolean updateInf(int x, int idx) throws ContradictionException {
    int oldinf = getInf();
    if (_updateInf(x)) {
      int cause = VarEvent.NOCAUSE;
      if (getInf() == x) cause = idx;
      if (getSup() == getInf())
        instantiate(getInf(), cause);
      else
        problem.getPropagationEngine().postUpdateInf(variable, cause);
      // TODO      problem.getChocEngine().postUpdateInf(variable, cause, oldinf);
      return true;
    } else
      return false;
  }

  /**
   * Internal var: update (value removal) on the domain of a variable caused by
   * its i-th constraint.
   * <i>Note:</i> Whenever the hole results in a stronger var (such as a bound update or
   * an instantiation, then we forget about the index of the var generating constraint.
   * Indeed the propagated var is stronger than the initial one that
   * was generated; thus the generating constraint should be informed
   * about such a new var.
   * Returns a boolean indicating whether the call indeed added new information.
   *
   * @param x   The removed value
   * @param idx The index of the constraint (among all constraints linked to the variable) responsible for the update
   */

  public boolean removeVal(int x, int idx) throws ContradictionException {
    if (_removeVal(x)) {
      if (logger.isLoggable(Level.FINEST))
        logger.finest("REM(" + this.toString() + "): " + x);
      if (getInf() == getSup())
        problem.getPropagationEngine().postInstInt(variable, VarEvent.NOCAUSE);
      else if (x < getInf())
        problem.getPropagationEngine().postUpdateInf(variable, VarEvent.NOCAUSE);
      else if (x > getSup())
        problem.getPropagationEngine().postUpdateSup(variable, VarEvent.NOCAUSE);
      else
        problem.getPropagationEngine().postRemoveVal(variable, x, idx);
      return true;
    } else
      return false;
  }


  /**
   * Internal var: remove an interval (a sequence of consecutive values) from
   * the domain of a variable caused by its i-th constraint.
   * Returns a boolean indicating whether the call indeed added new information.
   *
   * @param a   the first removed value
   * @param b   the last removed value
   * @param idx the index of the constraint (among all constraints linked to the variable)
   *            responsible for the update
   */

  public boolean removeInterval(int a, int b, int idx) throws ContradictionException {
    if (a <= getInf())
      return updateInf(b + 1, idx);
    else if (getSup() <= b)
      return updateSup(a - 1, idx);
    else if (variable.hasEnumeratedDomain()) {     // TODO: really ugly .........
      boolean anyChange = false;
      for (int v = a; v <= b; v++) {
        if (removeVal(v, idx))
          anyChange = true;
      }
      return anyChange;
    } else
      return false;
  }

  /**
   * Internal var: instantiation of the variable caused by its i-th constraint
   * Returns a boolean indicating whether the call indeed added new information.
   *
   * @param x   the new upper bound
   * @param idx the index of the constraint (among all constraints linked to the
   *            variable) responsible for the update
   */

  public boolean instantiate(int x, int idx) throws ContradictionException {
    if (_instantiate(x)) {
      if (logger.isLoggable(Level.FINEST))
        logger.finest("INST(" + this.toString() + "): " + x);
      problem.getPropagationEngine().postInstInt(variable, idx);
      return true;
    } else
      return false;
  }


// ============================================
  // Private methods for maintaining the
  // domain.
  // ============================================

  /**
   * Instantiating a variable to an search value. Returns true if this was
   * a real modification or not
   */

  protected boolean _instantiate(int x) throws ContradictionException {
    if (variable.isInstantiated()) {
      if (variable.getVal() != x) {
        throw new ContradictionException(this);
      } else
        return false;
    } else {
      if ((x < getInf()) || (x > getSup()))
        throw new ContradictionException(getProblem());
      else if (contains(x)) {
        restrict(x);
      } else {
        throw new ContradictionException(this);
      }
      updateSup(x);
      updateInf(x);
      variable.value.set(x);
      return true;
    }
  }


  /**
   * Improving the lower bound.
   */

  // note: one could have thrown an OutOfDomainException in case (x > IStateInt.MAXINT)
  protected boolean _updateInf(int x) throws ContradictionException {
    if (x > getInf()) {
      if (x > getSup()) {
        throw new ContradictionException(this);
      } else {
        updateInf(x);
        return true;
      }
    } else {
      return false;
    }
  }


  /**
   * Improving the upper bound.
   */
  protected boolean _updateSup(int x) throws ContradictionException {
    if (x < getSup()) {
      if (x < getInf()) {
        //if (x < IStateInt.MININT)
        throw new ContradictionException(this);
      } else {
        updateSup(x);
        return true;
      }
    } else {
      return false;
    }
  }

  /**
   * Removing a value from the domain of a variable. Returns true if this
   * was a real modification on the domain.
   */
  protected boolean _removeVal(int x) throws ContradictionException {
    int infv = getInf(), supv = getSup();
    if (infv <= x && x <= supv) {
      if (x == infv) {
        _updateInf(x + 1);
        if (getInf() == supv) _instantiate(supv);
        return true;
      } else if (x == supv) {
        _updateSup(x - 1);
        if (getSup() == infv) _instantiate(infv);
        return true;
      } else {
        return remove(x);
      }
    } else {
      return false;
    }
  }

  public void freezeDeltaDomain() {
    currentInfPropagated = getInf();
    currentSupPropagated = getSup();
  }

  public boolean releaseDeltaDomain() {
    boolean noNewUpdate = ((getInf() == currentInfPropagated) && (getSup() == currentSupPropagated));
    currentInfPropagated = Integer.MIN_VALUE;
    currentSupPropagated = Integer.MAX_VALUE;
    return noNewUpdate;
  }

  public void clearDeltaDomain() {
    currentInfPropagated = Integer.MIN_VALUE;
    currentSupPropagated = Integer.MAX_VALUE;
  }

  public boolean getReleasedDeltaDomain() {
    return true;
  }
}
