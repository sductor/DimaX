// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.search;

import choco.AbstractProblem;
import choco.integer.IntDomainVar;

public final class MinDomain extends IntHeuristicIntVarSelector {
  public MinDomain(AbstractProblem pb) {
    super(pb);
  }

  public MinDomain(AbstractProblem pb, IntDomainVar[] vs) {
    super(pb);
    vars = vs;
  }

  public int getHeuristic(IntDomainVar v) {
    return v.getDomainSize();
  }

}
