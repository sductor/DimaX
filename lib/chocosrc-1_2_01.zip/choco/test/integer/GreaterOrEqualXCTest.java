// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* File choco.test.search.GreaterOrEqualXCTest.java, last modified by Francois 23 ao�t 2003:17:40:29 */
package choco.test.integer;

import choco.Constraint;
import choco.ContradictionException;
import choco.Problem;
import junit.framework.TestCase;

import java.util.logging.Logger;

public class GreaterOrEqualXCTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar x;
  private choco.integer.IntDomainVar y;
  private Constraint c1;
  private Constraint c2;

  protected void setUp() {
    logger.fine("GreaterOrEqualXCTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVar("X", 1, 5);
    y = pb.makeBoundIntVar("Y", 1, 5);
    c1 = pb.geq(x, 1);
    c2 = pb.geq(y, 2);
  }

  protected void tearDown() {
    c1 = null;
    c2 = null;
    x = null;
    y = null;
    pb = null;
  }

  public void test1() {
    logger.finer("test1");
    try {
      pb.post(c1);
      pb.post(c2);
      pb.propagate();
      assertFalse(x.isInstantiated());
      assertFalse(y.isInstantiated());
      assertEquals(1, x.getInf());
      assertEquals(2, y.getInf());
      logger.finest("domains OK after first propagate");
      assertTrue(c1.isSatisfied());
      assertTrue(c2.isSatisfied());
    } catch (ContradictionException e) {
      assertTrue(false);
    }
  }
}
