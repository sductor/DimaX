package choco.test.bool;

import junit.framework.Test;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2004         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* FileTestSuite.java, last modified by Fran�ois, 8 avr. 2004 */

public class TestSuite extends junit.framework.TestSuite {
  private static Logger logger = Logger.getLogger("choco.test");

  public static Test suite() {
    choco.test.bool.TestSuite test = new choco.test.bool.TestSuite();

    logger.fine("Build TestSuite for choco.test.bool");
    test.addTestSuite(BoolRewriteTest.class);
    test.addTestSuite(BoolConnectTest.class);
    test.addTestSuite(BinDisjunctionTest.class);
    test.addTestSuite(EquivTest.class);
    test.addTestSuite(CardinalityTest.class);
    test.addTestSuite(BooleanSearchTest.class);
    test.addTestSuite(SolveTest.class);

    return test;
  }
}
