// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.search;

import choco.integer.IntDomainVar;
import choco.search.AbstractSearchHeuristic;

public class MinVal extends AbstractSearchHeuristic implements ValSelector {
  /**
   * selecting the lowest value in the domain
   *
   * @param x the variable under consideration
   * @return what seems the most interesting value for branching
   */
  public int getBestVal(IntDomainVar x) {
    return x.getInf();
  }
}
