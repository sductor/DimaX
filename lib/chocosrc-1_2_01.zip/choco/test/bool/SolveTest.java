package choco.test.bool;

import choco.Constraint;
import choco.ContradictionException;
import choco.Problem;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

/**
 * Some tests for solving problems with boolean expressions
 */

public class SolveTest extends TestCase {
  public void testBugMaurice1a() {
    int tMax = 10;
    Problem pb = new Problem();
    IntDomainVar S = pb.makeBoundIntVar("S", 0, tMax);
    int p = 4;
    IntDomainVar[] y = new IntDomainVar[11];
    for (int t = 0; t <= tMax; t++) {
      y[t] = pb.makeBoundIntVar("y_" + t, 0, 1);
      Constraint cst;
      cst = pb.implies(pb.eq(y[t], 1),
          pb.and(pb.geq(t, S),
              pb.lt(t, pb.plus(S, p))));
      pb.post(cst);
      Constraint cst2 = pb.implies(pb.and(pb.geq(t, S), pb.lt(t, pb.plus(S, p))),
          pb.eq(y[t], 1));
      pb.post(cst2);
    }

    try {
      pb.propagate();
      pb.solve();
      int nbSolution = 0;
      do {
        nbSolution++;
        System.out.print("S = " + S.getVal() + "   \t");
        for (int i = 0; i < y.length; i++) {
          IntDomainVar intVar = y[i];
          System.out.print(intVar + " = " + intVar.getVal() + "   ");
        }
        System.out.println("");
      } while (pb.nextSolution().booleanValue());
      assertEquals(11, nbSolution);
    } catch (ContradictionException e) {
      e.printStackTrace();
    }
  }

  public void testBugMaurice1b() {
    int tMax = 10;
    Problem pb = new Problem();
    IntDomainVar S = pb.makeBoundIntVar("S", 0, tMax);
    int p = 4;
    IntDomainVar[] y = new IntDomainVar[11];
    for (int t = 0; t <= tMax; t++) {
      y[t] = pb.makeBoundIntVar("y_" + t, 0, 1);
      Constraint cst;
      cst = pb.ifThen(pb.eq(y[t], 1),
          pb.and(pb.geq(t, S),
              pb.lt(t, pb.plus(S, p))));
      pb.post(cst);
      Constraint cst2 = pb.ifThen(pb.and(pb.geq(t, S), pb.lt(t, pb.plus(S, p))),
          pb.eq(y[t], 1));
      pb.post(cst2);
    }

    try {
      pb.propagate();
      pb.solve();
      int nbSolution = 0;
      do {
        nbSolution++;
        System.out.print("S = " + S.getVal() + "   \t");
        for (int i = 0; i < y.length; i++) {
          IntDomainVar intVar = y[i];
          System.out.print(intVar + " = " + intVar.getVal() + "   ");
        }
        System.out.println("");
      } while (pb.nextSolution().booleanValue());
      assertEquals(11, nbSolution);
    } catch (ContradictionException e) {
      e.printStackTrace();
    }
  }

  public void testBugMaurice1c() {
    int tMax = 10;
    Problem pb = new Problem();
    IntDomainVar S = pb.makeBoundIntVar("S", 0, tMax);
    int p = 4;
    IntDomainVar[] y = new IntDomainVar[11];
    for (int t = 0; t <= tMax; t++) {
      y[t] = pb.makeBoundIntVar("y_" + t, 0, 1);
      Constraint cst;
      cst = pb.ifOnlyIf(pb.eq(y[t], 1),
          pb.and(pb.geq(t, S),
              pb.lt(t, pb.plus(S, p))));
      pb.post(cst);
    }

    try {
      pb.propagate();
      pb.solve();
      int nbSolution = 0;
      do {
        nbSolution++;
        System.out.print("S = " + S.getVal() + "   \t");
        for (int i = 0; i < y.length; i++) {
          IntDomainVar intVar = y[i];
          System.out.print(intVar + " = " + intVar.getVal() + "   ");
        }
        System.out.println("");
      } while (pb.nextSolution().booleanValue());
      assertEquals(11, nbSolution);
    } catch (ContradictionException e) {
      e.printStackTrace();
    }
  }
}
