// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.search;

import choco.integer.IntDomainVar;

/**
 * A variable selector selecting the first non instantiated variable according to a given static order
 */
public class StaticVarOrder extends AbstractIntVarSelector {

  public StaticVarOrder(IntDomainVar[] vars) {
    this.vars = vars;
  }

  public IntDomainVar selectIntVar() {
    for (int i = 0; i < vars.length; i++) {
      if (!vars[i].isInstantiated()) {
        return vars[i];
      }
    }
    return null;
  }
}
