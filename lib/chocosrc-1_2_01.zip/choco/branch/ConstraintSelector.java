package choco.branch;

import choco.Constraint;

/**
 * A class that applies ta heuristic for selecting a constraint
 *  (which, in turn, can be used later to select a variable, by means of a CompositeIntVarSelector)
 */
public interface ConstraintSelector {
  public Constraint getConstraint();
}
