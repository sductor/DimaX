package choco.test.global;

import choco.AbstractProblem;
import choco.Problem;
import choco.integer.IntDomainVar;
import choco.integer.search.RandomIntValSelector;
import choco.integer.search.RandomIntVarSelector;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: Hadrien
 * Date: 27 mars 2006
 * Time: 10:03:39
 * To change this template use File | Settings | File Templates.
 */
public class CumulativeTest extends TestCase {

    public static void test1() { // nb solutions : 2
        for (int seed = 0; seed< 10; seed++) {
            AbstractProblem pb = new Problem();
            IntDomainVar d1 = pb.makeEnumIntVar("d1", 2, 2);
            IntDomainVar d2 = pb.makeEnumIntVar("d2", 2, 2);
            IntDomainVar d3 = pb.makeEnumIntVar("d3", 1, 1);
            IntDomainVar[] durations = new IntDomainVar[]{d1,d2,d3};
            IntDomainVar[] starts = new IntDomainVar[3];
            IntDomainVar[] ends = new IntDomainVar[3];
            for (int i = 0; i < 3; i++) {
                starts[i] = pb.makeEnumIntVar("s" +i,0,3);
                ends[i] = pb.makeEnumIntVar("e" +i,0,3);
            }

            pb.post(pb.cumulative(starts,ends,durations,new int[]{2,1,3},3));

            pb.getSolver().setValSelector(new RandomIntValSelector((long) seed));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb,(long) seed + 1002));//, t2, t3}));
            pb.solveAll();
            //System.out.println(seed + " nbSol " + pb.getSolver().getNbSolutions());
            assertEquals(2,pb.getSolver().getNbSolutions());
        }
    }

    public static void test2() { // nb solutions 208
        for (int seed = 0; seed< 20; seed++) {
            AbstractProblem pb = new Problem();
            IntDomainVar d1 = pb.makeEnumIntVar("d1", 4, 10);
            IntDomainVar d2 = pb.makeEnumIntVar("d2", 3, 3);
            IntDomainVar d3 = pb.makeEnumIntVar("d3", 1, 1);
            IntDomainVar d4 = pb.makeEnumIntVar("d4", 8, 12);
            IntDomainVar d5 = pb.makeEnumIntVar("d5", 2, 2);
            IntDomainVar[] durations = new IntDomainVar[]{d1,d2,d3,d4,d5};
            IntDomainVar[] starts = new IntDomainVar[5];
            IntDomainVar[] ends = new IntDomainVar[5];
            for (int i = 0; i < 5; i++) {
                starts[i] = pb.makeEnumIntVar("s" +i,0,11);
                ends[i] = pb.makeEnumIntVar("e" +i,0,11);
            }

            pb.post(pb.cumulative(starts,ends,durations,new int[]{2,2,3,1,4},4));

            pb.getSolver().setValSelector(new RandomIntValSelector((long) seed));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb,(long) seed + 1002));//, t2, t3}));
            pb.solveAll();
            //System.out.println(seed + " nbSol " + pb.getSolver().getNbSolutions());
            assertEquals(208,pb.getSolver().getNbSolutions());
            //System.out.println("Node " + ((NodeLimit) pb.getSolver().getSearchSolver().limits.get(1)).getNbTot());
        }
    }

    public static void test3() { // nb solutions
        for (int seed = 0; seed< 20; seed++) {
            AbstractProblem pb = new Problem();
            IntDomainVar[] durations = new IntDomainVar[5];
            IntDomainVar[] starts = new IntDomainVar[5];
            IntDomainVar[] ends = new IntDomainVar[5];
            IntDomainVar[] heigths = new IntDomainVar[5];
            for (int i = 0; i < 5; i++) {
                durations[i] = pb.makeBoundIntVar("d",2,2);
                heigths[i] = pb.makeBoundIntVar("h",2,4);
                starts[i] = pb.makeBoundIntVar("s" + i,0,6);
                ends[i] = pb.makeBoundIntVar("e" + i,0,6);
            }

            pb.post(pb.cumulative(starts,ends,durations,heigths,4));

            pb.getSolver().setValSelector(new RandomIntValSelector((long) seed));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb,(long) seed + 1002));//, t2, t3}));
            pb.solveAll();
            System.out.println(seed + " nbSol " + pb.getSolver().getNbSolutions());
            assertEquals(510,pb.getSolver().getNbSolutions());
            //System.out.println("Node " + ((NodeLimit) pb.getSolver().getSearchSolver().limits.get(1)).getNbTot());
        }
    }

    public static void test4() { // nb solutions
            for (int seed = 0; seed< 20; seed++) {
                int n = 3;
                AbstractProblem pb = new Problem();
                IntDomainVar[] durations = new IntDomainVar[n];
                IntDomainVar[] starts = new IntDomainVar[n];
                IntDomainVar[] ends = new IntDomainVar[n];
                IntDomainVar[] heigths = new IntDomainVar[n];
                for (int i = 0; i < n; i++) {
                    durations[i] = pb.makeBoundIntVar("d",2,2);
                    heigths[i] = pb.makeBoundIntVar("h",3,4);
                    starts[i] = pb.makeBoundIntVar("s" + i,0,6);
                    ends[i] = pb.makeBoundIntVar("e" + i,0,6);
                }

                pb.post(pb.cumulative(starts,ends,durations,heigths,4));

                pb.getSolver().setValSelector(new RandomIntValSelector((long) seed));
                pb.getSolver().setVarSelector(new RandomIntVarSelector(pb,(long) seed + 1002));//, t2, t3}));
                pb.solveAll();
                System.out.println("" + pb.getSolver().getNbSolutions());
                /*for (int i = 0; i < n; i++) {
                    System.out.println(starts[i].getVal() + " + " + durations[i].getVal() + " = " + ends[i].getVal() + "("+ heigths[i].getVal() + ")");

                }*/

            }
        }


    // 0 nodes with taskIntervals, 836 otherwise
    public static void test5TaskInterval() {
        for (int seed = 0; seed< 10; seed++) {
            try {
                int n = 10;
                AbstractProblem pb = new Problem();
                IntDomainVar[] durations = new IntDomainVar[n];
                IntDomainVar[] starts = new IntDomainVar[n];
                IntDomainVar[] ends = new IntDomainVar[n];
                int[] h = new int[n];
                for (int i = 0; i < n; i++) {
                    durations[i] = pb.makeEnumIntVar("t" + i, 2, 2);
                    starts[i] = pb.makeEnumIntVar("t" + i, 0, 4);
                    ends[i] = pb.makeEnumIntVar("t" + i, 0, 4);
                    h[i]= 1;
                }

                pb.post(pb.cumulative(starts,ends,durations,h, 4));
                pb.getSolver().setValSelector(new RandomIntValSelector((long) seed));
                pb.getSolver().setVarSelector(new RandomIntVarSelector(pb,(long) seed + 1002));

                pb.solveAll();
                assertEquals(0,pb.getSolver().getNbSolutions());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
