// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************

package choco;

import choco.bool.*;
import choco.global.BoundAllDiff;
import choco.global.Cumulative;
import choco.global.Lex;
import choco.global.Occurrence;
import choco.global.matching.AllDifferent;
import choco.global.matching.GlobalCardinality;
import choco.integer.IntDomainVar;
import choco.integer.IntVar;
import choco.integer.constraints.*;
import choco.integer.constraints.extension.*;
import choco.integer.var.IntDomainVarImpl;
import choco.mem.Environment;
import choco.mem.IStateInt;
import choco.mem.PartiallyStoredVector;
import choco.prop.ConstraintEvent;
import choco.prop.PropagationEngine;
import choco.real.RealExp;
import choco.real.RealVar;
import choco.real.constraint.Equation;
import choco.real.exp.*;
import choco.real.var.RealVarImpl;
import choco.set.SetVar;
import choco.set.constraint.*;
import choco.set.var.SetVarImpl;
import choco.util.UtilAlgo;

/**
 * A problem is a global structure containing variables bound by listeners
 * as well as solutions or solver parameters
 */
public class Problem extends AbstractProblem {

    /**
     * an index useful for re-propagating cuts (static constraints)
     * upon backtracking
     */
    public IStateInt indexOfLastInitializedStaticConstraint;

    /**
     * Constructs a problem.
     *
     * @param env the Environment responsible for all the memory management
     */

    public Problem(Environment env) {
        super();
        this.environment = env;
        this.constraints = env.makePartiallyStoredVector();
        this.indexOfLastInitializedStaticConstraint = env.makeInt(PartiallyStoredVector.getFirstStaticIndex() - 1);
    }

    /**
     * Constructs a problem.
     */

    public Problem() {
        this(new Environment());
    }

    /**
     * <i>Network management:</i>
     * adding a constraint to the problem. Note that this does not propagate anything !
     * This addition of a constraint is local to the current search (sub)tree: the constraint
     * will be un-posted upon backtracking
     *
     * @param cc the constraint to add
     */

    public void post(Constraint cc) {
        if (cc instanceof Propagator) {
            Propagator c = (Propagator) cc;
            constraints.add(c);
            c.addListener(true);
            ConstraintEvent event = (ConstraintEvent) c.getEvent();
            PropagationEngine pe = getPropagationEngine();
            pe.registerEvent(event);
            pe.postConstAwake(c, true);
            this.nbConstraint++;
        } else {
            throw new Error("impossible to post to a Problem constraints that are not Propagators");
        }
    }

    /**
     * <i>Network management:</i>
     * adding a constraint to the problem. Note that this does not propagate anything !
     * This addition of a constraint is global: the constraint
     * will NOT be un-posted upon backtracking
     *
     * @param cc the constraint to add
     */

    public void postCut(Constraint cc) {
        if (cc instanceof Propagator) {
            Propagator c = (Propagator) cc;
            int idx = constraints.staticAdd(c);
            indexOfLastInitializedStaticConstraint.set(idx);
            c.addListener(false);
            ConstraintEvent event = (ConstraintEvent) c.getEvent();
            PropagationEngine pe = getPropagationEngine();
            pe.registerEvent(event);
            pe.postConstAwake(c, true);
            this.nbConstraint++;
        } else {
            throw new Error("impossible to post to a Problem cuts that are not Propagators");
        }

    }

    /**
     * popping one world from the stack:
     * overrides AbstractProblem.worldPop because the Problem class adds
     * the notion of static constraints that need be repropagated upon backtracking
     */
    public final void worldPop() {
        super.worldPop();
        int lastStaticIdx = constraints.getLastStaticIndex();
        for (int i = indexOfLastInitializedStaticConstraint.get() + 1; i <= lastStaticIdx; i++) {
            Propagator c = (Propagator) constraints.get(i);
            if (c != null) {
                c.constAwake(true);
            }
        }
    }

    // All abstract methods for constructing constraint
    // that need be defined by a Problem implementing a model

    protected Constraint createEqualXC(IntVar v, int c) {
        if (v instanceof IntDomainVar) {
            return new EqualXC((IntDomainVar) v, c);
        } else
            return null;
    }

    protected Constraint createNotEqualXC(IntVar v, int c) {
        if (v instanceof IntDomainVar) {
            return new NotEqualXC((IntDomainVar) v, c);
        } else {
            return null;
        }
    }

    protected Constraint createGreaterOrEqualXC(IntVar v, int c) {
        if (v instanceof IntDomainVar) {
            return new GreaterOrEqualXC((IntDomainVar) v, c);
        } else {
            return null;
        }
    }

    protected Constraint createLessOrEqualXC(IntVar v, int c) {
        if (v instanceof IntDomainVar) {
            return new LessOrEqualXC((IntDomainVar) v, c);
        } else {
            return null;
        }
    }

    protected Constraint createEqualXYC(IntVar v0, IntVar v1, int c) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new EqualXYC((IntDomainVar) v0, (IntDomainVar) v1, c);
        } else {
            return null;
        }
    }

    protected Constraint createNotEqualXYC(IntVar v0, IntVar v1, int c) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new NotEqualXYC((IntDomainVar) v0, (IntDomainVar) v1, c);
        } else {
            return null;
        }
    }

    protected Constraint createGreaterOrEqualXYC(IntVar v0, IntVar v1, int c) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new GreaterOrEqualXYC((IntDomainVar) v0, (IntDomainVar) v1, c);
        } else {
            return null;
        }
    }

    protected Constraint createTimesXYZ(IntVar x, IntVar y, IntVar z) {
        if ((x instanceof IntDomainVar) &&
                (y instanceof IntDomainVar) &&
                (z instanceof IntDomainVar)) {
            return new TimesXYZ((IntDomainVar) x, (IntDomainVar) y, (IntDomainVar) z);
        } else {
            return null;
        }
    }

    protected Constraint createIntLinComb(IntVar[] sortedVars, int[] sortedCoeffs, int nbPositiveCoeffs, int c, int linOperator) {
        IntDomainVar[] tmpVars = new IntDomainVar[sortedVars.length];
        System.arraycopy(sortedVars, 0, tmpVars, 0, sortedVars.length);
        if (isBoolLinComb(tmpVars,sortedCoeffs,linOperator))
            return createBoolLinComb(tmpVars,sortedCoeffs,c,linOperator);
        else return new IntLinComb(tmpVars, sortedCoeffs, nbPositiveCoeffs, c, linOperator);
    }

    /**
     * Check if the combination is made of a single integer variable and only boolean variables
     */
    protected boolean isBoolLinComb(IntDomainVar[] lvars, int[] lcoeffs,int linOperator) {
        if (linOperator == IntLinComb.NEQ) return false;
        if (lvars.length <= 1) return false;
        int nbEnum = 0;
        for (int i = 0; i < lvars.length; i++) {
            if (!lvars[i].hasBooleanDomain())
                nbEnum ++;
            if (nbEnum > 1) return false;
        }
        return true;
    }

    protected Constraint createBoolLinComb(IntVar[] vars, int[] lcoeffs, int c, int linOperator) {
        IntDomainVar[] lvars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, lvars, 0, vars.length);
        int idxSingleEnum = -1;                  // index of the enum intvar (the single non boolean var)
        int coefSingleEnum = Integer.MIN_VALUE;  // coefficient of the enum intvar
        for (int i = 0; i < lvars.length; i++) {
            if (!lvars[i].hasBooleanDomain()) {
                idxSingleEnum = i;
                coefSingleEnum = -lcoeffs[i];
            }
        }
        // construct arrays of coefficients and variables
        int nbVar = (idxSingleEnum == -1) ? lvars.length : lvars.length - 1;
        IntDomainVar[] vs = new IntDomainVar[nbVar];
        int[] coefs = new int[nbVar];
        int cpt = 0;
        for (int i = 0; i < lvars.length; i++) {
            if (i != idxSingleEnum) {
                vs[cpt] = lvars[i];
                coefs[cpt] = lcoeffs[i];
                cpt++;
            }
        }
        if (idxSingleEnum == -1)        // the constant c has  already been reversed
            return createBoolLinComb(vs,coefs,null,Integer.MAX_VALUE,c,linOperator);
        else
            return createBoolLinComb(vs,coefs,lvars[idxSingleEnum],coefSingleEnum,c, linOperator);
    }

    protected Constraint createBoolLinComb(IntDomainVar[] vs, int[] coefs, IntDomainVar obj, int objcoef, int c, int linOperator) {
        UtilAlgo.quicksort(coefs, vs, 0, coefs.length - 1);
        if (obj == null) { // is there an enum variable ?
            IntDomainVar dummyObj = (IntDomainVar) makeConstantIntVar(-c);
            return new BoolIntLinComb(vs, coefs, dummyObj, 1, 0, linOperator);
        } else {
            int newLinOp = linOperator;
            if (objcoef < 0) {
                if (linOperator != IntLinComb.NEQ) {
                    objcoef = -objcoef;
                    c = -c;
                    UtilAlgo.reverse(coefs, vs);
                    UtilAlgo.inverseSign(coefs);
                }
                if (linOperator == IntLinComb.GEQ) {
                    newLinOp = IntLinComb.LEQ;
                } else if (linOperator == IntLinComb.LEQ) {
                    newLinOp = IntLinComb.GEQ;
                }
            }
            return new BoolIntLinComb(vs, coefs, obj, objcoef, c, newLinOp);
        }
    }


    protected Constraint createAC3BinConstraint(IntVar v0, IntVar v1, BinRelation relation) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new AC3BinConstraint((IntDomainVar) v0, (IntDomainVar) v1, relation);
        } else {
            return null;
        }
    }

    protected Constraint createAC4BinConstraint(IntVar v0, IntVar v1, BinRelation relation) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new AC4BinConstraint((IntDomainVar) v0, (IntDomainVar) v1, relation);
        } else {
            return null;
        }
    }

    protected Constraint createAC2001BinConstraint(IntVar v0, IntVar v1, BinRelation relation) {
        if ((v0 instanceof IntDomainVar) && (v1 instanceof IntDomainVar)) {
            return new AC2001BinConstraint((IntDomainVar) v0, (IntDomainVar) v1, relation);
        } else {
            return null;
        }
    }

    protected Constraint createCspLargeConstraint(IntVar[] vars, LargeRelation relation) {
        IntDomainVar[] tmpVars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, tmpVars, 0, vars.length);
        return new CspLargeConstraint(tmpVars, relation);
    }

    protected Constraint createSubscript(IntVar index, int[] values, IntVar val, int offset) {
        if ((index instanceof IntDomainVar) && (val instanceof IntDomainVar)) {
            return new Element((IntDomainVar) index, values, (IntDomainVar) val, offset);
        } else {
            return null;
        }
    }

    protected Constraint createSubscript(IntVar index, IntVar[] varArray, IntVar val, int offset) {
        if ((index instanceof IntDomainVar) && (val instanceof IntDomainVar)) {
            if (((IntDomainVar) index).hasEnumeratedDomain()) {
                IntDomainVar[] allVars = new IntDomainVar[varArray.length + 2];
                for (int i = 0; i < varArray.length; i++) {
                    allVars[i] = (IntDomainVar) varArray[i];
                }
                allVars[varArray.length] = (IntDomainVar) index;
                allVars[varArray.length + 1] = (IntDomainVar) val;
                return new ElementV(allVars, offset);
            } else {
                throw new Error("BoundConsistency is not implemented on nth! " + index + " should be an Enumerated variable instead of a BoundIntVar");
            }
        } else {
            throw new Error("variables " + index + " and " + val + " should be IntDomainVar in nth");
        }
    }

    protected Constraint createBoolChanneling(IntVar boolv, IntVar intv, int j) {
        return new BooleanChanneling((IntDomainVar) boolv, (IntDomainVar) intv, j);
    }

    protected Constraint createInverseChanneling(IntVar[] x, IntVar[] y) {
        int n = x.length;
        if (y.length != n) {
            throw new Error("not a valid inverse channeling constraint with two arrays of different sizes");
        }
        IntDomainVar[] allVars = new IntDomainVar[2 * n];
        for (int i = 0; i < n; i++) {
            allVars[i] = (IntDomainVar) x[i];
        }
        for (int i = 0; i < n; i++) {
            allVars[n + i] = (IntDomainVar) y[i];
        }
        return new InverseChanneling(allVars, n);
    }

    protected Constraint createBinDisjunction(Constraint c0, Constraint c1) {
        return new BinDisjunction((AbstractConstraint) c0, (AbstractConstraint) c1);
    }

    protected Constraint createLargeDisjunction(Constraint[] alternatives) {
        return new LargeDisjunction(alternatives);
    }

    protected Constraint createBinConjunction(Constraint c0, Constraint c1) {
        return new BinConjunction((AbstractConstraint) c0, (AbstractConstraint) c1);
    }

    protected Constraint createLargeConjunction(Constraint[] alternatives) {
        return new LargeConjunction(alternatives);
    }

    protected Constraint createGuard(Constraint c0, Constraint c1) {
        return new Guard((AbstractConstraint) c0, (AbstractConstraint) c1);
    }

    protected Constraint createEquiv(Constraint c0, Constraint c1) {
        return new Equiv((AbstractConstraint) c0, (AbstractConstraint) c1);
    }

    protected Constraint createCardinality(Constraint[] constList, IntVar cardVar, boolean constrainOnInf, boolean constrainOnSup) {
        if (cardVar instanceof IntDomainVar) {
            IntDomainVar v = (IntDomainVar) cardVar;
            return new Cardinality(constList, v, constrainOnInf, constrainOnSup);
        } else
            return null;
    }

    protected Constraint createOccurrence(IntVar[] vars, int occval, boolean onInf, boolean onSup) {
        IntDomainVar[] tmpVars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, tmpVars, 0, vars.length);
        return new Occurrence(tmpVars, occval, onInf, onSup);
    }

    protected Constraint createAllDifferent(IntVar[] vars) {
        IntDomainVar[] tmpVars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, tmpVars, 0, vars.length);
        return new AllDifferent(tmpVars);
    }

    protected Constraint createBoundAllDiff(IntVar[] vars, boolean global) {
        IntDomainVar[] tmpVars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, tmpVars, 0, vars.length);
        return new BoundAllDiff(tmpVars, global);
    }

    protected Constraint createGlobalCardinality(IntVar[] vars, int min, int max, int[] low, int[] up) {
        IntDomainVar[] tmpVars = new IntDomainVar[vars.length];
        System.arraycopy(vars, 0, tmpVars, 0, vars.length);
        return new GlobalCardinality(tmpVars, min, max, low, up);
    }

    protected Constraint createCumulative(IntVar[] sts, IntVar[] ends, IntVar[] durations, int[] h, int Capa) {
        int n = sts.length;
        IntVar[] heigthVars = new IntDomainVar[n];
        for (int i = 0; i < n; i++) {
            heigthVars[i] = makeConstantIntVar(h[i]);
        }
        return createCumulative(sts, ends, durations, heigthVars, Capa);
    }

    protected Constraint createCumulative(IntVar[] sts, IntVar[] ends, IntVar[] durations, IntVar[] heigths, int Capa) {
        int n = sts.length;
        IntDomainVar[] startVars = new IntDomainVar[n];
        System.arraycopy(sts, 0, startVars, 0, n);
        IntDomainVar[] endsVars = new IntDomainVar[n];
        System.arraycopy(ends, 0, endsVars, 0, n);
        IntDomainVar[] durationsVars = new IntDomainVar[n];
        System.arraycopy(durations, 0, durationsVars, 0, n);
        IntDomainVar[] heigthVars = new IntDomainVar[n];
        System.arraycopy(heigths, 0, heigthVars, 0, n);
        return new Cumulative(startVars, endsVars, durationsVars, heigthVars, Capa);
    }

    protected Constraint createLex(IntVar[] v1, IntVar[] v2, boolean strict) {
        int n = v1.length;
        IntDomainVar[] vs = new IntDomainVar[2 * n];
        System.arraycopy(v1, 0, vs, 0, n);
        System.arraycopy(v2, 0, vs, n, n);
        return new Lex(vs, v1.length, strict);
    }

    protected IntDomainVar createIntVar(String name, int domainType, int min, int max) {
        return new IntDomainVarImpl(this, name, domainType, min, max);
    }

    protected IntDomainVar createIntVar(String name, int[] sortedValues) {
        return new IntDomainVarImpl(this, name, sortedValues);
    }

    protected RealVar createRealVal(String name, double min, double max) {
        return new RealVarImpl(this, name, min, max);
    }

    protected RealIntervalConstant createRealIntervalConstant(double a, double b) {
        return new RealIntervalConstant(a, b);
    }

    protected RealExp createRealSin(RealExp exp) {
        return new RealSin(this, exp);
    }

    protected RealExp createRealCos(RealExp exp) {
        return new RealCos(this, exp);
    }

    protected RealExp createRealIntegerPower(RealExp exp, int power) {
        return new RealIntegerPower(this, exp, power);
    }

    protected RealExp createRealPlus(RealExp exp1, RealExp exp2) {
        return new RealPlus(this, exp1, exp2);
    }

    protected RealExp createRealMinus(RealExp exp1, RealExp exp2) {
        return new RealMinus(this, exp1, exp2);
    }

    protected RealExp createRealMult(RealExp exp1, RealExp exp2) {
        return new RealMult(this, exp1, exp2);
    }

    protected Constraint createEquation(RealVar[] tmpVars, RealExp exp, RealIntervalConstant cst) {
        return new Equation(this, tmpVars, exp, cst);
    }

    protected SetVar createSetVar(String name, int a, int b) {
        return new SetVarImpl(this, name, a, b);
    }

    protected Constraint createMemberXY(SetVar sv1, IntVar var) {
        if (var instanceof IntDomainVar) {
            IntDomainVar v = (IntDomainVar) var;
            return new MemberXY(sv1, v);
        } else
            return null;
    }

    protected Constraint createNotMemberXY(SetVar sv1, IntVar var) {
        if (var instanceof IntDomainVar) {
            IntDomainVar v = (IntDomainVar) var;
            return new NotMemberXY(sv1, v);
        } else
            return null;
    }

    protected Constraint createMemberX(SetVar sv1, int val) {
        return new MemberX(sv1, val);
    }

    protected Constraint createNotMemberX(SetVar sv1, int val) {
        return new NotMemberX(sv1, val);
    }

    protected Constraint createDisjoint(SetVar sv1, SetVar sv2) {
        return new Disjoint(sv1, sv2);
    }

    protected Constraint createSetIntersection(SetVar sv1, SetVar sv2, SetVar inter) {
        return new SetIntersection(sv1, sv2, inter);
    }

    protected Constraint createSetCard(SetVar sv, IntVar var, boolean b1, boolean b2) {
        if (var instanceof IntDomainVar) {
            IntDomainVar v = (IntDomainVar) var;
            return new SetCard(sv, v, b1, b2);
        } else
            return null;
    }


    public Boolean solve(boolean all) {
        solver.firstSolution = !all;
        solver.generateSearchSolver(this);
//    solver.getSearchSolver().incrementalRun();
        solver.launch();
        return isFeasible();
    }

    public Boolean solve() {
        solver.firstSolution = true;
        solver.generateSearchSolver(this);
        solver.launch();
        return isFeasible();
    }

    public Boolean solveAll() {
        solver.firstSolution = false;
        solver.generateSearchSolver(this);
        solver.launch();
        return isFeasible();
    }

    /**
     * <i>Resolution:</i>
     * Searches for the solution minimizing the objective criterion.
     *
     * @param obj     The variable modelling the optimization criterion
     * @param restart If true, then a new search is restarted from scratch
     *                after each solution is found;
     *                otherwise a single branch-and-bound search is performed
     */

    public Boolean minimize(Var obj, boolean restart) {
        return optimize(false, obj, restart);
    }

    protected Boolean optimize(boolean maximize, Var obj, boolean restart) {
        solver.setDoMaximize(maximize);
        solver.setObjective(obj);
        solver.setRestart(restart);
        solver.setFirstSolution(false);
        solver.generateSearchSolver(this);
        solver.launch();
        return this.isFeasible();
    }

    /**
     * <i>resolution:</i>
     * Searches for the solution maximizing the objective criterion.
     *
     * @param obj     The variable modelling the optimization criterion
     * @param restart If true, then a new search is restarted from scratch
     *                after each solution is found;
     *                otherwise a single branch-and-bound search is performed
     */
    public Boolean maximize(Var obj, boolean restart) {
        return optimize(true, obj, restart);
    }

}