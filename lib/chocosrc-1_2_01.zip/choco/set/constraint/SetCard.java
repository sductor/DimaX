package choco.set.constraint;

import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.set.SetVar;
import choco.util.IntIterator;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public class SetCard extends AbstractBinSetIntConstraint {

  // operator pour la contrainte de cardinalit� :
  // inf & !sup -> card(set) <= int
  // sup & !inf -> card(set) => int
  // inf && sup -> card(set) = int
  protected boolean inf = false;
  protected boolean sup = false;

  public SetCard(SetVar sv, IntDomainVar iv, boolean inf, boolean sup) {
    super(iv, sv);
    this.inf = inf;
    this.sup = sup;
  }

  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  public void reactOnInfAndEnvEvents(int envSize) throws ContradictionException {
    if (v0.getInf() > envSize)
      this.fail();
    else if (v0.getInf() == envSize) {
      IntIterator it = v1.getDomain().getOpenDomainIterator();
      while (it.hasNext())
        v1.addToKernel(it.next(), cIdx1);
    }
  }

  public void reactOnSupAndKerEvents(int kerSize) throws ContradictionException {
    if (v0.getSup() < kerSize)
      this.fail();
    else if (v0.getSup() == kerSize) {
      IntIterator it = v1.getDomain().getOpenDomainIterator();
      while (it.hasNext())
        v1.remFromEnveloppe(it.next(), cIdx1);
    }
  }

  public void filter() throws ContradictionException {
    int envSize = v1.getEnveloppeDomainSize();
    int kerSize = v1.getKernelDomainSize();
    if (inf && sup) {
      if (v0.getSup() < kerSize || v0.getInf() > envSize)
        this.fail();
      else if (kerSize < envSize) {
        if (v0.getInf() == envSize) {
          IntIterator it = v1.getDomain().getOpenDomainIterator();
          while (it.hasNext())
            v1.addToKernel(it.next(), cIdx1);
        } else if (v0.getSup() == kerSize) {
          IntIterator it = v1.getDomain().getOpenDomainIterator();
          while (it.hasNext())
            v1.remFromEnveloppe(it.next(), cIdx1);
        }
      }
    } else if (inf) {
      if (v0.getSup() < kerSize)
        this.fail();
      else if (kerSize < envSize) {
        if (v0.getSup() == kerSize) {
          IntIterator it = v1.getDomain().getOpenDomainIterator();
          while (it.hasNext())
            v1.remFromEnveloppe(it.next(), cIdx1);
        }
      }
    } else {
      if (v0.getInf() > envSize)
        this.fail();
      else if (kerSize < envSize) {
        if (v0.getInf() == envSize) {
          IntIterator it = v1.getDomain().getOpenDomainIterator();
          while (it.hasNext())
            v1.addToKernel(it.next(), cIdx1);
        }
      }
    }
  }

  public void awakeOnInf(int idx) throws ContradictionException {
    if (inf) reactOnInfAndEnvEvents(v1.getEnveloppeDomainSize());
  }

  public void awakeOnSup(int idx) throws ContradictionException {
    if (sup) reactOnSupAndKerEvents(v1.getKernelDomainSize());
  }

  public void awakeOnRemovals(int idx, IntIterator deltaDomain) throws ContradictionException {
    filter();
  }

  public void awakeOnkerAdditions(int idx, IntIterator deltaDomain) throws ContradictionException {
    if (inf) {
      int kerSize = v1.getKernelDomainSize();
      v0.updateInf(kerSize, cIdx0);
      reactOnSupAndKerEvents(kerSize);
    }
  }

  public void awakeOnEnvRemovals(int idx, IntIterator deltaDomain) throws ContradictionException {
    if (sup) {
      int envSize = v1.getEnveloppeDomainSize();
      v0.updateSup(envSize, cIdx0);
      reactOnInfAndEnvEvents(envSize);
    }
  }


  public void awakeOnInst(int varIdx) throws ContradictionException {
    if (varIdx == 1) {
      int kerSize = v1.getKernelDomainSize();
      if (inf && sup)
        v0.instantiate(kerSize, cIdx0);
      else if (inf)
        v0.updateInf(kerSize, cIdx0);
      else
        v0.updateSup(kerSize, cIdx0);
    } else {
      filter();
    }
  }

  public boolean isSatisfied() {
    if (inf && sup)
      return v1.getKernelDomainSize() == v0.getVal();
    else if (inf)
      return v1.getKernelDomainSize() <= v0.getVal();
    else
      return v1.getKernelDomainSize() >= v0.getVal();
  }

  public void awake() throws ContradictionException {
    if (inf && sup) {
      v0.updateInf(v1.getKernelDomainSize(), cIdx0);
      v0.updateSup(v1.getEnveloppeDomainSize(), cIdx0);
    } else if (inf) {
      v0.updateInf(v1.getKernelDomainSize(), cIdx0);
    } else
      v0.updateSup(v1.getEnveloppeDomainSize(), cIdx0);
  }

  public void propagate() throws ContradictionException {
    filter();
  }

  public boolean isConsistent() {
    return (v1.isInstantiated() && v0.isInstantiated() && isSatisfied());
  }

  public Boolean isEntailed() {
    if (inf & sup) {
      if (v0.getInf() > v1.getEnveloppeDomainSize())
        return Boolean.FALSE;
      else if (v0.getSup() < v1.getKernelDomainSize())
        return Boolean.FALSE;
      else if (v0.isInstantiated() && v1.isInstantiated())
        return Boolean.TRUE;
      else
        return null;
    } else if (inf) {
      if (v0.getSup() < v1.getKernelDomainSize())
        return Boolean.FALSE;
      else if (v0.isInstantiated() && v1.isInstantiated())
        return Boolean.TRUE;
      else
        return null;
    } else {
      if (v0.getInf() > v1.getEnveloppeDomainSize())
        return Boolean.FALSE;
      else if (v0.isInstantiated() && v1.isInstantiated())
        return Boolean.TRUE;
      else
        return null;
    }

  }
}
