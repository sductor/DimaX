/** -------------------------------------------------
 *                   J-CHOCO
 *   Copyright (C) F. Laburthe, 1999-2003
 * --------------------------------------------------
 *    an open-source Constraint Programming Kernel
 *          for Research and Education
 * --------------------------------------------------
 *
 * file: choco.test.util.TestSuite.java
 * last modified by Francois 28 ao�t 2003:14:59:09
 */
package choco.test.util;

import junit.framework.Test;

import java.util.logging.Logger;

public class TestSuite extends junit.framework.TestSuite {
  private static Logger logger = Logger.getLogger("choco.test");

  public static Test suite() {
    TestSuite test = new TestSuite();

    logger.fine("Build TestSuite for choco.test.util");
    test.addTestSuite(BitSetTest.class);
    test.addTestSuite(BipartiteSetTest.class);
    test.addTestSuite(PriorityQueueTest.class);
    test.addTestSuite(StoredPointerCycleTest.class);

    return test;
  }
}
