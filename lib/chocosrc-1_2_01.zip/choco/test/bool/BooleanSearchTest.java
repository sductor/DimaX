package choco.test.bool;

import choco.Problem;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

/**
 * J-CHOCO
 * Copyright (C) F. Laburthe, 1999-2003
 * <p/>
 * An open-source Constraint Programming Kernel
 * for Research and Education
 * <p/>
 * Created by: Guillaume on 30 juin 2004
 */
public class BooleanSearchTest extends TestCase {
  public void testOrBoundVar() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 3);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 3);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 3);

    pb.post(pb.or(pb.lt(x, y), pb.lt(y, x)));
    pb.post(pb.or(pb.lt(y, z), pb.lt(z, y)));

    pb.solveAll();

    assertEquals(12, pb.getSolver().getNbSolutions());
  }

  public void testOrEnumVar() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeEnumIntVar("x", 1, 3);
    IntDomainVar y = pb.makeEnumIntVar("y", 1, 3);
    IntDomainVar z = pb.makeEnumIntVar("z", 1, 3);

    pb.post(pb.or(pb.lt(x, y), pb.lt(y, x)));
    pb.post(pb.or(pb.lt(y, z), pb.lt(z, y)));

    pb.solveAll();

    assertEquals(12, pb.getSolver().getNbSolutions());
  }

  public void testEquiv() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 3);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 3);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 3);

    pb.post(pb.ifOnlyIf(pb.lt(x, y), pb.lt(y, z)));

    pb.solveAll();

    assertEquals(11, pb.getSolver().getNbSolutions());
  }

  public void testGuard() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 2);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 2);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 2);

    pb.post(pb.ifThen(pb.leq(x, y), pb.leq(x, z)));

    pb.solveAll();

    assertEquals(7, pb.getSolver().getNbSolutions());
  }

  public void testImplies() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 2);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 2);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 2);

    pb.post(pb.implies(pb.leq(x, y), pb.leq(x, z)));

    pb.solveAll();

    assertEquals(7, pb.getSolver().getNbSolutions());
  }

  public void testAnd() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 3);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 3);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 3);

    pb.post(pb.implies(pb.lt(x, 2), pb.and(pb.lt(x, y), pb.lt(y, z))));

    pb.solveAll();

    assertEquals(19, pb.getSolver().getNbSolutions());
  }

  public void testLargeOr() {
    Problem pb = new Problem();
    IntDomainVar x = pb.makeBoundIntVar("x", 1, 2);
    IntDomainVar y = pb.makeBoundIntVar("y", 1, 2);
    IntDomainVar z = pb.makeBoundIntVar("z", 1, 2);

    pb.post(pb.or(pb.lt(x, y), pb.lt(x, z), pb.lt(y, z)));

    pb.solveAll();

    assertEquals(4, pb.getSolver().getNbSolutions());
  }
}
