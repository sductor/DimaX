// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.search;

import choco.ContradictionException;
import choco.branch.VarSelector;
import choco.integer.IntDomainVar;

/**
 * an interface for objects controlling the selection of an search variable (for heuristic purposes)
 */
public interface IntVarSelector extends VarSelector {
  /**
   * the IIntVarSelector can be asked to return an {@link choco.integer.var.IntDomainVarImpl}
   *
   * @return a non instantiated search variable
   */
  public IntDomainVar selectIntVar() throws ContradictionException;
}
