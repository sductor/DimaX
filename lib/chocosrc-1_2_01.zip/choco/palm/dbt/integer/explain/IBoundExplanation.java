package choco.palm.dbt.integer.explain;

import choco.palm.dbt.integer.PalmIntVar;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public interface IBoundExplanation {

  public int getPreviousValue();


  public PalmIntVar getVariable();


}
