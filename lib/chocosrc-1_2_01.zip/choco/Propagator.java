// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco;

import choco.bool.AbstractCompositeConstraint;
import choco.prop.ConstraintPlugin;
import choco.prop.PropagationEvent;
import choco.prop.VarEventListener;

/**
 * An interface for all implementations of listeners.
 */
public interface Propagator extends VarEventListener, Constraint {

  /**
   * Returns the constraint plugin. Useful for extending the solver.
   */

  public ConstraintPlugin getPlugIn();


  /**
   * <i>Utility:</i>
   * Testing if all variables involved in the constraint are instantiated.
   */

  public boolean isCompletelyInstantiated();


  /**
   * Forces a propagation of the constraint.
   */

  public void constAwake(boolean isInitialPropagation);


  /**
   * <i>Propagation:</i>
   * Propagating the constraint for the very first time until local
   * consistency is reached.
   */

  public void awake() throws ContradictionException;


  /**
   * <i>Propagation:</i>
   * Propagating the constraint when the domain of a variable has been
   * modified (shrunk) since the last consistent state.
   */

  public void awakeOnVar(int idx) throws ContradictionException;


  /**
   * <i>Propagation:</i>
   * Propagating the constraint until local consistency is reached.
   */

  public void propagate() throws ContradictionException;


  /**
   * <i>Propagation:</i>
   * Accessing the priority level of the queue handling the propagation
   * of the constraint. Results range from 1 (most reactive, for listeners
   * with fast propagation algorithms) to 4 (most delayed, for listeners
   * with lengthy propagation algorithms).
   */

  public int getPriority();


  /**
   * Removes a constraint from the network.
   * Beware, this is a permanent removal, it may not be backtracked
   */

  public void delete();

  /**
   * Returns the constraint awake var associated with this constraint.
   */

  public PropagationEvent getEvent();

  /**
   * Checks whether the constraint is definitely satisfied, no matter what further restrictions
   * occur to the domain of its variables.
   */
  public Boolean isEntailed();

  /**
   * tests if the constraint is consistent with respect to the current state of domains
   */
  public boolean isConsistent();

  /**
   * performs the global numbering (wrt root) of the variables contained in the subtree this, starting from i
   *
   * @param root            the overall root constraint, for which the variables are numbered
   * @param i               the index that will assigned to the first variable in the subtree this (originally 0)
   * @param dynamicAddition whether the addition is undone automatically on backtracking
   * @return the index of the last variable in the subtree
   */
  public int assignIndices(AbstractCompositeConstraint root, int i, boolean dynamicAddition);

}