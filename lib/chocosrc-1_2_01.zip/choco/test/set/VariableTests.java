package choco.test.set;

import choco.ContradictionException;
import choco.Problem;
import choco.set.SetVar;
import choco.util.IntIterator;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public class VariableTests extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");

  public void test1() {
    logger.finer("test1");
    Problem pb = new Problem();
    SetVar x = pb.makeSetVar("X", 1, 5);
    try {
      x.addToKernel(2, -1);
      x.addToKernel(4, -1);
    } catch (ContradictionException e) {
      assertTrue(false);
    }
    IntIterator it = x.getDomain().getOpenDomainIterator();
    while (it.hasNext()) {
      int val = it.next();
      System.out.println("" + val);
      assertTrue(val != 2);
      assertTrue(val != 4);
    }
  }
}
