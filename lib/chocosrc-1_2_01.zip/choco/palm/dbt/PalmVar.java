package choco.palm.dbt;

import choco.Constraint;
import choco.palm.ExplainedVar;


public interface PalmVar extends ExplainedVar {

  /**
   * Returns the decision constraint for the ith branch on the current domain.
   */

  public Constraint getDecisionConstraint(int val);
}
