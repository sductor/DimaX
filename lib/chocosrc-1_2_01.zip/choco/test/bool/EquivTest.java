package choco.test.bool;

import choco.Constraint;
import choco.ContradictionException;
import choco.Problem;
import choco.bool.Equiv;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* File choco.test.bool.EquivTest.java, last modified by flaburthe 14 avr. 2004 15:36:50 */

/**
 * a class implementing tests for the connection of boolean constequivalence raints
 */
public class EquivTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar[] x;
  //private Constraint a, b, c, d, e, f, g;

  protected void setUp() {
    logger.fine("choco.test.bool.EquivTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVarArray("X", 10, 0, 1000);
    /*c = pb.lt(x[0], 3);
    d = pb.lt(pb.plus(x[1], x[2]), x[0]);
    e = pb.neq(pb.minus(x[1], x[2]), pb.plus(x[0], 7));
    f = pb.gt(x[4], 7);
    g = pb.leq(pb.scalar(new int[]{12, 32, 25}, new IntDomainVar[]{x[5], x[7], x[9]}), 9837);*/
  }

  protected void tearDown() {
    x = null;
    /*a = null;
    b = null;
    c = null;
    d = null;
    e = null;
    f = null;
    g = null; */
    pb = null;
  }

  public void test1() {
    logger.finer("test1");
    pb.post(pb.geq(x[0], x[4]));
    pb.post(pb.leq(x[0], x[5]));
    Equiv equiv = (Equiv) pb.ifOnlyIf(pb.eq(x[0], 3), pb.gt(x[1], 5));
    pb.post(equiv);
    try {
      x[0].setInf(4);
      pb.propagate();
      assertEquals(equiv.getStatus(0), Boolean.FALSE);
      assertEquals(x[1].getSup(), 5);
    } catch (ContradictionException e) {
      assertFalse(true);
    }
    for (int subConstIdx = 0; subConstIdx < equiv.getNbSubConstraints(); subConstIdx++) {
      Constraint subc = equiv.getSubConstraint(subConstIdx);
      Constraint oppsubc = equiv.getOppositeSubConstraint(subConstIdx);
      for (int varIdx = 0; varIdx < subc.getNbVars(); varIdx++) {
        int oppVarIdx = subc.getVarIdxInOpposite(varIdx);
        assertEquals(subc.getConstraintIdx(varIdx), oppsubc.getConstraintIdx(oppVarIdx));
      }
    }
  }

}
