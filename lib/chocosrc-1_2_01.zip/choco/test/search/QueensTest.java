package choco.test.search;

import choco.Problem;
import choco.Solver;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* File choco.test.search.QueensTest.java, last modified by flaburthe 12 janv. 2004 18:03:29 */

/**
 * A test placing n-queens on a chessboard, so that no two attack each other
 */
public class QueensTest extends TestCase {
  public static int nbQueensSolution[] = {0, 0, 0, 0, 2, 10, 4, 40, 92, 352, 724, 2680, 14200, 73712};
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar[] queens;

  protected void setUp() {
    logger.fine("Queens Testing...");
    pb = new Problem();
  }

  protected void tearDown() {
    pb = null;
    queens = null;
  }

  private void queen0(int n) {
    logger.finer("n queens, binary model, n=" + n);
    // create variables
    queens = new choco.integer.IntDomainVar[n];
    for (int i = 0; i < n; i++) {
      queens[i] = pb.makeEnumIntVar("Q" + i, 1, n);
    }
    // diagonal constraints
    for (int i = 0; i < n; i++) {
      for (int j = i + 1; j < n; j++) {
        int k = j - i;
        pb.post(pb.neq(queens[i], queens[j]));
        pb.post(pb.neq(queens[i], pb.plus(queens[j], k)));
        pb.post(pb.neq(queens[i], pb.minus(queens[j], k)));
      }
    }
    Solver s = pb.getSolver();
    pb.solve(true);
    if (n >= 4) {
      if (n <= 13) {
        assertEquals(Boolean.TRUE, pb.isFeasible());
        assertEquals(nbQueensSolution[n], s.getNbSolutions());
      }
    } else {
      assertEquals(Boolean.FALSE, pb.isFeasible());
    }
  }

  public void test0() {
    queen0(4);
  }

  public void test1() {
    queen0(5);
  }

  public void test2() {
    queen0(6);
  }

  public void test3() {
    queen0(7);
  }

  public void test4() {
    queen0(8);
  }

  public void test5() {
    queen0(9);
  }

  public void notest6() {
    queen0(10);
  }
  //  public void test7() { queen0(11); }

}