#population size
POP_SIZE=100

#ZDT number (1, 2)
EVAL=1

#vector Size
VEC_SIZE=30

#number of objectives
NB_OBJ=2

#PROBABIITY FOR SBXCROSSOVER
P_CROSS=1.0

#EXTERNAL PROBABILITY FOR POLYNOMIAL MUTATION
EXT_P_MUT=1.0

#INTERNAL PROBABILITY FOR POLYNOMIAL MUTATION
INT_P_MUT=0.083333

#number of evaluation
NB_EVAL=500

#Time 
TIME=0

NSGA="NSGAII.out"

./build/application/ZDT_NSGAII --eval=$i --vecSize=$VEC_SIZE --nbObj=$NB_OBJ --pCross=$P_CROSS --extPMut=$EXT_P_MUT --intPMut=$INT_P_MUT --nbEval=$NB_EVAL --time=$TIME -o=$NSGA

