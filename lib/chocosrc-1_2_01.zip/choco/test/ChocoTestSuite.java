package choco.test;

import junit.framework.Test;
import junit.framework.TestSuite;

import java.util.logging.Logger;

public class ChocoTestSuite extends TestSuite {
  private static Logger logger = Logger.getLogger("choco.test");

  public static Test suite() {
    TestSuite test = new ChocoTestSuite();

    logger.fine("Build main TestSuite for choco.test");
    test.addTest(choco.test.mem.TestSuite.suite());
    test.addTest(choco.test.integer.TestSuite.suite());
    test.addTest(choco.test.util.TestSuite.suite());
    test.addTest(choco.test.search.TestSuite.suite());
    test.addTest(choco.test.bool.TestSuite.suite());
    test.addTest(choco.test.set.TestSuite.suite());
    test.addTest(choco.test.real.RealTestSuite.suite());
    test.addTest(choco.test.global.TestSuite.suite());
    test.addTestSuite(choco.test.regression.RegressionTest.class);
//      test.addTestSuite(ChocoSolveTest.class);
    return test;
  }
}
