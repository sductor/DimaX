package choco.test.bool;

import choco.Problem;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2004         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* FileBinDisjunctionTest.java, last modified by Fran�ois, 8 avr. 2004 */

/**
 * a class implementing tests for backtrackable search
 */
public class BinDisjunctionTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar x, y;

  protected void setUp() {
    logger.fine("choco.test.bool.BitDisjunctionTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVar("X", 1, 100);
    y = pb.makeEnumIntVar("Y", 1, 15);
  }

  protected void tearDown() {
    y = null;
    x = null;
    pb = null;
  }

  public void test1() {
    logger.finer("test1");
  }

}