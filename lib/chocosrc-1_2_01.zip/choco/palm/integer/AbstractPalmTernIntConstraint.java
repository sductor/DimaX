package choco.palm.integer;

import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.integer.constraints.AbstractTernIntConstraint;
import choco.palm.PalmConstraint;
import choco.util.IntIterator;

/**
 * Created by IntelliJ IDEA.
 * User: Administrateur
 * Date: 30 janv. 2004
 * Time: 09:00:21
 * To change this template use Options | File Templates.
 */
public abstract class AbstractPalmTernIntConstraint
    extends AbstractTernIntConstraint
    implements PalmIntVarListener, PalmConstraint {

  public AbstractPalmTernIntConstraint(IntDomainVar x0, IntDomainVar x1, IntDomainVar x2) {
    super(x0,x1,x2);
  }

  public void takeIntoAccountStatusChange(int index) {
  }


  public void awakeOnRestoreInf(int index) throws ContradictionException {
    this.propagate();
  }

  public void awakeOnRestoreSup(int index) throws ContradictionException {
    this.propagate();
  }

  public void awakeOnInst(int idx) {
  }

  public void awakeOnRestoreVal(int idx, IntIterator repairDomain) throws ContradictionException {
    for (; repairDomain.hasNext();) {
      awakeOnRestoreVal(idx, repairDomain.next());
    }
  }

  public void updateDataStructuresOnConstraint(int idx, int select, int newValue, int oldValue) {
  }

  public void updateDataStructuresOnRestoreConstraint(int idx, int select, int newValue, int oldValue) {
  }
}
