package choco.test.bool;

import choco.Constraint;
import choco.Problem;
import choco.bool.CompositeConstraint;
import choco.bool.Equiv;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2004         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* file BoolConnectTest.java, last modified by Fran�ois, 8 avr. 2004 */

/**
 * a class implementing tests for the connection of boolean constraints
 */
public class BoolConnectTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar[] x;
  private Constraint c, d, e, f, g;
  private CompositeConstraint b;

  protected void setUp() {
    logger.fine("choco.test.bool.BitDisjunctionTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVarArray("X", 10, 0, 1000);
    c = pb.lt(x[0], 3);
    d = pb.lt(pb.plus(x[1], x[2]), x[0]);
    e = pb.neq(pb.minus(x[1], x[2]), pb.plus(x[0], 7));
    f = pb.gt(x[4], 7);
    g = pb.leq(pb.scalar(new int[]{12, 32, 25}, new IntDomainVar[]{x[5], x[7], x[9]}), 9837);
  }

  protected void tearDown() {
    x = null;
    c = null;
    d = null;
    e = null;
    f = null;
    g = null;
    b = null;
    pb = null;
  }

  private void checkVarCount(CompositeConstraint root) {
    int nbv = 0;
    for (int constIdx = 0; constIdx < root.getNbSubConstraints(); constIdx++) {
      nbv += root.getSubConstraint(constIdx).getNbVars();
    }
    assertEquals(root.getNbVars(), nbv);
  }

  private void checkVarIndices(CompositeConstraint root) {
    int nbv = 0;
    for (int constIdx = 0; constIdx < root.getNbSubConstraints(); constIdx++) {
      Constraint c = root.getSubConstraint(constIdx);
      for (int varIdx = 0; varIdx < c.getNbVars(); varIdx++) {
        assertEquals(root.getVar(nbv + varIdx), c.getVar(varIdx));
      }
      nbv += c.getNbVars();
    }
  }

  public void test1() {
    logger.finer("test1");
    b = (CompositeConstraint) pb.or(c, d);
    assertEquals(b.getNbSubConstraints(), 2);
    assertEquals(b.getSubConstraint(0), c);
    assertEquals(b.getSubConstraint(1), d);
    checkVarCount(b);
    checkVarIndices(b);
  }

  public void test2() {
    logger.finer("test2");
    b = (CompositeConstraint) pb.or(pb.or(e, f), g);
    assertEquals(b.getNbSubConstraints(), 3);
    assertEquals(b.getSubConstraint(0), e);
    assertEquals(b.getSubConstraint(1), f);
    assertEquals(b.getSubConstraint(2), g);
    checkVarCount(b);
    checkVarIndices(b);
  }


  public void test3() {
    logger.finer("test3");
    b = (CompositeConstraint) pb.or(e, pb.and(f, g));
    assertEquals(b.getNbSubConstraints(), 2);
    assertEquals(b.getSubConstraint(0), e);
    assertEquals(((CompositeConstraint) b.getSubConstraint(1)).getNbSubConstraints(), 2);
    assertEquals(((CompositeConstraint) b.getSubConstraint(1)).getSubConstraint(0), f);
    assertEquals(((CompositeConstraint) b.getSubConstraint(1)).getSubConstraint(1), g);
    checkVarCount(b);
    checkVarIndices(b);
  }

  public void test4() {
    logger.finer("test4");
    b = (CompositeConstraint) pb.implies(pb.and(c, d), pb.or(e, pb.and(f, g)));
    assertEquals(b.getNbSubConstraints(), 4);
    assertTrue(b.getSubConstraint(0).isEquivalentTo(pb.not(c)));
    assertTrue(b.getSubConstraint(1).isEquivalentTo(pb.not(d)));
    assertEquals(b.getSubConstraint(2), e);
    assertTrue(b.getSubConstraint(3).isEquivalentTo(pb.and(f, g)));
    checkVarCount(b);
    checkVarIndices(b);
  }

  public void test5() {
    logger.finer("test5");
    pb.post(d);
    pb.post(e);
    Equiv equiv = (Equiv) pb.ifOnlyIf(pb.and(d, e), pb.or(f, g));
    pb.post(equiv);
    for (int subConstIdx = 0; subConstIdx < equiv.getNbSubConstraints(); subConstIdx++) {
      Constraint subc = equiv.getSubConstraint(subConstIdx);
      Constraint oppsubc = equiv.getOppositeSubConstraint(subConstIdx);
      for (int varIdx = 0; varIdx < subc.getNbVars(); varIdx++) {
        int oppVarIdx = subc.getVarIdxInOpposite(varIdx);
        assertEquals(subc.getConstraintIdx(varIdx), oppsubc.getConstraintIdx(oppVarIdx));
      }
    }
  }

}