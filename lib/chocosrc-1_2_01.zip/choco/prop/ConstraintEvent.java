// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************

package choco.prop;

import choco.ContradictionException;
import choco.Propagator;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A class for constraint revisions in the propagation process.
 */
public class ConstraintEvent implements PropagationEvent {

  /**
   * The touched constraint.
   */

  private Propagator touchedConstraint;


  /**
   * Specifies if the constraint should be initialized.
   */

  private boolean initialized = false;


  /**
   * Returns the priority of the var.
   */

  private int priority = (-1);

  /**
   * Reference to an object for logging trace statements related to propagation events (using the java.util.logging package)
   */

  private static Logger logger = Logger.getLogger("choco.prop");

  /**
   * Constructs a new var with the specified values for the fileds.
   */

  public ConstraintEvent(Propagator constraint, boolean init, int prio) {
    this.touchedConstraint = constraint;
    this.initialized = init;
    this.priority = prio;
  }

  public Object getModifiedObject() {
    return touchedConstraint;
  }

  /**
   * Returns the priority of the var.
   */

  public int getPriority() {
    return priority;
  }


  /**
   * Propagates the var: awake or propagate depending on the init status.
   *
   * @throws choco.ContradictionException
   */

  public boolean propagateEvent() throws ContradictionException {
    if (this.initialized) {
      this.touchedConstraint.propagate();
    } else {
      this.touchedConstraint.awake();
    }
    return true;
  }


  /**
   * Returns if the constraint is initialized.
   */

  public boolean isInitialized() {
    return this.initialized;
  }


  /**
   * Sets if the constraint is initialized.
   */

  public void setInitialized(boolean init) {
    this.initialized = init;
  }


  /**
   * Testing whether an event is active in the propagation network
   */

  public boolean isActive(int idx) {
    return true;
  }


  /**
   * Clears the var. This should not be called with this kind of var.
   */

  public void clear() {
    if (logger.isLoggable(Level.WARNING))
      logger.warning("Const Awake Event does not need to be cleared !");
  }
}

