package choco.integer.search;

import choco.ContradictionException;

/**
 * An interface for control objects that model a heuristic selectying at the same time
 * a variable and a value from its domain
 */
public interface VarValPairSelector {
  IntVarValPair selectVarValPair() throws ContradictionException;
}
