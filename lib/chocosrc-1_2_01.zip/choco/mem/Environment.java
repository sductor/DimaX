// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.mem;

import java.util.logging.Logger;

/**
 * The root class for managing memory and sessions.
 * <p/>
 * A environment is associated to each problem.
 * It is responsible for managing backtrackable data.
 */
// new comment
public class Environment {

  /**
   * Index of the {@link choco.mem.StoredBoolTrail} for storing booleans.
   */

  public final static int BOOL_TRAIL = 0;


  /**
   * Index of the {@link choco.mem.StoredIntTrail} for storing integers.
   */

  public final static int INT_TRAIL = 1;


  /**
   * Index of the {@link choco.mem.StoredVectorTrail} for storing vectors.
   */

  public final static int VECTOR_TRAIL = 2;


  /**
   * Index of the {@link choco.mem.StoredIntVectorTrail} for storing
   * integer vectors.
   *
   * @see #trails
   */

  public final static int INT_VECTOR_TRAIL = 3;


  /**
   * Index of the {@link choco.mem.StoredFloatTrail} for storing
   * integer vectors.
   *
   * @see #trails
   */

  public final static int FLOAT_TRAIL = 4;

  /**
   * Index of the {@link choco.mem.StoredLongTrail} for storing
   * integer vectors.
   *
   * @see #trails
   */

  public final static int LONG_TRAIL = 5;

  /**
   * The maximum numbers of objects that a
   * {@link choco.mem.ITrailStorage} can handle.
   */

  private int maxHist;


  /**
   * The maximum numbers of worlds that a
   * {@link choco.mem.ITrailStorage} can handle.
   */

  private int maxWorld;


  /**
   * The current world number (should be less
   * than <code>maxWorld</code>).
   */

  public int currentWorld = 0;


  /**
   * Contains all the {@link choco.mem.ITrailStorage} trails for
   * storing different kinds of data.
   */

  protected ITrailStorage[] trails;

  /**
   * Reference to the root Logger object (using the java.util.logging package)
   */

  private static Logger logger = Logger.getLogger("choco");

  /**
   * capacity of the trailing stack (in terms of number of worlds that can be handled)
   */
  private int maxWorlds = 0;

  /**
   * Constructs a new <code>Environment</code> with
   * the default stack sizes : 50000 and 1000.
   */

  public Environment() {
    maxHist = 50000;
    maxWorld = 1000;
    trails = new ITrailStorage[]{
      new StoredBoolTrail(this, maxHist, maxWorld),
      new StoredIntTrail(this, maxHist, maxWorld),
      new StoredVectorTrail(this, maxHist, maxWorld),
      new StoredIntVectorTrail(this, maxHist, maxWorld),
      new StoredFloatTrail(this, maxHist, maxWorld),
      new StoredLongTrail(this, maxHist, maxWorld),
    };
  }

  /**
   * Returns the <code>i</code>th trail in the trail array.
   *
   * @param i index of the trail.
   */

  public ITrailStorage getTrail(int i) {
    return trails[i];
  }


  /**
   * Returns the world number.
   *
   * @see #currentWorld
   */

  public int getWorldIndex() {
    return currentWorld;
  }


  /**
   * Starts a new branch in the search tree.
   */

  public void worldPush() {
    for (int i = 0; i < trails.length; i++) {
      ITrailStorage trail = trails[i];
      trail.worldPush();
    }
    currentWorld++;
    if (currentWorld + 1 == maxWorld)
      resizeWorldCapacity(maxWorld * 3 / 2);
  }


  /**
   * Backtracks to the previous choice point in the search tree.
   */
  public void worldPop() {
    for (int i = 0; i < trails.length; i++) {
      ITrailStorage trail = trails[i];
      trail.worldPop();
    }
    currentWorld--;
  }

  /**
   * Accepts all modifications since the previous choice point in the search tree.
   */

  public void worldCommit() {
    if (currentWorld == 0) throw new IllegalStateException("Commit in world 0?");
    for (int i = 0; i < trails.length; i++) {
      ITrailStorage trail = trails[i];
      trail.worldCommit();
    }
    currentWorld--;
  }

  /**
   * Factory pattern: new IStateInt objects are created by the environment
   * (no initial value is assigned to the backtrackable search)
   */

  public IStateInt makeInt() {
    return new StoredInt(this);
  }

  /**
   * Factory pattern: new IStateInt objects are created by the environment
   *
   * @param initialValue the initial value of the backtrackable integer
   */

  public IStateInt makeInt(int initialValue) {
    return new StoredInt(this, initialValue);
  }

  /**
   * Factory pattern: new IStateBool objects are created by the environment
   *
   * @param initialValue the initial value of the backtrackable boolean
   */

  public IStateBool makeBool(boolean initialValue) {
    return new StoredBool(this, initialValue);
  }

  /**
   * Factory pattern: new IStateIntVector objects are created by the environment.
   * Creates an empty vector
   */

  public StoredIntVector makeIntVector() {
    return new StoredIntVector(this);
  }

  /**
   * Factory pattern: new IStateIntVector objects are created by the environment
   *
   * @param size         the number of entries in the vector
   * @param initialValue the common initial value for all entries (backtrackable integers)
   */

  public StoredIntVector makeIntVector(int size, int initialValue) {
    return new StoredIntVector(this, size, initialValue);
  }

  /**
   * Factory pattern: new IStateIntVector objects are created by the environment
   *
   * @param entries an array to be copied as set of initial contents of the vector
   */

  public StoredIntVector makeIntVector(int[] entries) {
    return new StoredIntVector(entries);
  }

  public PartiallyStoredVector makePartiallyStoredVector() {
    return new PartiallyStoredVector(this);
  }

  public PartiallyStoredIntVector makePartiallyStoredIntVector() {
    return new PartiallyStoredIntVector(this);
  }

  /**
   * Factory pattern: new StoredBitSetVector objects are created by the environment
   */
  public StoredBitSet makeBitSet(int size) {
    return new StoredBitSet(this, size);
  }

  public StoredBitSet makeBitSet(int[] entries) {
    return new StoredBitSet(this, 0);  // TODO
  }

  /**
   * Factory pattern: new IStateFloat objects are created by the environment
   * (no initial value is assigned to the backtrackable search)
   */

  public StoredFloat makeFloat() {
    return new StoredFloat(this);
  }

  /**
   * Factory pattern: new IStateFloat objects are created by the environment
   *
   * @param initialValue the initial value of the backtrackable search
   */

  public StoredFloat makeFloat(double initialValue) {
    return new StoredFloat(this, initialValue);
  }

  /**
   * returns the size of the trail
   */

  public int getTrailSize() {
    int s = 0;
    for (int i = 0; i < trails.length; i++)
      s += trails[i].getSize();
    return s;
  }

  /**
   * returns the size of the trail used for storing integers
   */

  public int getIntTrailSize() {
    return trails[INT_TRAIL].getSize();
  }

  /**
   * returns the size of the trail used for storing search arrays
   */

  public int getIntVectorTrailSize() {
    return trails[INT_VECTOR_TRAIL].getSize();
  }

  private void resizeWorldCapacity(int newWorldCapacity) {
    for (int i = 0; i < trails.length; i++)
      trails[i].resizeWorldCapacity(newWorldCapacity);
    maxWorld = newWorldCapacity;
  }
}

