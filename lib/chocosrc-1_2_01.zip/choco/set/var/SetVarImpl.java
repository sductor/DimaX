package choco.set.var;

import choco.AbstractProblem;
import choco.AbstractVar;
import choco.ContradictionException;
import choco.set.SetVar;
import choco.util.IntIterator;

/**
 * Created by IntelliJ IDEA.
 * User: Hadrien
 * Date: 6 juin 2004
 * Time: 14:22:32
 * To change this template use File | Settings | File Templates.
 */
public class SetVarImpl extends AbstractVar implements SetVar {

  protected SetDomainImpl domain;

  public SetVarImpl(AbstractProblem pb, String name, int a, int b) {
    super(pb, name);
    this.domain = new SetDomainImpl(this, a, b);
    this.event = new SetVarEvent(this);
  }

  public void fail() throws ContradictionException {
    this.fail();
  }

  public boolean isInstantiated() {
    return domain.isInstantiated();  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void setValIn(int x) throws ContradictionException {
    addToKernel(x, SetVarEvent.NOCAUSE);
  }

  public void setValOut(int x) throws ContradictionException {
    remFromEnveloppe(x, SetVarEvent.NOCAUSE);
  }

  public boolean isInDomainKernel(int x) {
    return domain.getKernelDomain().contains(x);
  }

  public boolean isInDomainEnveloppe(int x) {
    return domain.getEnveloppeDomain().contains(x);
  }

  public SetDomain getDomain() {
    return domain;
  }

  /**
   * Check if the both domain intersects
   *
   * @param x
   * @return
   */
  public boolean canBeEqualTo(SetVar x) {
    return false;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public int getKernelDomainSize() {
    return domain.getKernelDomain().getSize();
  }

  public int getEnveloppeDomainSize() {
    return domain.getEnveloppeDomain().getSize();
  }

  public int getEnveloppeInf() {
    return domain.getEnveloppeDomain().getFirstVal();
  }

  public int getEnveloppeSup() {
    return domain.getEnveloppeDomain().getLastVal();
  }

  public int getKernelInf() {
    return domain.getKernelDomain().getFirstVal();
  }

  public int getKernelSup() {
    return domain.getKernelDomain().getLastVal();
  }

  public int[] getValue() {
    int[] val = new int[getKernelDomainSize()];
    IntIterator it = domain.getKernelIterator();
    int i = 0;
    while (it.hasNext()) {
      val[i] = it.next();
      i++;
    }
    return val;
  }

  public void setVal(int[] val) throws ContradictionException {
    instantiate(val, SetVarEvent.NOCAUSE);
  }

  public boolean addToKernel(int x, int idx) throws ContradictionException {
    return domain.addToKernel(x, idx);
  }

  public boolean remFromEnveloppe(int x, int idx) throws ContradictionException {
    return domain.remFromEnveloppe(x, idx);
  }

  public boolean instantiate(int[] x, int idx) throws ContradictionException {
    return domain.instantiate(x, idx);
  }

  /**
   * pretty printing
   *
   * @return a String representation of the variable
   */
  public String pretty() {
    return (this.toString() + this.domain.pretty());
  }
}
