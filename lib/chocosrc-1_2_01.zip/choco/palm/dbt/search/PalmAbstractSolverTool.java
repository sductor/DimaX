//     ___  ___         PaLM library for Choco system
//    /__ \/ __\        (c) 2001 - 2004 -- Narendra Jussien
//   ____\ |/_____
//  /_____\/_____ \     PalmExplanation based constraint programming tool
// |/   (_)(_)   \|
//       \ /            Version 0.1
//       \ /            January 2004
//       \ /
// ______\_/_______     Contibutors: Fran�ois Laburthe, Hadrien Cambazard, Guillaume Rochart...

package choco.palm.dbt.search;

public abstract class PalmAbstractSolverTool {
  protected PalmGlobalSearchSolver manager;

  public PalmGlobalSearchSolver getManager() {
    return manager;
  }

  public void setManager(PalmGlobalSearchSolver manager) {
    this.manager = manager;
  }
}
