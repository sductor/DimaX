package choco.test.bool;

import choco.Constraint;
import choco.Problem;
import choco.integer.IntDomainVar;
import junit.framework.TestCase;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/* File choco.test.bool.BoolRewriteTest.java, last modified by flaburthe 13 avr. 2004 12:59:06 */

/**
 * a class implementing tests for boolean rewrite rules
 */
public class BoolRewriteTest extends TestCase {
  private Logger logger = Logger.getLogger("choco.test");
  private Problem pb;
  private choco.integer.IntDomainVar[] x;
  private Constraint a, b, c, d, e, f;
  private Constraint exp1, exp2;

  protected void setUp() {
    logger.fine("choco.test.bool.BoolRewriteTest Testing...");
    pb = new Problem();
    x = pb.makeBoundIntVarArray("X", 10, 0, 1000);
    a = pb.lt(x[0], 3);
    b = pb.lt(pb.plus(x[1], x[2]), x[0]);
    c = pb.neq(pb.minus(x[1], x[2]), pb.plus(x[0], 7));
    d = pb.gt(x[4], 7);
    e = pb.leq(pb.scalar(new int[]{12, 32, 25}, new IntDomainVar[]{x[5], x[7], x[9]}), 9837);
    f = pb.neq(pb.scalar(new int[]{18, 22, -25}, new IntDomainVar[]{x[1], x[3], x[2]}), 8125);
  }

  protected void tearDown() {
    x = null;
    a = null;
    b = null;
    c = null;
    d = null;
    e = null;
    f = null;
    pb = null;
    exp1 = null;
    exp2 = null;
  }

  public void test1() {
    exp1 = pb.or(pb.or(a, b), c);
    exp2 = pb.or(a, b, c);
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test2() {
    exp1 = pb.and(pb.and(a, b), c);
    exp2 = pb.and(a, b, c);
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test3() {
    exp1 = pb.not(pb.and(a, b));
    exp2 = pb.or(pb.not(a), pb.not(b));
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test4() {
    exp1 = pb.implies(a, b);
    exp2 = pb.or(pb.not(a), b);
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test5() {
    exp1 = pb.or(pb.implies(c, d), pb.or(pb.not(e), f));
    exp2 = pb.or(pb.not(c), d, pb.not(e), f);
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test6() {
    exp1 = pb.and(pb.not(pb.or(a, b)), pb.and(c, d));
    exp2 = pb.and(pb.not(a), pb.not(b), c, d);
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test7() {
    exp1 = pb.implies(pb.and(a, b), pb.and(c, d));
    exp2 = pb.or(pb.not(a), pb.not(b), pb.and(c, d));
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test8() {
    exp1 = pb.not(pb.and(pb.or(a, b), pb.and(c, d)));
    exp2 = pb.or(pb.and(pb.not(a), pb.not(b)), pb.not(c), pb.not(d));
    assertTrue(exp1.isEquivalentTo(exp2));
  }

  public void test9() {
    exp1 = pb.not(pb.or(pb.and(pb.or(a, b), c), pb.and(d, pb.or(e, f))));
    exp2 = pb.and(pb.or(pb.and(pb.not(a), pb.not(b)), pb.not(c)), pb.or(pb.not(d), pb.and(pb.not(e), pb.not(f))));
    assertTrue(exp1.isEquivalentTo(exp2));
  }
}
