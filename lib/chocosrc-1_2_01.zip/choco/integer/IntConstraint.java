// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************

package choco.integer;

import choco.Constraint;
import choco.ContradictionException;
import choco.Propagator;
import choco.integer.var.IntVarEventListener;
import choco.util.IntIterator;

/**
 * An interface for all implementations of listeners using search variables.
 */
public interface IntConstraint extends Constraint, Propagator, IntVarEventListener {

  /**
   * <i>Network management:</i>
   * Accessing the i-th search variable of a constraint.
   *
   * @param i index of the variable among all search variables in the constraint. Numbering start from 0 on.
   * @return the variable, or null when no such variable is found
   */

  public IntDomainVar getIntVar(int i);

  public void awakeOnRemovals(int varIdx, IntIterator deltaDomain) throws ContradictionException;

  public void awakeOnBounds(int varIdx) throws ContradictionException;

}
