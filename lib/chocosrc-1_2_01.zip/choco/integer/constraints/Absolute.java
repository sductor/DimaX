package choco.integer.constraints;

import choco.AbstractConstraint;
import choco.Constraint;
import choco.ContradictionException;
import choco.integer.IntDomainVar;
import choco.util.Arithm;

/**
 * Implements a constraint X == |Y| + C, with X and Y two variables and C a constant.
 */
public class Absolute extends AbstractBinIntConstraint {

  /**
   * The search constant of the constraint
   */
  protected final int cste;

  /**
   * Constructs the constraint with the specified variables and constant.
   *
   * @param x0 first IntDomainVar
   * @param x1 second IntDomainVar
   * @param c  The search constant used in the disequality.
   */

  public Absolute(IntDomainVar x0, IntDomainVar x1, int c) {
    super(x0, x1);
    this.cste = c;
  }

  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  /**
   * The one and only propagation method, using foward checking
   */

  public void propagate() throws ContradictionException {
    // v1 => v0
    int minAbs = 0;
    int maxAbs = Math.max(Math.abs(v1.getInf()), Math.abs(v1.getSup()));
    if (v1.getDomain().isEnumerated() || v1.getInf() > 0 || v1.getSup() < 0) {
      // We can maybe increase minAbs value
      while(minAbs < maxAbs) {
        if (!v1.canBeInstantiatedTo(minAbs) && !v1.canBeInstantiatedTo(-minAbs)) {
          minAbs++;
        } else {
          break;
        }
      }
    }
    v0.updateInf(minAbs + cste, cIdx0);
    v0.updateSup(maxAbs + cste, cIdx0);

    // v0 => v1
    v1.updateInf(-(v0.getSup() - cste), cIdx1);
    v1.updateSup(v0.getSup() - cste, cIdx1);
    if (v1.getDomain().isEnumerated()) {
      for(int i = 0; i < v0.getInf() - cste; i++) {
        v1.removeVal(i, cIdx1);
        v1.removeVal(-i, cIdx1);
      }
    } else {
      if (v1.getInf() > 0) {
        v1.updateInf(v0.getInf() - cste, cIdx1);
      }
      if (v1.getSup() < 0) {
        v1.updateSup(-(v0.getInf() - cste), cIdx1);
      }
    }
  }


  public void awakeOnInf(int idx) throws ContradictionException {
    propagate();
  }

  public void awakeOnSup(int idx) throws ContradictionException {
    propagate();
  }

  public void awakeOnInst(int idx) throws ContradictionException {
    propagate();
  }

  public void awakeOnVar(int idx) throws ContradictionException {
    propagate();
  }

  public void awakeOnRem(int idx, int x) throws ContradictionException {
    propagate();
  }

  /**
   * Checks if the listeners must be checked or must fail.
   */

  public Boolean isEntailed() {
    throw new UnsupportedOperationException("Absolute.isEntailed is not implemented!");
  }

  /**
   * Checks if the constraint is satisfied when the variables are instantiated.
   */

  public boolean isSatisfied() {
    throw new UnsupportedOperationException("Absolute.isSatisfied is not implemented!");
  }

  /**
   * tests if the constraint is consistent with respect to the current state of domains
   *
   * @return true iff the constraint is bound consistent (weaker than arc consistent)
   */
  public boolean isConsistent() {
    throw new UnsupportedOperationException("Absolute.isConsistent is not implemented!");
  }

  public AbstractConstraint opposite() {
    throw new UnsupportedOperationException("Absolute.opposite is not implemented!");
  }

  public final boolean isEquivalentTo(Constraint compareTo) {
    throw new UnsupportedOperationException("Absolute.isEquivalentTo is not implemented!");
  }

  public String pretty() {
    StringBuffer sb = new StringBuffer();
    sb.append(v0.toString());
    sb.append(" = |");
    sb.append(v1.toString());
    sb.append("| ");
    sb.append(Arithm.pretty(this.cste));
    return sb.toString();
  }

}
