This package contains the source code for ZDT problems.

# Step 1 - Configuration
------------------------
Edit the "install.cmake" file by entering the FULL PATH of the "ParadisEO".
On Windows write your path with double antislash (ex: C:\\Users\\...)


# Step 2 - Build process
------------------------
ParadisEO is assumed to be compiled. To download ParadisEO, please visit http://paradiseo.gforge.inria.fr/.
Go to the Example/build/ directory and lunch cmake:
(Unix)       > cmake ..
(Windows)    > cmake .. -G"Visual Studio 9 2008"

Note for windows users: if you don't use VisualStudio 9, enter the name of your generator instead of "VisualStudio 9 2008".


# Step 3 - Compilation
----------------------
In the Example/build/ directory:
(Unix)       > make
(Windows)    Open the VisualStudio solution and compile it, compile also the target install.
You can refer to this tutorial if you don't know how to compile a solution: http://paradiseo.gforge.inria.fr/index.php?n=Paradiseo.VisualCTutorial


# Step 4 - Execution
---------------------
A toy example is given to test the components. You can run these tests as following.
To define problem-related components for your own problem, please refer to the tutorials available on the website : http://paradiseo.gforge.inria.fr/.
In the Example/build/ directory:
(Unix)       > ctest
Windows users, please refer to this tutorial: http://paradiseo.gforge.inria.fr/index.php?n=Paradiseo.VisualCTutorial

In the directory "application", there are three ".cpp" which instantiate NSGAII on ZDT problems.

(Unix) After compilation you can run the script "Example/run.sh" and see results in "NSGAII.out". Parameters can be modified in the script.

(Windows) Add argument "NSGAII.param" and execute the corresponding algorithms.
Windows users, please refer to this tutorial: http://paradiseo.gforge.inria.fr/index.php?n=Paradiseo.VisualCTutorial

# Documentation
---------------
The API-documentation is available in doc/html/index.html 

