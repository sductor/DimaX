//     ___  ___         PaLM library for Choco system
//    /__ \/ __\        (c) 2001 - 2004 -- Narendra Jussien
//   ____\ |/_____
//  /_____\/_____ \     PalmExplanation based constraint programming tool
// |/   (_)(_)   \|
//       \ /            Version 0.1
//       \ /            January 2004
//       \ /
// ______\_/_______     Contibutors: Fran�ois Laburthe, Hadrien Cambazard, Guillaume Rochart...

package choco.palm.dbt.integer.explain;

import choco.AbstractProblem;
import choco.Constraint;
import choco.palm.dbt.integer.PalmIntVar;

import java.util.BitSet;

public class IncInfExplanation extends AbstractBoundExplanation {
  public IncInfExplanation(AbstractProblem pb, BitSet explanation, int previousValue, PalmIntVar variable) {
    super(pb);
    this.explanation = explanation;
    this.previousValue = previousValue;
    this.variable = variable;
  }

  public String toString() {
    return this.variable + ".inf > " + this.previousValue + " because " + super.toString();
  }

  public void postUndoRemoval(Constraint removed) {
    this.removeDependencies(removed);
    this.variable.restoreInf(this.previousValue);
  }
}
