package choco.real.constraint;

import choco.Constraint;
import choco.Propagator;
import choco.integer.IntConstraint;
import choco.integer.IntDomainVar;
import choco.real.RealVar;

/**
 * An interface for mixed constraint : interger and flot variables.
 */
public interface MixedConstraint extends Constraint, Propagator, 
    RealListener, IntConstraint {
  /**
   * Returns the real variable with index i.
   * @param i the variable index
   * @return the variable with index i
   */
  RealVar getRealVar(int i);

  /**
   * Returns the number of real variables. Note that here the number of 
   * variables should equal the number of real variables plus the number
   * of integer variables.
   * @return the number of <i>real</i> variables.
   */
  int getRealVarNb();

  /**
   * Returns the integer variable with index i.
   * @param i the variable index
   * @return the variable with index i
   */
  IntDomainVar getIntVar(int i);

  /**
   * Returns the number of integer variables. Note that here the number of 
   * variables should equal the number of real variables plus the number
   * of integer variables.
   * @return the number of <i>integer</i> variables.
   */  
  int getIntVarNb();
}
