// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.integer.search;

import choco.integer.IntDomainVar;

/**
 * An interface for control objects that model a binary choice to an search value
 */
public interface ValSelector {
  /**
   * A method selecting the search value used for the alternative
   */
  int getBestVal(IntDomainVar x);
}
