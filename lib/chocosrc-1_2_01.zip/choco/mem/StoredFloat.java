// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.mem;

import java.util.logging.Logger;

/**
 * A class implementing a backtrackable float variable.
 */
public class StoredFloat {
  /**
   * Reference to an object for logging trace statements related memory & backtrack (using the java.util.logging package)
   */

  private static Logger logger = Logger.getLogger("choco.mem");

  /**
   * The current {@link choco.mem.Environment}.
   */

  private Environment environment;


  /**
   * Current value of the search.
   */

  private double currentValue;


  /**
   * The last world the search was moidified in.
   */

  int worldStamp;


  /**
   * The current {@link choco.mem.StoredIntTrail}.
   */

  private final StoredFloatTrail trail;


  /**
   * Constructs a stored search with an unknown initial value.
   * Note: this constructor should not be used directly: one should instead
   * use the Environment factory
   */

  public StoredFloat(Environment env) {
    this(env, Double.NaN);
  }


  /**
   * Constructs a stored search with an initial value.
   * Note: this constructor should not be used directly: one should instead
   * use the Environment factory
   */

  public StoredFloat(Environment env, double d) {
    environment = env;
    currentValue = d;
    worldStamp = env.currentWorld;
    trail = (StoredFloatTrail) this.environment.getTrail(Environment.FLOAT_TRAIL);
  }


  /**
   * Returns the current value.
   */

  public double get() {
    return currentValue;
  }


  /**
   * Checks if a value is currently stored.
   */

  public boolean isKnown() {
    return (currentValue != Double.NaN);
  }


  /**
   * Modifies the value and stores if needed the former value on the
   * trailing stack.
   */

  public void set(double y) {
    if (y != currentValue) {
      if (this.worldStamp < environment.currentWorld) {
        trail.savePreviousState(this, currentValue, worldStamp);
        worldStamp = environment.currentWorld;
      }
      currentValue = y;
    }
  }

  /**
   * modifying a StoredInt by an increment
   *
   * @param delta
   */
  public void add(double delta) {
    set(get() + delta);
  }

  /**
   * Modifies the value without storing the former value on the trailing stack.
   *
   * @param y      the new value
   * @param wstamp the stamp of the world in which the update is performed
   */

  void _set(double y, int wstamp) {
    currentValue = y;
    worldStamp = wstamp;
  }

  /**
   * Retrieving the environment
   */
  public Environment getEnvironment() {
    return environment;
  }

}
