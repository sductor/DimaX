package choco.branch;

/**
 * A utility class with static methods implementing useful heuristics
 * for branching strategies
 */
public class Heuristic {


}


