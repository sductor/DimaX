package choco.real.exp;

import choco.AbstractProblem;
import choco.ContradictionException;
import choco.real.RealExp;
import choco.real.RealInterval;
import choco.real.RealMath;

/**
 * An expression modelling a real addition.
 */
public class RealPlus extends AbstractRealBinTerm {
  /**
   * Builds an addition expression for real constraint modelling.
   * @param pb is the current problem
   * @param exp1 is the first expression operand
   * @param exp2 is the second expression operand
   */
  public RealPlus(final AbstractProblem pb, final RealExp exp1, 
      final RealExp exp2) {
    super(pb, exp1, exp2);
  }

  /**
   * Tightens the expression to find the smallest interval containing values
   * the expression can equal according to operand domains.
   */
  public void tighten() {
    RealInterval res = RealMath.add(exp1, exp2);
    inf.set(res.getInf());
    sup.set(res.getSup());
  }

  /**
   * Projects domain reduction on operands according to the expression
   * domain itself (due to constraint restrictions).
   * @throws ContradictionException if a domain becomes empty
   */
  public void project() throws ContradictionException {
    exp1.intersect(RealMath.sub(this, exp2));
    exp2.intersect(RealMath.sub(this, exp1));
  }
}
