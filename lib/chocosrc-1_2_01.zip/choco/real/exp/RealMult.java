package choco.real.exp;

import choco.AbstractProblem;
import choco.ContradictionException;
import choco.real.RealExp;
import choco.real.RealInterval;
import choco.real.RealMath;

/**
 * An expression modelling a multiplication.
 */
public class RealMult extends AbstractRealBinTerm {
  public RealMult(AbstractProblem pb, RealExp exp1, RealExp exp2) {
    super(pb, exp1, exp2);
  }

  public void tighten() {
    RealInterval res = RealMath.mul(exp1, exp2);
    inf.set(res.getInf());
    sup.set(res.getSup());
  }

  public void project() throws ContradictionException {
    RealInterval res = RealMath.odiv_wrt(this, exp2, exp1);
    if (res.getInf() > res.getSup()) {
      problem.getPropagationEngine().raiseContradiction();
    }
    exp1.intersect(res);

    res = RealMath.odiv_wrt(this, exp1, exp2);
    if (res.getInf() > res.getSup()) {
      problem.getPropagationEngine().raiseContradiction();
    }
    exp2.intersect(res);
  }
}
