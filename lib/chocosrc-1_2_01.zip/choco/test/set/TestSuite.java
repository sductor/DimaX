package choco.test.set;

import junit.framework.Test;

import java.util.logging.Logger;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

public class TestSuite extends junit.framework.TestSuite {
  private static Logger logger = Logger.getLogger("choco.test");

  public static Test suite() {
    TestSuite test = new TestSuite();

    logger.fine("Build TestSuite for choco.set");

    test.addTestSuite(VariableTests.class);
    test.addTestSuite(BasicConstraintsTests.class);
    test.addTestSuite(SearchTests.class);


    return test;
  }
}
