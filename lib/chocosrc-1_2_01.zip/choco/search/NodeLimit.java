// **************************************************
// *  CHOCO: an open-source Constraint Programming  *
// *     System for Research and Education          *
// *                                                *
// *    contributors listed in choco.Entity.java    *
// *           Copyright (C) F. Laburthe, 1999-2006 *
// **************************************************
package choco.search;


public final class NodeLimit extends AbstractGlobalSearchLimit {

  public NodeLimit(AbstractGlobalSearchSolver theSolver, int theLimit) {
    super(theSolver, theLimit);
    unit = "nodes";
  }

  public boolean newNode(AbstractGlobalSearchSolver solver) {
    nb++;
    return ((nb + nbTot) < nbMax);
  }

  public boolean endNode(AbstractGlobalSearchSolver solver) {
    return ((nb + nbTot) < nbMax);  //<hca> test also the limit while backtracking
  }

}
