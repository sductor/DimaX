package choco.palm.cbj.search;

import choco.ContradictionException;
import choco.branch.VarSelector;
import choco.integer.search.AssignVar;
import choco.integer.search.ValIterator;
import choco.palm.Explanation;
import choco.palm.JumpProblem;
import choco.palm.cbj.explain.JumpExplanation;
import choco.palm.integer.ExplainedIntVar;

// **************************************************
// *                   J-CHOCO                      *
// *   Copyright (C) F. Laburthe, 1999-2003         *
// **************************************************
// *  an open-source Constraint Programming Kernel  *
// *     for Research and Education                 *
// **************************************************

/**
 * An variable assigning heuristic used by search algorithm.
 */
public class JumpAssignVar extends AssignVar {

  /**
   * Builds an assign variable heuristic.
   * @param varSel a variable selector
   * @param valHeuri a value iterator
   */
  public JumpAssignVar(final VarSelector varSel,
      final ValIterator valHeuri) {
    super(varSel, valHeuri);
  }

  /**
   * Builds an assign variable heuristic.
   * @param varSel a variable selector
   * @param valHeuri a value selector
   */
  public JumpAssignVar(final VarSelector varSel,
      final choco.integer.search.ValSelector valHeuri) {
    super(varSel, valHeuri);
  }

  /**
   * Actually posts the choice taken if this search tree node. Here the
   * variable will be instantiated to the value i.
   * @param x the variable involved in the choice
   * @param i the value chosen for this variable
   * @throws ContradictionException if a contradiction occurs due to this
   * choice
   */
  public void goDownBranch(final Object x, final int i) 
  throws ContradictionException {
    logDownBranch(x, i);
    ExplainedIntVar y = (ExplainedIntVar) x;
    Explanation exp = ((JumpProblem) manager.problem).
        makeExplanation(manager.problem.getWorldIndex() - 1);    
    y.instantiate(i, -1, exp);
    manager.problem.propagate();
  }

  /**
   * A previous choice is undone. Here the bad value is removed from the
   * domain and correctly explained.
   * @param x the involved variable 
   * @param i the bad value
   * @param e the explanation about inconsistancy
   * @throws ContradictionException if a contradiction occurs due to the
   * implied domain reduction
   */
  public void goUpBranch(final Object x, final int i, final Explanation e) 
  throws ContradictionException {
    logUpBranch(x, i);
    ExplainedIntVar y = (ExplainedIntVar) x;
    //if (((JumpExplanation)e).contains(manager.problem.getWorldIndex() + 2))
    ((JumpExplanation) e).delete(manager.problem.getWorldIndex());
    y.removeVal(i, -1, e);
    manager.problem.propagate();
  }
}
